#pragma once

#include "mainWin.h"
#include "newWin.h"
#include "colorWin.h"
#include "saveWin.h"
#include "loadWin.h"
#include "editLevel.h"

#define M_PI 3.14159265358979323846

struct Win
{
    MainWin Main;
    New setNew;
    Color color;
    Save save;
    Load load;
    EditLevel editLevel;

    Win(VariabiliGlobali& global)
        : Main(global), setNew(global), color(global), save(global), load(global), editLevel(global)
    {}
};

struct PntHeader
{
    char magic[4] = { 0 };       // "PNT!" -> Identifica il tipo di file
    uint32_t version = 1;        // 1      -> Utile se cambierai il formato in futuro      

    uint32_t currentLevel = 0;
    uint32_t baseLevelPos = 0;
    uint32_t numLevels = 0;

    float zoom = 0.0f;
    Uint8 alphaLevel = 0;
    std::string currentfile;
    Coord alphaGridCoord = { 0.0f, 0.0f };

    ColorRgb color_PP = { 0, 0, 0, 0 };
    ColorRgb color_SF = { 0, 0, 0, 0 };
    ColorRgb bgColor = { 0, 0, 0, 0 };
    ToolsSettings toolsSettings;
};

struct VariabiliGlobali
{
    VariabiliGlobali()
        : currentLevel(0),
        baseLevelPos(0),
        directoryDraw("Disegni/"),
        directoryProjects("Projects/"),
        leftMousePressed(false),
        doppioClick(false),
        hasLast(false),
        mouseVisible(true),
        cronologyUpdate(false),
        ctrl(false),
        hasMovedSinceClick(false),
        lastClick{ +1, -1 },
        click{ -1, -1 },
        cursorPosition{ 0, 0 },
        win(*this),
        cursor(nullptr),
        projectData(nullptr),
        copyTexture(nullptr),
        fileCartella(),
        fileRicerca(),
        loadedSurfaces()
    {}

    size_t currentLevel;
    size_t baseLevelPos;
    std::string directoryDraw;
    std::string directoryProjects;
    bool leftMousePressed;
    bool doppioClick;
    bool hasLast;
    bool mouseVisible;
    bool cronologyUpdate;
    bool ctrl;
    bool hasMovedSinceClick;
    Coord lastClick;
    Coord click;
    Coord cursorPosition;
    CopySelection copy;
    Win win;
    SDL_Cursor* cursor;
    PntHeader* projectData;
    SDL_Texture* copyTexture;
    std::vector<loadFiles> fileCartella;
    std::vector<loadFiles> fileRicerca;
    std::vector<IconsSurface> loadedSurfaces;
};