#pragma once

#include "variabiliGlobali.h"
#include "graphics.h"
#include "textBox.h"

namespace SET
{
    void menuFile(VariabiliGlobali& global);
    void menuTools(VariabiliGlobali& global);
    void alphaLevel(VariabiliGlobali& global);
    void newTextBox(VariabiliGlobali& global, bool level);
    void saveWindow(VariabiliGlobali& global);
    void loadWindow(VariabiliGlobali& global);
    void levelMenu(VariabiliGlobali& global);
    void toolsSetting(VariabiliGlobali& global);
}