#define SDL_MAIN_HANDLED
#include "texture.h"

namespace TEXTURE
{
    SDL_Texture* LoadImageTexture(SDL_Renderer* renderer, const std::string& path)
    {
        SDL_Surface* surface = IMG_Load(path.c_str());
        if (!surface) {
            SDL_Log("Errore caricamento immagine: %s", path.c_str());
            return nullptr;
        }

        SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_DestroySurface(surface);
        return tex;
    }

    void LoadTextureSurfaces(std::vector<IconsSurface>& surfaces)
    {
        struct File
        {
            std::vector<std::string> vect;
            std::string directory;
        };

        std::string basePath = "Texture/";

        File alphabetMai;
        alphabetMai.vect = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        alphabetMai.directory = "Lettere/Maiuscole/";

        File alphabetMin;
        alphabetMin.vect = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
        alphabetMin.directory = "Lettere/Minuscole/";

        File numbers;
        numbers.vect = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        numbers.directory = "Numeri/";

        File symbols;
        symbols.vect = { ".", "DUE PUNTI", "PENNELLO", "GOMMA", "Triangolo", "BUCKET", "PIPETTA", "MOVE", "ERROR", "add_level", "edit_level", "delete_level", 
            "Xcento", ",", "-", "Visibile", "NonVisibile", "Freccia2Punte", "selezioneRettangolare", "selezioneCircolare", "selezioneLazo", "selezioneColore",
            "ancoraLivello" };
        symbols.directory = "Simboli/";

        surfaces.resize(alphabetMai.vect.size() + alphabetMin.vect.size() + numbers.vect.size() + symbols.vect.size());
        size_t currentSize = 0;

        auto loadFiles = [&](const File& fileStruct, const std::string& extension = ".png")
            {
                for (size_t i = 0; i < fileStruct.vect.size(); ++i, ++currentSize)
                {
                    surfaces[currentSize].name = fileStruct.vect[i];
                    std::string file = basePath + fileStruct.directory + fileStruct.vect[i] + extension;
                    surfaces[currentSize].surface = IMG_Load(file.c_str());
                    if (!surfaces[currentSize].surface)
                    {
                        SDL_Log("Errore caricamento file: %s", file.c_str());
                    }
                }
            };

        loadFiles(alphabetMai);
        loadFiles(alphabetMin);
        loadFiles(numbers);
        loadFiles(symbols);
    }

    Textures getTexture(std::vector<Textures>& textures, std::string name)
    {
        for (const auto texture : textures)
        {
            if (texture.name == name && texture.texture) return texture;
        }
        SDL_Log("Texture <%s> non disponibile", name.c_str());

        for (const auto texture : textures)
        {
            if (texture.name == "ERROR" && texture.texture) return texture;
        }
        SDL_Log("Texture <ERROR> non disponibile");
        return{};
    }

    std::vector<Textures> CreateIconsTextures(SDL_Renderer* renderer, const std::vector<IconsSurface>& surfaces)
    {
        std::vector<Textures> textures(surfaces.size());

        for (size_t i = 0; i < surfaces.size(); i++)
        {
            textures[i].name = surfaces[i].name;
            if (surfaces[i].surface)
            {
                textures[i].texture = SDL_CreateTextureFromSurface(renderer, surfaces[i].surface);
                if (!textures[i].texture)
                {
                    SDL_Log("Errore creazione texture per %s: %s",
                        surfaces[i].name.c_str(), SDL_GetError());
                }
            }
        }

        return textures;
    }

    std::vector<std::vector<ColorRgb>> getLevelsMap(VariabiliGlobali& global) 
    {
        Project& project = global.win.Main.level();
        const std::vector<Level>& levels = project.GetLevel();
        const size_t startPos = global.baseLevelPos;

        if (levels.empty())
            return {};

        std::vector<std::vector<ColorRgb>> finalMap(
            static_cast<size_t>(global.win.Main.level()[startPos].size.h), 
            std::vector<ColorRgb>(static_cast<size_t>(global.win.Main.level()[startPos].size.w))
        );

        for (size_t y = 0; y < finalMap.size(); ++y)
        {
            for (size_t x = 0; x < finalMap[y].size(); ++x)
            {
                finalMap[y][x] = { 0, 0, 0, 0 };
            }
        }

        // Sovrapponi i livelli visibili
        for (const Level& lvl : levels)
        {
            if (!lvl.isVisible || lvl.map.empty())
                continue;

            for (size_t y = 0; y < lvl.map.size(); ++y)
            {
                for (size_t x = 0; x < lvl.map[y].size(); ++x)
                {
                    Coord pixelPos = {
                        lvl.moveCoord.x - levels[startPos].zoomSize.x + x,
                        lvl.moveCoord.y - levels[startPos].zoomSize.y + y
                    };

                    if (pixelPos.x < 0.0f || pixelPos.x >= levels[startPos].size.w ||
                        pixelPos.y < 0.0f || pixelPos.y >= levels[startPos].size.h) continue;

                    const ColorRgb& pixel = lvl.map[y][x];
                    if (pixel.a == 0)
                        continue;

                    finalMap[static_cast<size_t>(pixelPos.y)][static_cast<size_t>(pixelPos.x)] = pixel;
                }
            }
        }

        return finalMap;
    }

    SDL_Texture* CreateTextureFromMap(SDL_Renderer* renderer, const std::vector<std::vector<ColorRgb>>& map)
    {
        if (map.empty() || map[0].empty())
            return nullptr;

        int height = static_cast<int>(map.size());
        int width = static_cast<int>(map[0].size());

        SDL_Texture* texture = SDL_CreateTexture(
            renderer,
            SDL_PIXELFORMAT_RGBA8888,
            SDL_TEXTUREACCESS_STREAMING,
            width,
            height
        );

        if (!texture)
            return nullptr;

        void* pixels = nullptr;
        int pitch = 0;

        if (!SDL_LockTexture(texture, nullptr, &pixels, &pitch))
        {
            SDL_DestroyTexture(texture);
            SDL_Log("Errore nel lock della texture");
            return nullptr;
        }

        Uint32* dst = static_cast<Uint32*>(pixels);

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                const ColorRgb& c = map[y][x];

                Uint32 pixel =
                    (c.a << 24) |
                    (c.b << 16) |
                    (c.g << 8) |
                    (c.r);

                dst[y * (pitch / 4) + x] = pixel;
            }
        }

        SDL_UnlockTexture(texture);

        return texture;
    }
}