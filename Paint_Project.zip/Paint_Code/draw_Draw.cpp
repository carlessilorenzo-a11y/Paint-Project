#define SDL_MAIN_HANDLED
#include "draw_Draw.h"
#include "variabiliGlobali.h"
#include "textBox.h"
#include "graphics.h"

void setRectClip(VariabiliGlobali& global)
{
    Level& currentLvl = global.win.Main.level()[global.currentLevel];
    Level* baseLvl = nullptr;

    if (global.win.Main.level().IsBaseLevelDeleted())
    {
        baseLvl = &global.win.Main.level().GetFinalLevel();
    }
    else
    {
        baseLvl = &global.win.Main.level()[global.baseLevelPos];
    }

    SDL_FRect levelEdge = {
        currentLvl.moveCoord.x - 1,
        currentLvl.moveCoord.y - 1,
        currentLvl.zoomSize.w + 2,
        currentLvl.zoomSize.h + 2
    };

    // Rettangolo base (area di lavoro)
    SDL_Rect clipBase = {
        static_cast<int>(global.win.Main.GetAreaDiLavoro().x),
        static_cast<int>(global.win.Main.GetAreaDiLavoro().y),
        static_cast<int>(global.win.Main.GetAreaDiLavoro().w),
        static_cast<int>(global.win.Main.GetAreaDiLavoro().h)
    };

    // Rettangolo viewport (zoom/move)
    SDL_Rect clipView = {
        static_cast<int>(baseLvl->zoomSize.x),
        static_cast<int>(baseLvl->zoomSize.y),
        static_cast<int>(baseLvl->zoomSize.w),
        static_cast<int>(baseLvl->zoomSize.h)
    };

    // Intersezione tra i due
    SDL_Rect clipFinal;
    if (SDL_GetRectIntersection(&clipBase, &clipView, &clipFinal))
    {
        SDL_SetRenderClipRect(global.win.Main.getRenderer(), &clipFinal);
    }
    else {
        // Nessuna intersezione: non disegnare nulla
        SDL_SetRenderClipRect(global.win.Main.getRenderer(), nullptr);
    }

    renderTexture(global);

    SDL_SetRenderClipRect(global.win.Main.getRenderer(), &clipBase);
    GRAPHICS::RenderRectTratteggiato(global.win.Main.getRenderer(), &levelEdge, { 0, 0, 0, 255 }, { 200, 180, 0, 255 });

    if (global.win.Main.GetSelections())
    {
        SDL_SetRenderClipRect(global.win.Main.getRenderer(), &clipBase);
        global.win.Main.GetSelections()->Draw();
    }
}

void renderTexture(VariabiliGlobali& global)
{
    SDL_FRect temp = {
        global.win.Main.level().GetAlphaGridCoord().x,
        global.win.Main.level().GetAlphaGridCoord().y,
        global.win.Main.level().GetLevel()[global.baseLevelPos].zoomSize.w,
        global.win.Main.level().GetLevel()[global.baseLevelPos].zoomSize.h
    };
    SDL_RenderTexture(global.win.Main.getRenderer(), global.win.Main.level().GetAlphaGrid(), nullptr, &temp);

    for (int i = static_cast<int>(global.win.Main.level().GetLevel().size() - 1); i >= 0 ; --i)
    {
        if (global.win.Main.level()[i].isVisible)
        {
            temp = {
                global.win.Main.level()[i].moveCoord.x,
                global.win.Main.level()[i].moveCoord.y,
                global.win.Main.level()[i].zoomSize.w,
                global.win.Main.level()[i].zoomSize.h
            };
            SDL_SetTextureAlphaMod(global.win.Main.level()[i].canvas, global.win.Main.level()[i].opacity);
            SDL_RenderTexture(global.win.Main.getRenderer(), global.win.Main.level()[i].canvas, nullptr, &temp);
        }
    }
}