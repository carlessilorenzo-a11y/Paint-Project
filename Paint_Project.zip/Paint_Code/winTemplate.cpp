#define SDL_MAIN_HANDLED
#include "winTemplate.h"
#include "variabiliGlobali.h"

Window::Window() :
    window(nullptr),
    renderer(nullptr),
    open(false),
    size({ 0, 0 }),
    textures() {
}

void Window::Initialize(const char* title, int w, int h, bool centered, int x, int y, bool resizeble, bool maximized)
{
    if (open)
    {
        Destroy();
    }

    size = { w, h };
    Uint32 flags = ((resizeble) ? SDL_WINDOW_RESIZABLE : 0) | ((maximized) ? SDL_WINDOW_MAXIMIZED : 0);
    window = SDL_CreateWindow(title, w, h, flags);

    if (!window)
    {
        SDL_Log("Errore nella creazione della finestra: %s", SDL_GetError());
        throw std::runtime_error("Impossibile creare la finestra SDL.");
    }

    SDL_SetWindowPosition(window, (centered) ? SDL_WINDOWPOS_CENTERED : x, (centered) ? SDL_WINDOWPOS_CENTERED : y);

    renderer = SDL_CreateRenderer(window, nullptr);
    if (!renderer)
    {
        SDL_DestroyWindow(window);
        window = nullptr;
        SDL_Log("Errore nella creazione del renderer: %s", SDL_GetError());
        throw std::runtime_error("Impossibile creare il renderer SDL.");
    }

    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
    open = true;
}

void Window::Destroy()
{
    if (renderer)
    {
        SDL_DestroyRenderer(renderer);
        renderer = nullptr;
    }
    if (window)
    {
        SDL_DestroyWindow(window);
        window = nullptr;
    }

    open = false;
}

SDL_Window* Window::getWindow() const { return window; }
SDL_Renderer* Window::getRenderer() const { return renderer; }

bool& Window::isOpen() { return open; }
const bool& Window::isOpen() const { return open; }

Size& Window::getSize() { return size; }
const Size& Window::getSize() const { return size; }

std::vector<Textures>& Window::getTextures() { return textures; };
const std::vector<Textures>& Window::getTextures() const { return textures; };