#pragma once
#include "winTemplate.h"

class Slider;

class Interfaccia_RGBHSV
{
private:
    VariabiliGlobali& global;
    SDL_FRect& staticRect;
    SDL_FRect& continueRect;
    ColorRgb& finalColor;
    bool& colorPP;

    SDL_FRect rectCerchio;
    Coord centro;
    float RgbDegree;
    float outerRadius;
    float innerRadius;
    Triangolo triangolo;
    ColorRgb currentColor;
    bool drawCursor;
    Coord intersectionTriangle;
    std::vector<TextBox*> textbox;
    std::vector<std::string> str;
    std::vector<Slider*> barreScelta;
    std::vector<float> valPercentuale;
    SDL_Texture* colorWheel;
    SDL_Texture* HSV_Triangle;

public:
    Interfaccia_RGBHSV(VariabiliGlobali& global, SDL_FRect& staticRect, SDL_FRect& continueRect, ColorRgb& finalColor, bool& colorPP);

    float getPercentualeRGB(float variabile);
    ColorRgb getHueColor(float h);
    float getAngleFromRGB(ColorRgb color);
    bool isInRadius(float x, float y, float& dx, float& dy);
    SDL_Texture* createColorWheel();
    SDL_Texture* createHSV_Triangle();
    void SetTriangolo();
    bool isPixelInTriangle(Triangolo* tr, float x, float y, float& w1, float& w2, float& w3);
    ColorRgb getRgbFromCoefficient(float w1, float w2, float w3);
    void getWeightsFromRGB(ColorRgb finalCol, float& w1, float& w2, float& w3);
    Coord intersectionLineandLine(Coord p1, Coord p2, Coord p3, Coord p4);
    void UpdateCursor(bool moving, Triangolo* tr);
    void SetRGBHSV(char type, float newVal);
    void UpdateRGBHSV();
    void Set();
    void Draw();
    void Update();
    void UpdateRgbCerchio(bool cursorInMove, bool cursorRealesed);

    SDL_FRect& GetRectCerchio();
    const SDL_FRect& GetRectCerchio() const;
    void SetRectCerchio(const SDL_FRect& rect);

    Coord& GetCentro();
    const Coord& GetCentro() const;
    void SetCentro(const Coord& c);

    float& GetRgbDegree();
    float GetRgbDegree() const;
    void SetRgbDegree(float degree);

    float& GetOuterRadius();
    float GetOuterRadius() const;
    void SetOuterRadius(float radius);

    float& GetInnerRadius();
    float GetInnerRadius() const;
    void SetInnerRadius(float radius);

    Triangolo& GetTriangolo();
    const Triangolo& GetTriangolo() const;
    void SetTriangolo(const Triangolo& t);

    ColorRgb& GetCurrentColor();
    const ColorRgb& GetCurrentColor() const;
    void SetCurrentColor(const ColorRgb& color);

    bool& GetDrawCursor();
    bool GetDrawCursor() const;
    void SetDrawCursor(bool draw);

    Coord& GetIntersectionTriangle();
    const Coord& GetIntersectionTriangle() const;
    void SetIntersectionTriangle(const Coord& coord);

    SDL_FRect& GetStaticRect();
    const SDL_FRect& GetStaticRect() const;
    void SetStaticRect(const SDL_FRect& rect);

    std::vector<TextBox*>& GetTextbox();
    const std::vector<TextBox*>& GetTextbox() const;

    std::vector<std::string>& GetStr();
    const std::vector<std::string>& GetStr() const;

    std::vector<Slider*>& GetBarreScelta();
    const std::vector<Slider*>& GetBarreScelta() const;

    std::vector<float>& GetValPercentuale();
    const std::vector<float>& GetValPercentuale() const;
};
