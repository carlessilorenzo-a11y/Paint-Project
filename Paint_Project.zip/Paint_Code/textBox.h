#pragma once

#include "variabiliGlobali.h"

class TextBox
{
private:
	SDL_FRect rect;
	int maxSize;
	float minNum;
	float maxNum;
	int maxDecimali;
	VariabiliGlobali& global;
	Window* win;
	ColorRgb bgColor;
	float charSize;
	bool open;
	bool ERROR;
	TypeTxtBox type;
	SDL_FRect triangleUpRect;
	SDL_FRect triangleDownRect;
	SDL_FRect startRect;
	std::string text;
	SDL_Texture* textureTriangle;

public:
	TextBox(SDL_FRect rect, TypeTxtBox type, int maxSize, float minNum, float maxNum, int maxDecimali, VariabiliGlobali& global, Window* win, ColorRgb bgColor, float charSize = 10.0f);
	TextBox(SDL_FRect rect, TypeTxtBox type, int maxSize, VariabiliGlobali& global, Window* win, ColorRgb bgColor, float charSize = 10.0f);
	~TextBox();

	void Update(bool* textIsUpdate = nullptr);

	void UpdateText(SDL_Event& event);

	void Draw();

	std::string getText()  const;
	SDL_FRect getRect() const;
	void setRect(SDL_FRect newRect);
	bool getERROR() const;

	void setText(std::string newText);
	void setERROR(bool newERROR);
};