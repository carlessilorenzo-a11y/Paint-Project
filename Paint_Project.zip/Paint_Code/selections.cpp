#define SDL_MAIN_HANDLED
#include "selections.h"
#include "app.h"

Selections::Selections(Window* win, Tools& type, VariabiliGlobali& global) :
	win(win),
	type(type),
	global(global),
	lastType(Tools::NOTHING),
	selected(false),
	moving(false),
	color1{ 0, 0, 0, 255 },
	color2{ 255, 255, 255, 255 },
	settingRect{},
	currentRectPos(-1),
	startCoord{ -1.0f, -1.0f },
	finalCoord{ -1.0f, -1.0f },
	rect{ 0.0f, 0.0f, 0.0f, 0.0f },
	lazoCoord{},
	preparationLazoCoord{},
	lazoMovingPoints{},
	area{},
	preparation(false),
	edge(nullptr)
{}

void Selections::Draw()
{
	if (selected)
	{
		switch (lastType)
		{
		case Tools::SELEZIONE_RETTANGOLARE:
		{
			GRAPHICS::RenderRectTratteggiato(win->getRenderer(), &rect, color1, color2);
			break;
		}
		case Tools::SELEZIONE_CIRCOLARE:
		{
			GRAPHICS::RenderEllisseInscrittaTratteggiata(win->getRenderer(), &rect, color1, color2);
			break;
		}
		case Tools::SELEZIONE_LAZO:
		{
			GRAPHICS::RenderPointsTratteggiati(win->getRenderer(), lazoCoord, color1, color2);

			/*for (const auto& pixel : area)
			{
				SDL_SetRenderDrawColor(win->getRenderer(), 0, 0, 0, 255);
				SDL_RenderPoint(win->getRenderer(), pixel.x, pixel.y);
			}*/
			break;
		}
		case Tools::SELEZIONE_COLORE:
		{
			SDL_FRect levelPos = {
				global.win.Main.level()[global.currentLevel].moveCoord.x - 1,
				global.win.Main.level()[global.currentLevel].moveCoord.y - 1,
				global.win.Main.level()[global.currentLevel].zoomSize.w + 2,
				global.win.Main.level()[global.currentLevel].zoomSize.h + 2
			};
			if (edge)
			{
				SDL_RenderTexture(win->getRenderer(), edge, nullptr, &levelPos);
			}
			break;
		}
		}

		/*SDL_SetRenderDrawColor(win->getRenderer(), 255, 0, 0, 255);
		SDL_RenderRect(win->getRenderer(), &rect);*/
	}

	if (!settingRect.empty() && (type == Tools::SELEZIONE_RETTANGOLARE || type == Tools::SELEZIONE_CIRCOLARE))
	{
		for (int i = static_cast<int>(settingRect.size()) - 1; i >= 0; --i)
		{
			if (currentRectPos != -1 && i != currentRectPos && i != 0) continue;

			SDL_FRect frame1 = {
				settingRect[i].x - 1.0f,
				settingRect[i].y - 1.0f,
				settingRect[i].w + 2.0f,
				settingRect[i].h + 2.0f
			};

			SDL_FRect frame2 = {
				settingRect[i].x + 1.0f,
				settingRect[i].y + 1.0f,
				settingRect[i].w - 2.0f,
				settingRect[i].h - 2.0f
			};

			SDL_SetRenderDrawColor(win->getRenderer(), 0, 0, 0, 255);
			SDL_RenderRect(win->getRenderer(), &frame1);
			SDL_RenderRect(win->getRenderer(), &frame2);
			SDL_SetRenderDrawColor(win->getRenderer(), 255, 255, 255, 255);
			SDL_RenderRect(win->getRenderer(), &settingRect[i]);
		}

		if (type == Tools::SELEZIONE_CIRCOLARE)
		{
			GRAPHICS::RenderEllisseInscritta(win->getRenderer(), &settingRect[0], { 255, 255, 255, 255 });
			SDL_FRect frameRect = {
				settingRect[0].x - 1.0f,
				settingRect[0].y - 1.0f,
				settingRect[0].w + 2.0f,
				settingRect[0].h + 2.0f
			};
			GRAPHICS::RenderEllisseInscritta(win->getRenderer(), &frameRect, { 0, 0, 0, 255 });
			frameRect = {
				settingRect[0].x + 1.0f,
				settingRect[0].y + 1.0f,
				settingRect[0].w - 2.0f,
				settingRect[0].h - 2.0f
			};
			GRAPHICS::RenderEllisseInscritta(win->getRenderer(), &frameRect, { 0, 0, 0, 255 });

			SDL_SetRenderDrawColor(win->getRenderer(), 0, 0, 0, 255);
			float centroSize = 10.0f;
			SDL_RenderLine(
				win->getRenderer(),
				settingRect[0].x + settingRect[0].w / 2.0f - centroSize / 2.0f,
				settingRect[0].y + settingRect[0].h / 2.0f,
				settingRect[0].x + settingRect[0].w / 2.0f + centroSize / 2.0f,
				settingRect[0].y + settingRect[0].h / 2.0f
			);
			SDL_RenderLine(
				win->getRenderer(),
				settingRect[0].x + settingRect[0].w / 2.0f,
				settingRect[0].y + settingRect[0].h / 2.0f - centroSize / 2.0f,
				settingRect[0].x + settingRect[0].w / 2.0f,
				settingRect[0].y + settingRect[0].h / 2.0f + centroSize / 2.0f
			);
		}
	}

	auto renderLineFrame = [this](std::vector<SDL_FPoint> points, bool* isCursoInCircle = nullptr)
		{
			float offsets[][2] = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };

			SDL_SetRenderDrawColor(win->getRenderer(), 0, 0, 0, 255);

			for (int i = 0; i < 4; ++i)
			{
				std::vector<SDL_FPoint> puntiOffset = points;
				for (auto& p : puntiOffset)
				{
					p.x += offsets[i][0];
					p.y += offsets[i][1];
				}
				SDL_RenderLines(win->getRenderer(), puntiOffset.data(), (int)puntiOffset.size());
			}

			SDL_SetRenderDrawColor(win->getRenderer(), 255, 255, 255, 255);
			SDL_RenderLines(win->getRenderer(), points.data(), static_cast<int>(points.size()));

			float radius = 5.0f;
			for (size_t i = 0; i < lazoMovingPoints.size(); ++i)
			{
				Coord point = lazoMovingPoints[i];
				if (APP::isPixelInCircle(global.cursorPosition, point, radius * 10.0f))
				{
					GRAPHICS::RenderCircle(win->getRenderer(), point.x, point.y, radius + 1.0f, { 0, 0, 0, 255 });
					GRAPHICS::RenderCircle(win->getRenderer(), point.x, point.y, radius, { 255, 255, 255, 255 });
					GRAPHICS::RenderCircle(win->getRenderer(), point.x, point.y, radius - 1.0f, { 0, 0, 0, 255 });

					if (APP::isPixelInCircle(global.cursorPosition, point, radius))
					{
						GRAPHICS::RenderFillCircle(win->getRenderer(), point.x, point.y, radius - 2.0f, { 255, 239, 0, 255 });
						if (i != 0 && isCursoInCircle) *isCursoInCircle = true;
					}
				}
			}
		};

	if (!preparationLazoCoord.empty() && !lazoMovingPoints.empty())
	{
		bool isCursorInCircle = false;
		if (preparationLazoCoord.size() > 1)
		{
			for (size_t i = 1; i < preparationLazoCoord.size(); ++i)
			{
				renderLineFrame(preparationLazoCoord, &isCursorInCircle);
			}
		}

		if (preparationLazoCoord.size() > 0 && !moving && !isCursorInCircle && !preparation)
		{
			std::vector<SDL_FPoint> points;
			points.push_back(preparationLazoCoord.back());
			points.push_back({ global.cursorPosition.x, global.cursorPosition.y });

			renderLineFrame(points);
		}
	}
}

void Selections::Update(Coord click, bool cursorMotion, bool cursorRealesed, bool returnRealesed, bool reset)
{
	if (reset)
	{
		if(selected)
		{
			moving = false;
			preparation = false;

			switch (lastType)
			{
			case Tools::SELEZIONE_RETTANGOLARE:
			{
				settingRect.clear();
				currentRectPos = -1;

				lazoCoord.clear();
				preparationLazoCoord.clear();
				lazoMovingPoints.clear();
				area.clear();
				break;
			}
			case Tools::SELEZIONE_CIRCOLARE:
			{
				settingRect.clear();
				currentRectPos = -1;

				lazoCoord.clear();
				preparationLazoCoord.clear();
				lazoMovingPoints.clear();
				area.clear();
				break;
			}
			case Tools::SELEZIONE_LAZO:
			{
				settingRect.clear();
				currentRectPos = -1;
				startCoord = { -1.0f, -1.0f };
				finalCoord = { -1.0f, -1.0f };

				preparationLazoCoord.clear();
				lazoMovingPoints.clear();
				break;
			}
			case Tools::SELEZIONE_COLORE:
				settingRect.clear();
				currentRectPos = -1;
				startCoord = { -1.0f, -1.0f };
				finalCoord = { -1.0f, -1.0f };

				rect = { 0.0f, 0.0f, 0.0f, 0.0f };

				lazoCoord.clear();
				preparationLazoCoord.clear();
				lazoMovingPoints.clear();
				break;
			}
		}
		else
		{
			settingRect.clear();
			currentRectPos = -1;
			startCoord = { -1.0f, -1.0f };
			finalCoord = { -1.0f, -1.0f };

			rect = { 0.0f, 0.0f, 0.0f, 0.0f };

			lazoCoord.clear();
			preparationLazoCoord.clear();
			lazoMovingPoints.clear();
			area.clear();
		}
	}
	else
	{
		switch (type)
		{
		case Tools::SELEZIONE_RETTANGOLARE:
		{
			UpdateRect(click, cursorMotion, cursorRealesed, returnRealesed);
			break;
		}
		case Tools::SELEZIONE_CIRCOLARE:
			UpdateRect(click, cursorMotion, cursorRealesed, returnRealesed);
			break;

		case Tools::SELEZIONE_LAZO:
			UpdateLazo(click, cursorMotion, cursorRealesed, returnRealesed);
			break;

		case Tools::SELEZIONE_COLORE:
			UpdateColor(click, cursorMotion, cursorRealesed, returnRealesed);
			break;
		}
	}
}

void Selections::UpdateRect(Coord click, bool cursorMotion, bool cursorRealesed, bool returnRealesed)
{
	static bool cornerMoving = false;
	static bool selectionMoving = false;

	static SDL_FRect initialRect = { 0,0,0,0 };
	static Coord lastMouse = { -1.0f,-1.0f };

	if (!cursorMotion && !cursorRealesed && !returnRealesed)
	{
		if (APP::isPixelInDrawAndBasic(click, global))
		{
			startCoord = click;

			if (settingRect.size() == 5)
			{
				for (int i = 1; i < 5; ++i)
				{
					if (APP::isPixelInRect(click, &settingRect[i]))
					{
						cornerMoving = true;
						currentRectPos = i;
						initialRect = settingRect[0];
						lastMouse = click;
						break;
						break;
					}
				}

				if (APP::isPixelInRect(click, &settingRect[0]) && !cornerMoving)
				{
					selectionMoving = true;
					lastMouse = click;
				}
			}
			moving = true;
			finalCoord = click;


			if (!cornerMoving && !selectionMoving)
			{
				SDL_FRect newRect = {
					startCoord.x,
					startCoord.y,
					std::abs(finalCoord.x - startCoord.x),
					std::abs(finalCoord.y - startCoord.y)
				};
				if (finalCoord.x < startCoord.x) newRect.x = finalCoord.x;
				if (finalCoord.y < startCoord.y) newRect.y = finalCoord.y;

				settingRect.clear();
				settingRect.push_back(newRect);
			}
		}
	}
	else if (cursorMotion)
	{
		if (moving && click != finalCoord)
		{
			Coord newCoord = {
				finalCoord.x * -1.0f,
				finalCoord.y * -1.0f
			};
			finalCoord = click;
			newCoord.x += finalCoord.x;
			newCoord.y += finalCoord.y;

			Coord delta = { click.x - lastMouse.x, click.y - lastMouse.y };
			lastMouse = click;

			if (!settingRect.empty())
			{
				if (!cornerMoving && !selectionMoving)
				{
					SDL_FRect newRect = {
						startCoord.x,
						startCoord.y,
						std::abs(finalCoord.x - startCoord.x),
						std::abs(finalCoord.y - startCoord.y)
					};
					if (finalCoord.x < startCoord.x) newRect.x = finalCoord.x;
					if (finalCoord.y < startCoord.y) newRect.y = finalCoord.y;

					settingRect[0] = newRect;
				}
				else if (cornerMoving)
				{
					SDL_FRect& setRect = settingRect[0];

					switch (currentRectPos)
					{
					case 1: // Alto a sinistra
						setRect.x += delta.x;
						setRect.y += delta.y;
						setRect.w -= delta.x;
						setRect.h -= delta.y;
						break;
					case 2: // Alto a destra
						setRect.y += delta.y;
						setRect.w += delta.x;
						setRect.h -= delta.y;
						break;
					case 3: // Basso a sinistra
						setRect.x += delta.x;
						setRect.w -= delta.x;
						setRect.h += delta.y;
						break;
					case 4: // Basso a destra
						setRect.w += delta.x;
						setRect.h += delta.y;
						break;
					}

					if (setRect.w < 5.0f) setRect.w = 5.0f;
					if (setRect.h < 5.0f) setRect.h = 5.0f;

					setRectCorner();
				}
				else if (selectionMoving)
				{
					for (size_t i = 0; i < settingRect.size(); ++i)
					{
						settingRect[i].x += delta.x;
						settingRect[i].y += delta.y;
					}
				}
			}
		}
	}
	else if (cursorRealesed && !moving)
	{
		startCoord = { -1.0f, -1.0f };
	}
	else if (cursorRealesed && moving)
	{
		if (!cornerMoving && !selectionMoving)
		{
			for (int i = 0; i < 4; ++i) settingRect.push_back({});
			setRectCorner();
		}
		if (cornerMoving)
		{
			currentRectPos = -1;
			cornerMoving = false;
		}
		if (selectionMoving)
		{
			selectionMoving = false;
		}
	}
	else if (returnRealesed)
	{
		if (!settingRect.empty())
		{
			lastType = type;
			cornerMoving = false;
			selectionMoving = false;
			rect = settingRect[0];
			settingRect.clear();
			selected = true;

			currentRectPos = -1;
			startCoord = { -1.0f, -1.0f };
			finalCoord = { -1.0f, -1.0f };
			lazoCoord.clear();
			preparationLazoCoord.clear();
			lazoMovingPoints.clear();
			area.clear();
		}
	}
}

void Selections::setRectCorner()
{
	if (settingRect.size() < 5) settingRect.resize(5); // evita out-of-range

	FSize size = {
		settingRect[0].w / 5.0f,
		settingRect[0].h / 5.0f
	};
	if (size.w > 40.0f) size.w = 40.0f;
	else if (size.w < 20.0f) size.w = 20.0f;
	if (size.h > 40.0f) size.h = 40.0f;
	else if (size.h < 20.0f) size.h = 20.0f;

	bool esterno = false;
	if (size.w * 3.0f > settingRect[0].w) esterno = true;
	if (size.h * 3.0f > settingRect[0].h) esterno = true;

	SDL_FRect temp = { // Alto a sinistra
		settingRect[0].x - ((esterno) ? size.w : 0.0f),
		settingRect[0].y - ((esterno) ? size.h : 0.0f),
		size.w,
		size.h
	};
	settingRect[1] = temp;

	temp = { // Alto a destra
		settingRect[0].x + settingRect[0].w - size.w + ((esterno) ? size.w : 0.0f),
		settingRect[0].y - ((esterno) ? size.h : 0.0f),
		size.w,
		size.h
	};
	settingRect[2] = temp;

	temp = { // Basso a sinistra
		settingRect[0].x - ((esterno) ? size.w : 0.0f),
		settingRect[0].y + settingRect[0].h - size.h + ((esterno) ? size.h : 0.0f),
		size.w,
		size.h
	};
	settingRect[3] = temp;

	temp = { // Basso a destra
		settingRect[0].x + settingRect[0].w - size.w + ((esterno) ? size.w : 0.0f),
		settingRect[0].y + settingRect[0].h - size.h + ((esterno) ? size.h : 0.0f),
		size.w,
		size.h
	};
	settingRect[4] = temp;
}

bool Selections::IsPixelInArea(Coord coord)
{
	Coord offset = global.win.Main.level()[global.currentLevel].moveCoord;
	float zoom = global.win.Main.level().GetZoom();

	float mapX = std::round((coord.x - offset.x) / zoom);
	float mapY = std::round((coord.y - offset.y) / zoom);

	return area.count({ mapX, mapY });
}

void Selections::SetArea()
{
	if (lazoCoord.empty()) return;

	area.clear();
	Coord offset = global.win.Main.level()[global.currentLevel].moveCoord;
	float zoom = global.win.Main.level().GetZoom();

	int mapXStart = static_cast<int>(std::floor((rect.x - offset.x) / zoom)); //floor -> arrotondamento per difetto
	int mapYStart = static_cast<int>(std::floor((rect.y - offset.y) / zoom));
	int mapXEnd = static_cast<int>(std::ceil((rect.x + rect.w - offset.x) / zoom)); //ceil -> arrotondamento per eccesso
	int mapYEnd = static_cast<int>(std::ceil((rect.y + rect.h - offset.y) / zoom));

	for (int my = mapYStart; my <= mapYEnd; ++my) 
	{
		for (int mx = mapXStart; mx <= mapXEnd; ++mx) 
		{
			float screenX = (mx + 0.5f) * zoom + offset.x;
			float screenY = (my + 0.5f) * zoom + offset.y;

			bool inside = false;

			for (size_t i = 0, j = lazoCoord.size() - 1; i < lazoCoord.size(); j = i++) 
			{
				if (((lazoCoord[i].y > screenY) != (lazoCoord[j].y > screenY)) &&
					(screenX < (lazoCoord[j].x - lazoCoord[i].x) * (screenY - lazoCoord[i].y) / (lazoCoord[j].y - lazoCoord[i].y) + lazoCoord[i].x)) {
					inside = !inside;
				}
			}

			if (inside) 
			{
				area.insert({ (float)mx, (float)my });
			}
		}
	}
}

void Selections::UpdateLazo(Coord clickCoord, bool cursorMotion, bool cursorRealesed, bool returnRealesed)
{
	SDL_FPoint click = { clickCoord.x, clickCoord.y };
	static int posLazo = -1;
	static int posCentro = -1;

	if (!cursorMotion && !cursorRealesed && !returnRealesed)
	{
		if (APP::isPixelInDrawAndBasic(clickCoord, global))
		{
			posLazo = -1;
			posCentro = -1;
			moving = true;

			if (preparationLazoCoord.empty())
			{
				startCoord = clickCoord;
				preparationLazoCoord.push_back({ startCoord.x, startCoord.y });
				lazoMovingPoints.push_back(startCoord);
			}
			else
			{
				for (size_t j = 0; j < lazoMovingPoints.size(); ++j)
				{
					if (APP::isPixelInCircle(clickCoord, lazoMovingPoints[j], 8.0f))
					{
						if (j == 0 && !preparation)
						{
							preparationLazoCoord.push_back(preparationLazoCoord.front());
							preparation = true;
							moving = false;
							return;
						}

						posCentro = static_cast<int>(j);
						for (size_t i = 0; i < preparationLazoCoord.size(); ++i)
						{
							if (preparationLazoCoord[i].x == lazoMovingPoints[j].x && preparationLazoCoord[i].y == lazoMovingPoints[j].y) {
								posLazo = static_cast<int>(i);
								break;
							}
						}
						return;
					}
				}

				if (!preparation)
				{
					preparationLazoCoord.push_back(click);

					if (posLazo == -1)
					{
						lazoMovingPoints.push_back(clickCoord);
					}
				}
			}
		}
	}
	else if (cursorMotion && moving) 
	{
		if (posLazo > -1 && posCentro > -1)
		{
			lazoMovingPoints[posCentro] = clickCoord;
			preparationLazoCoord[posLazo] = click;
			if (posLazo == 0 && preparation) preparationLazoCoord.back() = click;
		}
		else if (!preparation)
		{
			if (preparationLazoCoord.empty() || (preparationLazoCoord.back().x != click.x || preparationLazoCoord.back().y != click.y))
			{
				preparationLazoCoord.push_back(click);
			}
		}
	}
	else if (cursorRealesed) 
	{
		if (moving && posLazo == -1 && !preparationLazoCoord.empty() && !preparation)
		{
			lazoMovingPoints.push_back(clickCoord);
		}

		moving = false;
		posLazo = -1;
		posCentro = -1;
	}
	else if (returnRealesed)
	{
		lastType = type;

		selected = true;
		moving = false;
		preparation = false;
		settingRect.clear();
		currentRectPos = -1;
		startCoord = { -1.0f, -1.0f };
		finalCoord = { -1.0f, -1.0f };
		rect = { 0.0f, 0.0f, 0.0f, 0.0f };

		lazoCoord.clear();
		lazoCoord = preparationLazoCoord;
		preparationLazoCoord.clear();

		lazoMovingPoints.clear();

		Coord max = {
			lazoCoord[0].x,
			lazoCoord[0].y
		};
		Coord min = {
			lazoCoord[0].x,
			lazoCoord[0].y
		};

		for (const auto& pixel : lazoCoord)
		{
			if (pixel.x > max.x) max.x = pixel.x;
			if (pixel.y > max.y) max.y = pixel.y;
			if (pixel.x < min.x) min.x = pixel.x;
			if (pixel.y < min.y) min.y = pixel.y;
		}

		rect = {
			min.x,
			min.y,
			max.x - min.x,
			max.y - min.y
		};

		SetArea();
	}
}

void Selections::UpdateColor(Coord click, bool cursorMotion, bool cursorRealesed, bool returnRealesed)
{
	if (!cursorMotion && !cursorRealesed && !returnRealesed)
	{
		if (APP::isPixelInDrawAndBasic(click, global))
		{
			if (selected)
			{
				selected = false;
				Update({ 0.0f, 0.0f }, false, false, false, true);
				lastType = Tools::SELEZIONE_COLORE;
			}

			std::vector<std::vector<ColorRgb>>& map = global.win.Main.level()[global.currentLevel].map;
			Coord offset = global.win.Main.level()[global.currentLevel].moveCoord;
			float zoom = global.win.Main.level().GetZoom();

			Coord mapCoord = {
				(click.x - offset.x) / zoom,
				(click.y - offset.y) / zoom
			};

			ColorRgb target = map[static_cast<size_t>(mapCoord.y)][static_cast<size_t>(mapCoord.x)];
			float& error = global.win.Main.GetTools().setting.colorSelection.error;

			area.clear();
			for (size_t y = 0; y < map.size(); ++y)
			{
				for (size_t x = 0; x < map[y].size(); ++x)
				{
					ColorRgb& color = map[y][x];
					if ((color.r >= target.r - error && color.r <= target.r + error) &&
						(color.g >= target.g - error && color.g <= target.g + error) &&
						(color.b >= target.b - error && color.b <= target.b + error) &&
						(color.a >= target.a - error && color.a <= target.a + error))
					{
						area.insert({ static_cast<float>(x), static_cast<float>(y) });
					}
				}
			}

			edge = createEdgeAreaTexture();

			selected = true;

			Coord max = {
				-1.0f, 
				-1.0f
			};
			Coord min = {
				1000000.0f,
				1000000.0f
			};

			for (const auto& pixel : area)
			{
				if (pixel.x > max.x) max.x = pixel.x;
				if (pixel.y > max.y) max.y = pixel.y;
				if (pixel.x < min.x) min.x = pixel.x;
				if (pixel.y < min.y) min.y = pixel.y;
			}

			rect = {
				offset.x + min.x * zoom,
				offset.y + min.y * zoom,
				(max.x - min.x) * zoom,
				(max.y - min.y) * zoom
			};
		}
	}
}

SDL_Texture* Selections::createEdgeAreaTexture()
{
	if (area.empty()) return nullptr;

	auto& mapData = global.win.Main.level()[global.currentLevel].map;
	float zoom = global.win.Main.level().GetZoom();

	// 1. Calcoliamo le dimensioni "Alta Risoluzione" basate sullo zoom attuale
	int texW = static_cast<int>(mapData[0].size() * zoom);
	int texH = static_cast<int>(mapData.size() * zoom);

	// Evitiamo texture di dimensione zero o negative che farebbero crashare SDL
	if (texW < 1 || texH < 1) return nullptr;

	SDL_Texture* texture = SDL_CreateTexture(
		win->getRenderer(),
		SDL_PIXELFORMAT_RGBA8888,
		SDL_TEXTUREACCESS_TARGET,
		texW,
		texH
	);

	if (!texture) return nullptr;

	// Fondamentale: abilita il blending per permettere la trasparenza
	SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);

	SDL_Texture* oldTarget = SDL_GetRenderTarget(win->getRenderer());
	SDL_SetRenderTarget(win->getRenderer(), texture);

	// 2. Pulizia: rendiamo la texture completamente trasparente
	SDL_SetRenderDrawColor(win->getRenderer(), 0, 0, 0, 0);
	SDL_RenderClear(win->getRenderer());

	// 3. Renderizziamo con lo ZOOM, ma senza l'offset della camera (offset {0,0})
	// In questo modo il disegno occupa tutto lo spazio della texture ad alta risoluzione
	GRAPHICS::RenderAreaTratteggiata(win->getRenderer(), area, color1, color2, { 0.0f, 0.0f }, zoom, static_cast<int>(mapData[0].size()), static_cast<int>(mapData.size()));

	SDL_SetRenderTarget(win->getRenderer(), oldTarget);

	return texture;
}

void Selections::SetLastType(Tools t) { lastType = t; }
Tools& Selections::GetLastType() { return lastType; }
const Tools& Selections::GetLastType() const { return lastType; }

bool& Selections::IsSelected() { return selected; }
bool Selections::IsSelected() const { return selected; }

bool& Selections::IsPreparation() { return preparation; }
bool Selections::IsPreparation() const { return preparation; }

void Selections::SetColor1(ColorRgb c) { color1 = c; }
ColorRgb& Selections::GetColor1() { return color1; }
const ColorRgb& Selections::GetColor1() const { return color1; }

void Selections::SetColor2(ColorRgb c) { color2 = c; }
ColorRgb& Selections::GetColor2() { return color2; }
const ColorRgb& Selections::GetColor2() const { return color2; }

void Selections::SetSettingRect(const std::vector<SDL_FRect>& v) { settingRect = v; }
std::vector<SDL_FRect>& Selections::GetSettingRect() { return settingRect; }
const std::vector<SDL_FRect>& Selections::GetSettingRect() const { return settingRect; }

void Selections::SetStartCoord(Coord c) { startCoord = c; }
Coord& Selections::GetStartCoord() { return startCoord; }
const Coord& Selections::GetStartCoord() const { return startCoord; }

void Selections::SetFinalCoord(Coord c) { finalCoord = c; }
Coord& Selections::GetFinalCoord() { return finalCoord; }
const Coord& Selections::GetFinalCoord() const { return finalCoord; }

void Selections::SetRect(SDL_FRect r) { rect = r; }
SDL_FRect& Selections::GetRect() { return rect; }
const SDL_FRect& Selections::GetRect() const { return rect; }

void Selections::SetLazoCoord(const std::vector<SDL_FPoint>& l) { lazoCoord = l; }
std::vector<SDL_FPoint>& Selections::GetLazoCoord() { return lazoCoord; }
const std::vector<SDL_FPoint>& Selections::GetLazoCoord() const { return lazoCoord; }

void Selections::SetPreparationLazoCoord(const std::vector<SDL_FPoint>& l) { preparationLazoCoord = l; }
std::vector<SDL_FPoint>& Selections::GetPreparationLazoCoord() { return preparationLazoCoord; }
const std::vector<SDL_FPoint>& Selections::GePreparationtLazoCoord() const { return preparationLazoCoord; }

void Selections::SetLazoMovingPoints(const std::vector<Coord>& l) { lazoMovingPoints = l; }
std::vector<Coord>& Selections::GetLazoMovingPoints() { return lazoMovingPoints; }
const std::vector<Coord>& Selections::GetLazoMovingPoints() const { return lazoMovingPoints; }

std::unordered_set<Coord>& Selections::GetArea() { return area; }
const std::unordered_set<Coord>& Selections::GetArea() const { return area; }

Tools& Selections::GetType() { return type; }
const Tools& Selections::GetType() const { return lastType; }

SDL_Texture*& Selections::getTexture() { return edge; }
