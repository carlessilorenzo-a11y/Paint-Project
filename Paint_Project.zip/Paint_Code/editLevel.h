#pragma once

#include "winTemplate.h"

class EditLevel : public Window
{
protected:
    VariabiliGlobali& global;
    rectText back;
    rectText next;
    std::vector<TextBox*> textbox;

public:
    EditLevel(VariabiliGlobali& global);

    void Update() override;
    void Draw() override;
};