#pragma once

struct VariabiliGlobali;
struct FSize;

FSize getTexSize(VariabiliGlobali& global, size_t i);
bool textureNeedUpdate(VariabiliGlobali& global, FSize tex, size_t i);
void creteNewTexture(VariabiliGlobali& global, size_t i);
void setMap(VariabiliGlobali& global);
