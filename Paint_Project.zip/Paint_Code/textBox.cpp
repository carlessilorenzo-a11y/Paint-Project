#define SDL_MAIN_HANDLED
#include "textBox.h"
#include "texture.h"
#include "graphics.h"
#include "app.h"

TextBox::TextBox(SDL_FRect rect, TypeTxtBox type, int maxSize, float minNum, float maxNum, int maxDecimali, VariabiliGlobali& global, Window* win, ColorRgb bgColor, float charSize)
    : rect(rect),
    type(type),
    maxSize(maxSize),
    minNum(minNum),
    maxNum(maxNum),
    maxDecimali(maxDecimali),
    global(global),
    win(win),
    bgColor(bgColor),
    charSize(charSize),
    startRect(rect),
    open(false),
    ERROR(false),
    text("0"),
    textureTriangle(nullptr),
    triangleUpRect({ 0,0,0,0 }),
    triangleDownRect({ 0,0,0,0 })
{
    textureTriangle = TEXTURE::getTexture(win->getTextures(), "Triangolo").texture;
}

TextBox::TextBox(SDL_FRect rect, TypeTxtBox type, int maxSize, VariabiliGlobali& global, Window* win, ColorRgb bgColor, float charSize)
    : rect(rect), type(type), maxSize(maxSize), maxNum(0), global(global), win(win), bgColor(bgColor), charSize(charSize), minNum(0), maxDecimali(0), startRect(rect), open(false), ERROR(false), text("\0"),
    textureTriangle(nullptr), triangleUpRect({ 0,0,0,0 }), triangleDownRect({ 0,0,0,0 })
{
    SDL_StartTextInput(win->getWindow());

    for (auto& texture : win->getTextures())
    {
        if (texture.name == "Triangolo")
        {
            textureTriangle = texture.texture;
            break;
        }
    }
}

TextBox::~TextBox()
{
    if (textureTriangle)
    {
        textureTriangle = nullptr;
    }
}

void TextBox::Update(bool* textIsUpdate)
{
    if (textIsUpdate != nullptr && *textIsUpdate == true)
    {
        *textIsUpdate = false;
    }

    if ((global.click.x >= rect.x && global.click.x <= rect.x + rect.w) &&
        (global.click.y >= rect.y && global.click.y <= rect.y + rect.h) && !open)
    {
        open = true;
    }
    else if ((global.click.x < rect.x || global.click.x > rect.x + rect.w) ||
        (global.click.y < rect.y || global.click.y > rect.y + rect.h) && open)
    {
        open = false;
    }

    if (type == TypeTxtBox::NUMBERS)
    {
        if ((global.click.x >= triangleUpRect.x && global.click.x <= triangleUpRect.x + triangleUpRect.w) &&
            (global.click.y >= triangleUpRect.y && global.click.y <= triangleUpRect.y + triangleUpRect.h))
        {
            if (!text.empty())
            {
                float temp = std::stof(text);
                if (temp + 1.0f <= maxNum)
                {
                    temp += 1.0f;

                    std::stringstream ss;
                    ss << std::fixed << std::setprecision(maxDecimali) << temp;
                    text = ss.str();

                    if (textIsUpdate)
                    {
                        *textIsUpdate = true;
                    }
                }
            }
            else
            {
                text = "1";

                if (textIsUpdate)
                {
                    *textIsUpdate = true;
                }
            }
        }
        else if ((global.click.x >= triangleDownRect.x && global.click.x <= triangleDownRect.x + triangleDownRect.w) &&
            (global.click.y >= triangleDownRect.y && global.click.y <= triangleDownRect.y + triangleDownRect.h))
        {
            if (!text.empty())
            {
                float temp = std::stof(text);
                if (temp - 1.0f >= minNum)
                {
                    temp -= 1.0f;

                    std::stringstream ss;
                    ss << std::fixed << std::setprecision(maxDecimali) << temp;
                    text = ss.str();

                    if (textIsUpdate)
                    {
                        *textIsUpdate = true;
                    }
                }
            }
            else
            {
                text = std::to_string(minNum);

                if (textIsUpdate)
                {
                    *textIsUpdate = true;
                }
            }
        }
    }
}

void TextBox::UpdateText(SDL_Event& event)
{
    if (open)
    {
        switch (type)
        {
        case TypeTxtBox::NUMBERS:
        {
            if (event.key.key >= '0' && event.key.key <= '9')
            {
                if (open)
                {
                    if (event.key.key == SDLK_BACKSPACE)
                    {
                        text.erase(text.end() - 1);
                    }
                    else if (text.length() < maxSize)
                    {
                        if (text == "0")
                        {
                            text.clear();
                        }

                        text.push_back(event.key.key);
                        if (std::stof(text) > maxNum)
                        {
                            text = std::to_string(maxNum);
                        }
                        else if (std::stof(text) < minNum)
                        {
                            text = std::to_string(minNum);
                        }
                    }
                }
            }
            else if (event.key.key == SDLK_KP_0 || event.key.key == SDLK_KP_1 || event.key.key == SDLK_KP_2 || event.key.key == SDLK_KP_3 || event.key.key == SDLK_KP_4 ||
                event.key.key == SDLK_KP_5 || event.key.key == SDLK_KP_6 || event.key.key == SDLK_KP_7 || event.key.key == SDLK_KP_8 || event.key.key == SDLK_KP_9)
            {
                if (open)
                {
                    char temp;
                    switch (event.key.key)
                    {
                    case SDLK_KP_0:
                        temp = '0';
                        break;
                    case SDLK_KP_1:
                        temp = '1';
                        break;
                    case SDLK_KP_2:
                        temp = '2';
                        break;
                    case SDLK_KP_3:
                        temp = '3';
                        break;
                    case SDLK_KP_4:
                        temp = '4';
                        break;
                    case SDLK_KP_5:
                        temp = '5';
                        break;
                    case SDLK_KP_6:
                        temp = '6';
                        break;
                    case SDLK_KP_7:
                        temp = '7';
                        break;
                    case SDLK_KP_8:
                        temp = '8';
                        break;
                    case SDLK_KP_9:
                        temp = '9';
                        break;
                    }

                    if (open && text.length() < maxSize)
                    {
                        if (text == "0")
                        {
                            text.clear();
                        }

                        text.push_back(temp);
                        if (std::stof(text) > maxNum)
                        {
                            text = std::to_string(maxNum);
                        }
                        else if (std::stof(text) < minNum)
                        {
                            text = std::to_string(minNum);
                        }
                    }
                }
            }
            else if (event.key.key == SDLK_BACKSPACE)
            {
                if (open && !text.empty())
                {
                    text.erase(text.end() - 1);
                }
            }
            break;
        }

        case TypeTxtBox::LETTERS:
        {
            float size = APP::GetTextWidth(text, 10, win->getTextures(), 0.5f);

            switch (event.type)
            {
            case SDL_EVENT_TEXT_INPUT:
                if (text.length() + SDL_strlen(event.text.text) <= maxSize)
                {
                    text += event.text.text;

                    float newSize = APP::GetTextWidth(text, 10, win->getTextures(), 0.5f);

                    if (newSize + rect.w / 10 >= rect.w)
                    {
                        rect.w += newSize - size;
                    }

                    size = newSize;
                }
                break;

            case SDL_EVENT_KEY_DOWN:
                if (event.key.key == SDLK_BACKSPACE)
                {
                    if (open && !text.empty())
                    {
                        text.erase(text.end() - 1);

                        float newSize = APP::GetTextWidth(text, 10, win->getTextures(), 0.5f);

                        if (newSize + rect.w / 10 >= startRect.w)
                        {
                            rect.w -= size - newSize;
                        }

                        size = newSize;
                    }
                }
                break;
            };
        }
        }
    }
}

void TextBox::Draw()
{
    ColorRgb frameColor = (!ERROR) ? ColorRgb{ 0, 0, 0, 255 } : ColorRgb{ 255, 0, 0, 255 };

    SDL_SetRenderDrawColor(win->getRenderer(), 64, 64, 64, 255);
    SDL_RenderFillRect(win->getRenderer(), &rect);
    SDL_FRect temp = { rect.x - 1, rect.y - 1, rect.w + 2, rect.h + 2 };
    SDL_SetRenderDrawColor(win->getRenderer(), frameColor.r, frameColor.g, frameColor.b, frameColor.a);
    SDL_RenderRect(win->getRenderer(), &temp);

    if (textureTriangle && type == TypeTxtBox::NUMBERS)
    {
        float size = 0.8f;
        triangleUpRect = { rect.x + rect.w + 1, rect.y, rect.h / 2, rect.h / 2 };
        temp = { static_cast<float>(triangleUpRect.x + (triangleUpRect.w - triangleUpRect.w * size) / 2),
            static_cast<float>(triangleUpRect.y + (triangleUpRect.h - triangleUpRect.h * size) / 2),
            static_cast<float>(triangleUpRect.w * size),
            static_cast<float>(triangleUpRect.h * size) };
        SDL_RenderTexture(win->getRenderer(), textureTriangle, NULL, &temp);

        triangleDownRect = { rect.x + rect.w + 1, rect.y + rect.h / 2, rect.h / 2, rect.h / 2 };
        temp = { static_cast<float>(triangleDownRect.x + (triangleDownRect.w - triangleDownRect.w * size) / 2),
            static_cast<float>(triangleDownRect.y + (triangleDownRect.h - triangleDownRect.h * size) / 2),
            static_cast<float>(triangleDownRect.w * size),
            static_cast<float>(triangleDownRect.h * size) };
        SDL_RenderTextureRotated(win->getRenderer(), textureTriangle, nullptr, &temp,
            180.0, nullptr, SDL_FLIP_NONE);
    }

    SDL_SetRenderDrawColor(win->getRenderer(), frameColor.r, frameColor.g, frameColor.b, frameColor.a);
    temp = { triangleUpRect.x - 1, triangleUpRect.y - 1, triangleUpRect.w + 2, triangleUpRect.h + triangleDownRect.h + 2 };
    SDL_RenderRect(win->getRenderer(), &temp);
    SDL_RenderLine(win->getRenderer(), temp.x, temp.y + temp.h / 2, temp.x + temp.w - 1, temp.y + temp.h / 2);

    if (open)
    {
        SDL_SetRenderDrawColor(win->getRenderer(), frameColor.r, frameColor.g, frameColor.b, frameColor.a);
        temp = { rect.x - 2, rect.y - 2, rect.w + 4, rect.h + 4 };
        SDL_RenderRect(win->getRenderer(), &temp);

    }
    if (!text.empty())
    {
        switch (type)
        {
        case TypeTxtBox::NUMBERS:
        {
            float floatText = std::stof(text);
            if (floatText < minNum) floatText = minNum;
            else if (floatText > maxNum) floatText = maxNum;

            std::stringstream ss;
            ss << std::fixed << std::setprecision(maxDecimali) << floatText;
            std::string strText = ss.str();

            if (maxDecimali > 0)
            {
                bool stop = false;
                for (size_t i = strText.size() - 1; i > 0 && !stop; --i)
                {
                    switch (strText[i])
                    {
                    case '0':
                        strText.pop_back();
                        break;
                    case '.':
                        stop = true;
                        break;
                    case ',':
                        stop = true;
                        break;
                    }
                }
                if (stop && (strText.back() == ',' || strText.back() == '.'))
                {
                    strText.pop_back();
                }
            }
            else if (maxDecimali == 1)
            {
                if (strText.back() == '0')
                {
                    strText.pop_back();
                    strText.pop_back();
                }
            }

            GRAPHICS::PrintCentered(strText, &rect, charSize, win->getRenderer(), win->getTextures(), 0.1f);
            break;
        }

        case TypeTxtBox::LETTERS:
        {
            GRAPHICS::Print(text, startRect.x + startRect.w / charSize, rect.y + rect.h / 2 - charSize / 2, charSize, win->getRenderer(), win->getTextures());
            break;
        }
        }
    }
}

std::string TextBox::getText() const
{
    return text;
}

SDL_FRect TextBox::getRect() const
{
    SDL_FRect temp = { rect.x, rect.y, rect.w + triangleUpRect.w + 3, rect.h + triangleUpRect.h + 2 };
    return temp;
}
void TextBox::setRect(SDL_FRect newRect) { rect = newRect; }

bool TextBox::getERROR() const
{
    return ERROR;
}

void TextBox::setText(std::string newText)
{
    text = newText;
}

void TextBox::setERROR(bool newERROR)
{
    ERROR = newERROR;
}