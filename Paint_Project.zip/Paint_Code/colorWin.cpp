#define SDL_MAIN_HANDLED
#include "colorWin.h"
#include "graphics.h"
#include "set.h"
#include "app.h"

Color::Color(VariabiliGlobali& global) :
    global(global),
    colorPP(true),
    interfaccia(ColorInterfaccia::RGBHSV),
    staticRect{ 0.0f, 0.0f, 0.0f, 0.0f },
    baseRect{ 0.0f, 0.0f, 0.0f, 0.0f },
    avanzatoRect{ 0.0f, 0.0f, 0.0f, 0.0f },
    continueRect{ 0.0f, 0.0f, 0.0f, 0.0f },
    rectLastColor{ 0.0f, 0.0f, 0.0f, 0.0f },
    rectNewColor{ 0.0f, 0.0f, 0.0f, 0.0f },
    finalColor{ 0, 0, 0, 255 },
    interfaccia_RGB(global, continueRect, rectNewColor, finalColor, colorPP),
    interfaccia_RGBHSV(global, staticRect, continueRect, finalColor, colorPP)
{}

void Color::Set()
{
    switch (interfaccia) //Devo settare continueRect
    {
    case ColorInterfaccia::RGB:
        SET::alphaLevel(global);
        break;

    case ColorInterfaccia::RGBHSV:
        interfaccia_RGBHSV.Set();
        break;
    }

    SDL_FRect rectCerchio = interfaccia_RGBHSV.GetRectCerchio();
    staticRect = {
        rectCerchio.x - rectCerchio.w * 0.1f / 2.0f,
        rectCerchio.y - rectCerchio.h * 0.1f / 2.0f,
        rectCerchio.w * 1.1f,
        rectCerchio.h * 1.1f
    };
    interfaccia_RGBHSV.GetStaticRect() = staticRect;

    continueRect = {
        global.win.color.getSize().w / 6.0f * 4.7f,
        global.win.color.getSize().h / 15.0f * 13.5f,
        global.win.color.getSize().w / 5.75f,
        global.win.color.getSize().h / 21.0f
    };

    float h = 16.0f;
    baseRect = {
        staticRect.x,
        staticRect.y - h,
        APP::GetTextWidth("Base", h, global.win.color.getTextures(), 0.05f),
        h
    };

    avanzatoRect = {
        baseRect.x + baseRect.w,
        baseRect.y,
        APP::GetTextWidth("Avanzato", h, global.win.color.getTextures(), 0.05f),
        h
    };

    rectNewColor = {
        rectCerchio.x + rectCerchio.w / 2.0f,
        (global.win.color.getSize().h - (rectCerchio.y + rectCerchio.h)) / 2.0f + rectCerchio.h + rectCerchio.y - rectCerchio.h / 15.0f,
        rectCerchio.w / 2.0f,
        rectCerchio.h / 12.0f
    };
    rectLastColor = rectNewColor;
    rectLastColor.y += rectNewColor.h;
}

void Color::Update()
{
    switch (interfaccia)
    {
    case ColorInterfaccia::RGB:
        interfaccia_RGB.Update();
        break;

    case ColorInterfaccia::RGBHSV:
        interfaccia_RGBHSV.Update();
        break;
    }

    if (APP::isPixelInRect(global.click, &baseRect) && interfaccia != ColorInterfaccia::RGB)
    {
        interfaccia = ColorInterfaccia::RGB;
        Set();
    }
    else if(APP::isPixelInRect(global.click, &avanzatoRect) && interfaccia != ColorInterfaccia::RGBHSV)
    {
        interfaccia = ColorInterfaccia::RGBHSV;
        Set();
    }
}

void Color::Draw()
{
    switch (interfaccia)
    {
    case ColorInterfaccia::RGB:
        interfaccia_RGB.Draw();
        break;

    case ColorInterfaccia::RGBHSV:
        interfaccia_RGBHSV.Draw();
        break;
    }
    SDL_Renderer* renderer = global.win.color.getRenderer();

    SDL_SetRenderDrawColor(renderer, 189, 189, 189, 255);
    SDL_RenderLine(renderer, staticRect.x, staticRect.y + staticRect.h, staticRect.x + staticRect.w, staticRect.y + staticRect.h);
    SDL_RenderLine(renderer, staticRect.x + staticRect.w, staticRect.y, staticRect.x + staticRect.w, staticRect.y + staticRect.h);
    SDL_RenderLine(renderer, staticRect.x, staticRect.y, staticRect.x, staticRect.y + staticRect.h);
    SDL_RenderLine(renderer, avanzatoRect.x + avanzatoRect.w, avanzatoRect.y, avanzatoRect.x + avanzatoRect.w, avanzatoRect.y + avanzatoRect.h);
    SDL_RenderLine(renderer, baseRect.x + baseRect.w, baseRect.y, baseRect.x + baseRect.w, baseRect.y + baseRect.h);
    SDL_RenderLine(renderer, avanzatoRect.x + avanzatoRect.w, avanzatoRect.y + avanzatoRect.h, staticRect.x + staticRect.w, staticRect.y);

    if (interfaccia == ColorInterfaccia::RGBHSV) SDL_SetRenderDrawColor(renderer, 128, 128, 128, 255);
    SDL_RenderLine(renderer, baseRect.x, baseRect.y, baseRect.x + baseRect.w, baseRect.y);
    SDL_RenderLine(renderer, baseRect.x, baseRect.y, staticRect.x, staticRect.y);

    SDL_SetRenderDrawColor(renderer, 189, 189, 189, 255);
    if (interfaccia == ColorInterfaccia::RGB) SDL_SetRenderDrawColor(renderer, 128, 128, 128, 255);
    SDL_RenderLine(renderer, avanzatoRect.x, avanzatoRect.y, avanzatoRect.x + avanzatoRect.w, avanzatoRect.y);
    SDL_SetRenderDrawColor(renderer, 189, 189, 189, 255);

    switch (interfaccia)
    {
    case ColorInterfaccia::RGB:
        SDL_RenderLine(renderer, baseRect.x + baseRect.w, baseRect.y + baseRect.h, avanzatoRect.x + avanzatoRect.w, avanzatoRect.y + avanzatoRect.h);
        break;

    case ColorInterfaccia::RGBHSV:
        SDL_RenderLine(renderer, baseRect.x + baseRect.w, baseRect.y + baseRect.h, baseRect.x, baseRect.y + baseRect.h);
        break;
    }

    SDL_FRect temp = {
        rectNewColor.x - rectNewColor.w,
        rectNewColor.y,
        rectNewColor.w,
        rectNewColor.h
    };
    ColorRgb c = finalColor;
    SDL_SetRenderDrawColor(global.win.color.getRenderer(), c.r, c.g, c.b, c.a);
    SDL_RenderFillRect(global.win.color.getRenderer(), &rectNewColor);
    SDL_SetRenderDrawColor(global.win.color.getRenderer(), 0, 0, 0, 255);
    SDL_RenderRect(global.win.color.getRenderer(), &rectNewColor);
    GRAPHICS::PrintCentered("Attuale: ", &temp, 10, global.win.color.getRenderer(), global.win.color.getTextures());

    temp = {
        rectLastColor.x - rectLastColor.w,
        rectLastColor.y,
        rectLastColor.w,
        rectLastColor.h
    };
    c = (colorPP) ? global.win.Main.GetColor_PP() : global.win.Main.GetColor_SF();
    SDL_SetRenderDrawColor(global.win.color.getRenderer(), c.r, c.g, c.b, c.a);
    SDL_RenderFillRect(global.win.color.getRenderer(), &rectLastColor);
    SDL_SetRenderDrawColor(global.win.color.getRenderer(), 0, 0, 0, 255);
    SDL_RenderRect(global.win.color.getRenderer(), &rectLastColor);
    GRAPHICS::PrintCentered("Precedente: ", &temp, 10, global.win.color.getRenderer(), global.win.color.getTextures());

    GRAPHICS::PrintCentered(
        "Base", 
        &baseRect, 
        16.0f * 2.0f / 4.0f, 
        global.win.color.getRenderer(), 
        global.win.color.getTextures()
    );

    GRAPHICS::PrintCentered(
        "Avanzato",
        &avanzatoRect,
        16.0f * 2.0f / 4.0f,
        global.win.color.getRenderer(),
        global.win.color.getTextures()
    );

    SDL_SetRenderDrawColor(global.win.color.getRenderer(), 189, 189, 189, 255);
    SDL_RenderRect(global.win.color.getRenderer(), &continueRect);
    GRAPHICS::PrintCentered(
        "Continue",
        &continueRect,
        7.5,
        global.win.color.getRenderer(),
        global.win.color.getTextures()
    );
}

ColorInterfaccia Color::getCurrentInterfaccia() const { return interfaccia; }

bool Color::IsColorPP() const { return colorPP; }
void Color::SetIsColorPP(bool isPP) { colorPP = isPP; }

ColorRgb& Color::GetFinalColor() { return finalColor; }
const ColorRgb& Color::GetFinalColor() const { return finalColor; }
void Color::SetFinalColor(const ColorRgb& color) { finalColor = color; }

SDL_FRect& Color::GetStaticRect() { return staticRect; }
const SDL_FRect& Color::GetStaticRect() const { return staticRect; }
void Color::SetStaticRect(const SDL_FRect& rect) { staticRect = rect; }

SDL_FRect& Color::GetRectLastColor() { return rectLastColor; }
const SDL_FRect& Color::GetRectLastColor() const { return rectLastColor; }
void Color::SetRectLastColor(const SDL_FRect& newRectLastColor) { rectLastColor = newRectLastColor; }

SDL_FRect& Color::GetRectNewColor() { return rectNewColor; }
const SDL_FRect& Color::GetRectNewColor() const { return rectNewColor; }
void Color::SetRectNewColor(const SDL_FRect& newRectNewColor) { rectNewColor = newRectNewColor; }

Interfaccia_RGB& Color::getRGBinterfaccia() { return interfaccia_RGB; }
const Interfaccia_RGB& Color::getRGBinterfaccia() const { return interfaccia_RGB; }

Interfaccia_RGBHSV& Color::getRGBHSVinterfaccia() { return interfaccia_RGBHSV; }
const Interfaccia_RGBHSV& Color::getRGBHSVinterfaccia() const { return interfaccia_RGBHSV; }
