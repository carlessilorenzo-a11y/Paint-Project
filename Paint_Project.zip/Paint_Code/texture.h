#pragma once

#include "variabiliGlobali.h"

namespace TEXTURE
{
    SDL_Texture* LoadImageTexture(SDL_Renderer* renderer, const std::string& path);

    void LoadTextureSurfaces(std::vector<IconsSurface>& surfaces);

    Textures getTexture(std::vector<Textures>& textures, std::string name);

    std::vector<Textures> CreateIconsTextures(SDL_Renderer* renderer, const std::vector<IconsSurface>& surfaces);

    std::vector<std::vector<ColorRgb>> getLevelsMap(VariabiliGlobali& global);

    SDL_Texture* CreateTextureFromMap(SDL_Renderer* renderer, const std::vector<std::vector<ColorRgb>>& map);
}