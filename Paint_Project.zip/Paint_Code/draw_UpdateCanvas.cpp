#define SDL_MAIN_HANDLED
#include "draw_UpdateCanvas.h"
#include "variabiliGlobali.h"

FSize getTexSize(VariabiliGlobali& global, size_t i)
{
    FSize tex = { 0.0f, 0.0f };

    if (global.win.Main.level()[i].canvas)
    {
        SDL_GetTextureSize(global.win.Main.level()[i].canvas, &tex.w, &tex.h);
    }

    return tex;
}

bool textureNeedUpdate(VariabiliGlobali& global, FSize tex, size_t i)
{
    return !global.win.Main.level()[i].canvas ||
        tex.w != static_cast<float>(global.win.Main.level()[i].size.w) ||
        tex.h != static_cast<float>(global.win.Main.level()[i].size.h);
}

void creteNewTexture(VariabiliGlobali& global, size_t i)
{
    if (global.win.Main.level()[i].canvas)
        SDL_DestroyTexture(global.win.Main.level()[i].canvas);

    global.win.Main.level()[i].canvas = SDL_CreateTexture(
        global.win.Main.getRenderer(),
        SDL_PIXELFORMAT_RGBA8888,
        SDL_TEXTUREACCESS_STREAMING,
        static_cast<int>(global.win.Main.level()[i].size.w),
        static_cast<int>(global.win.Main.level()[i].size.h)
    );

    if (!global.win.Main.level()[i].canvas)
    {
        SDL_Log("Errore nella creazione della canvas: %s", SDL_GetError());
        return;
    }

    global.win.Main.level()[i].needsUpdate = true;
}

void setMap(VariabiliGlobali& global)
{
    void* pixels = nullptr;
    int pitch = 0;
    if (!SDL_LockTexture(global.win.Main.level()[global.currentLevel].canvas, nullptr, &pixels, &pitch))
    {
        SDL_Log("Errore nel lock della canvas: %s", SDL_GetError());
        return;
    }

    uint32_t* buf = static_cast<uint32_t*>(pixels);

    for (size_t y = 0; y < global.win.Main.level()[global.currentLevel].map.size(); ++y)
    {
        for (size_t x = 0; x < global.win.Main.level()[global.currentLevel].map[y].size(); ++x)
        {
            if (y >= static_cast<size_t>(global.win.Main.level()[global.currentLevel].size.h) || x >= static_cast<size_t>(global.win.Main.level()[global.currentLevel].size.w))
                continue;

            const ColorRgb& cell = global.win.Main.level()[global.currentLevel].map[y][x];
            uint8_t r = cell.r;
            uint8_t g = cell.g;
            uint8_t b = cell.b;
            uint8_t a = cell.a;

            buf[y * (pitch / 4) + x] = (r << 24) | (g << 16) | (b << 8) | a;
        }
    }
}
