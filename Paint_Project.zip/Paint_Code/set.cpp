#define SDL_MAIN_HANDLED
#include "set.h"
#include "slider.h"
#include "app.h"

namespace SET
{
    void menuFile(VariabiliGlobali& global)
    {
        SDL_FRect fileRect = { 0, 0, static_cast<float>(global.win.Main.getSize().w / 15.0f), static_cast<float>(global.win.Main.getSize().h / 40.0f) };
        std::vector<rectBool>& mainMenu = global.win.Main.GetMainMenuRect();

        mainMenu.clear();
        global.win.Main.GetMenuFile().clear();
        std::vector<std::string> text = { "New", "Save", "Save as", "Load" };
        std::vector<MenuFileType> type1 = { MenuFileType::New, MenuFileType::Save, MenuFileType::SaveAs, MenuFileType::Load };
        if (text.size() != type1.size()) return;

        Size dim = {
            global.win.Main.getSize().w / 12,
            global.win.Main.getSize().h / 50
        };

        mainMenu.push_back({ fileRect, false });

        for (int i = 0; i < text.size(); ++i)
        {
            MenuFile temp;
            temp.type = type1[i];
            temp.open = false;
            temp.rect = {
                0,
                fileRect.h * (i + 1),
                static_cast<float>(dim.w),
                static_cast<float>(dim.h)
            };
            temp.text = text[i];

            global.win.Main.GetMenuFile().push_back(temp);
        }

        global.win.Main.GetMenuProject().clear();
        text = { "Save", "Save as", "Load" };
        std::vector<MenuProjectType> type2 = { MenuProjectType::Save, MenuProjectType::SaveAs, MenuProjectType::Load };
        if (text.size() != type2.size()) return;

        mainMenu.push_back(
            {
                {
                    fileRect.x + fileRect.w,
                    fileRect.y,
                    fileRect.w / 5.0f * 7.0f, // rapporto tra le lettere di 'level' e 'project'
                    fileRect.h
                },
                false
            }
        );

        for (int i = 0; i < text.size(); ++i)
        {
            MenuProject temp;
            temp.type = type2[i];
            temp.open = false;
            temp.rect = {
                mainMenu[1].rect.x + (mainMenu[1].rect.w - static_cast<float>(dim.w * 2.0f)) / 2.0f,
                fileRect.h * (i + 1),
                static_cast<float>(dim.w * 2.0f),
                static_cast<float>(dim.h)
            };
            temp.text = text[i];

            global.win.Main.GetMenuProject().push_back(temp);
        }


        global.win.Main.GetMenuEdit().clear();
        text = { "Undo", "Redo", "Copy", "Paste", "Paste in place", "Fill with PP color", "Fill with SF color" };
        std::vector<MenuEditType> type3 = { MenuEditType::Undo, MenuEditType::Redo, MenuEditType::Copy, MenuEditType::Paste, MenuEditType::PasteInPlace, 
            MenuEditType::RiempiConPP, MenuEditType::RiempiConSF };
        if (text.size() != type3.size()) return;

        mainMenu.push_back(
            {
                {
                    mainMenu[1].rect.x + mainMenu[1].rect.w,
                    fileRect.y,
                    fileRect.w / 5.0f * 4.0f, // rapporto tra le lettere di 'level' e 'edit'
                    fileRect.h
                },
                false
            }
        );

        for (int i = 0; i < text.size(); ++i)
        {
            MenuEdit temp;
            temp.type = type3[i];
            temp.open = false;
            temp.rect = {
                mainMenu[2].rect.x + (mainMenu[2].rect.w - static_cast<float>(dim.w * 2.0f)) / 2.0f,
                fileRect.h * (i + 1),
                static_cast<float>(dim.w * 2.0f),
                static_cast<float>(dim.h)
            };
            temp.text = text[i];

            global.win.Main.GetMenuEdit().push_back(temp);
        }


        global.win.Main.GetMenuSelection().clear();
        text = { "All", "Nothing", "Invert", "New Level" };
        std::vector<MenuSelectionType> type4 = { MenuSelectionType::All, MenuSelectionType::Nothing, MenuSelectionType::Invert, MenuSelectionType::NewLevel };
        if (text.size() != type4.size()) return;

        mainMenu.push_back(
            {
                {
                    mainMenu[2].rect.x + mainMenu[2].rect.w,
                    fileRect.y,
                    fileRect.w / 5.0f * 9.0f, // rapporto tra le lettere di 'level' e 'selection'
                    fileRect.h
                },
                false
            }
        );

        for (int i = 0; i < text.size(); ++i)
        {
            MenuSelection temp;
            temp.type = type4[i];
            temp.open = false;
            temp.rect = {
                mainMenu[3].rect.x + (mainMenu[3].rect.w - static_cast<float>(dim.w * 2.0f)) / 2.0f,
                fileRect.h * (i + 1),
                static_cast<float>(dim.w * 2.0f),
                static_cast<float>(dim.h)
            };
            temp.text = text[i];

            global.win.Main.GetMenuSelection().push_back(temp);
        }
    }

    void menuTools(VariabiliGlobali& global)
    {
        int w, h;
        SDL_GetWindowSize(global.win.Main.getWindow(), &w, &h);

        std::vector<std::string> str = { "MOVE", "PENNELLO", "GOMMA", "BUCKET", "PIPETTA", "selezioneRettangolare", "selezioneCircolare", "selezioneLazo", "selezioneColore" };
        MenuFile tempRect{};
        float tempRectW = static_cast<float>(w / 100.0f + h / 100.0f);
        float sommaW = 0;

        global.win.Main.GetTools().menuFile.clear();

        for (size_t i = 0; i < str.size(); ++i)
        {
            if (i <= 4)
            {
                tempRect.rect = {
                    static_cast<float>(w / 30 + ((tempRectW + 20) * i)),
                    static_cast<float>(h / 10 * 2),
                    tempRectW,
                    tempRectW
                };
            }
            else if (i > 4 && i <= 9)
            {
                tempRect.rect = {
                    static_cast<float>(w / 30.0f + ((tempRectW + 20.0f) * (i - 5))),
                    static_cast<float>(h / 10.0f * 2.0f + tempRectW * 1.5f),
                    tempRectW,
                    tempRectW
                };
            }

            tempRect.text = str[i];

            global.win.Main.GetTools().menuFile.push_back(tempRect);
        }
        sommaW = global.win.Main.GetTools().menuFile[4].rect.x + global.win.Main.GetTools().menuFile[4].rect.w - global.win.Main.GetTools().menuFile[0].rect.x;

        SDL_FRect colorRect_PP = {
            global.win.Main.GetTools().menuFile[0].rect.x + sommaW / 2.0f - global.win.Main.GetTools().menuFile[0].rect.w / 2,
            global.win.Main.GetTools().menuFile[0].rect.y - (global.win.Main.GetTools().menuFile[0].rect.h * 2.5f),
            global.win.Main.GetTools().menuFile[0].rect.w,
            global.win.Main.GetTools().menuFile[0].rect.h
        };
        SDL_FRect colorRect_SF = colorRect_PP;

        float rapporto = 0.7f;
        colorRect_PP = {
            colorRect_PP.x - (colorRect_PP.w - colorRect_PP.w * rapporto),
            colorRect_PP.y - (colorRect_PP.w - colorRect_PP.h * rapporto),
            colorRect_PP.w,
            colorRect_PP.h
        };

        colorRect_SF = {
            colorRect_SF.x + (colorRect_SF.w - colorRect_SF.w * rapporto),
            colorRect_SF.y + (colorRect_SF.h - colorRect_SF.h * rapporto),
            colorRect_SF.w,
            colorRect_SF.h
        };

        global.win.Main.SetColorRect_PP(colorRect_PP);
        global.win.Main.SetColorRect_SF(colorRect_SF);

        Coord intersection = { colorRect_PP.x + colorRect_PP.w, colorRect_SF.y };
        float texSize = (intersection.y - colorRect_PP.y) / 1.5f;

        SDL_FRect texRect = {
            intersection.x + ((colorRect_SF.x + colorRect_SF.w - intersection.x) - texSize) / 2.0f,
            intersection.y - ((colorRect_PP.y + colorRect_PP.h * 2.0f - intersection.y) - texSize) / 2.0f,
            texSize,
            texSize
        };

        global.win.Main.SetFrecciaRect(texRect);

        SDL_FRect levelRect = {
            tempRect.rect.x = static_cast<float>(w / 10.0f * 8.69f),
            global.win.Main.GetTools().menuFile[0].rect.y + global.win.Main.GetTools().menuFile[0].rect.h * 3,
            sommaW,
            static_cast<float>(h - global.win.Main.GetTools().menuFile[0].rect.y + global.win.Main.GetTools().menuFile[0].rect.h * 3.0f) * 0.65f
        };
        float centrerX = (levelRect.x + levelRect.w) / 2.0f;
        levelRect.w *= 1.3f;
        levelRect.x -= (levelRect.w - sommaW) / 2.0f;
        global.win.Main.SetLevelRect(levelRect);

        SDL_FRect rectGestioneTools = {
            global.win.Main.GetTools().menuFile[0].rect.x,
            global.win.Main.GetTools().menuFile.back().rect.y + global.win.Main.GetTools().menuFile.back().rect.h * 2.0f,
            sommaW,
        };
        rectGestioneTools.h = global.win.Main.getSize().h - rectGestioneTools.y;
        rectGestioneTools.h *= 0.8f;
        global.win.Main.SetRectGestioneTools(rectGestioneTools);

        global.win.Main.level().GetBasicSize().w = static_cast<int>(global.win.Main.getSize().w - (sommaW + global.win.Main.GetTools().menuFile[0].rect.x) - levelRect.w * 1.4f);
        global.win.Main.level().GetBasicSize().h = static_cast<int>(global.win.Main.getSize().h / 10 * 9);
        global.win.Main.level().GetLimitSize().w = static_cast<int>(global.win.Main.level().GetBasicSize().w / 0.4f);
        global.win.Main.level().GetLimitSize().h = static_cast<int>(global.win.Main.level().GetBasicSize().w / 0.4f);

        SDL_FRect areaDiLavoro = {
            sommaW + global.win.Main.GetTools().menuFile[0].rect.x * 2.0f,
            static_cast<float>((global.win.Main.getSize().h - global.win.Main.level().GetBasicSize().h) / 2.0f),
            static_cast<float>(global.win.Main.level().GetBasicSize().w),
            static_cast<float>(global.win.Main.level().GetBasicSize().h)
        };
        global.win.Main.SetAreaDiLavoro(areaDiLavoro);
    }

    void alphaLevel(VariabiliGlobali& global)
    {
        global.win.color.getRGBinterfaccia().SetAlphaLevelRgb(global.win.Main.GetColor_PP().a);

        SDL_FRect temp = {
            (global.win.color.GetStaticRect().x + global.win.color.GetStaticRect().w) * 1.7f,
            global.win.color.GetStaticRect().y + (global.win.color.GetStaticRect().h - 255.0f) / 2.0f,
            3,
            255
        };

        global.win.color.getRGBinterfaccia().SetAlphaLine({ temp, {255, 255, 255, 255} });
        global.win.color.getRGBinterfaccia().SetAlphaCircle(GRAPHICS::createCircle(temp.x + 1, temp.y, 12, { 230, 230, 230, 255 }, { 0, 0, 0, 255 }));

        int letterSize = global.win.color.getRGBinterfaccia().GetLetterSize();
        SDL_FRect& staticRect = global.win.color.GetStaticRect();
        float cellW = static_cast<float>(staticRect.w / letterSize);
        std::vector<std::vector<rectColored>>& colorMap = global.win.color.getRGBinterfaccia().GetColorMap();
        std::vector<std::vector<bool>>& rectSelected = global.win.color.getRGBinterfaccia().GetRectSelected();

        colorMap.clear();
        colorMap.resize(global.win.color.getRGBinterfaccia().GetLetterSize());
        rectSelected.clear();
        rectSelected.resize(global.win.color.getRGBinterfaccia().GetLetterSize());

        for (size_t j = 0; j < letterSize; j++)
        {
            colorMap[j].clear();
            rectSelected[j].clear();
            for (size_t i = 0; i < letterSize; i++)
            {
                float x1 = staticRect.x + i * cellW;
                float y1 = staticRect.y + j * cellW;
                float x2 = staticRect.x + (i + 1) * cellW;
                float y2 = staticRect.y + (j + 1) * cellW;

                rectColored temp;
                temp.rect = { x1, y1, x2 - x1, y2 - y1 };
                temp.color = static_cast<ColorType>(i);

                colorMap[j].push_back(temp);
                rectSelected[j].push_back(false);
            }
        }

        SDL_Renderer* rendererMain = global.win.Main.getRenderer();
        SDL_Renderer* rendererColor = global.win.color.getRenderer();
        SDL_Texture* texSorgente = global.win.Main.level().GetAlphaGrid();

        if (texSorgente)
        {
            SDL_SetRenderTarget(rendererMain, texSorgente);

            // 2. PULISCI la texture (altrimenti leggi i disegni vecchi del Main!)
            SDL_SetRenderDrawColor(rendererMain, 0, 0, 0, 0);
            SDL_RenderClear(rendererMain);

            // 3. DISEGNA esplicitamente la texture su se stessa nel contesto del Main
            // Questo assicura che il buffer contenga SOLO i dati della texture
            SDL_RenderTexture(rendererMain, texSorgente, NULL, NULL);

            // 4. ORA scatta la "foto" (Surface) dal buffer pulito del Main
            SDL_Surface* surfaceTemporanea = SDL_RenderReadPixels(rendererMain, NULL);

            // 5. Ripristina il target del Main (molto importante!)
            SDL_SetRenderTarget(rendererMain, NULL);

            if (surfaceTemporanea) {
                // 6. Crea la nuova texture nel "mondo" del renderer Color
                SDL_Texture* finalTex = SDL_CreateTextureFromSurface(rendererColor, surfaceTemporanea);
                global.win.color.getRGBinterfaccia().GetAlphaGrid() = finalTex;

                SDL_DestroySurface(surfaceTemporanea);
            }
        }
        else
        {
            SDL_Log("texture non disponibile");
        }
    }

    void newTextBox(VariabiliGlobali& global, bool level)
    {
        float sizeFont = 20;

        global.win.setNew.SetIsLevel(level);

        SDL_GetWindowSize(global.win.setNew.getWindow(), &global.win.setNew.getSize().w, &global.win.setNew.getSize().h);

        global.win.setNew.GetBack().text = "Back";
        global.win.setNew.SetWBack(static_cast<float>(10 * global.win.setNew.GetBack().text.length() + 10));
        float hBack = sizeFont + 6;
        global.win.setNew.GetBack().rect = {
            static_cast<float>(global.win.setNew.getSize().w) / 10,
            static_cast<float>(global.win.setNew.getSize().h) / 10 * 9 - hBack,
            global.win.setNew.GetWBack(),
            hBack
        };

        global.win.setNew.GetNext().text = "Next";
        float wNext = static_cast<float>(10 * global.win.setNew.GetNext().text.length() + 10);
        float hNext = sizeFont + 6;
        global.win.setNew.GetNext().rect = {
            static_cast<float>(global.win.setNew.getSize().w) / 10 * 9 - wNext,
            static_cast<float>(global.win.setNew.getSize().h) / 10 * 9 - hNext,
            wNext,
            hNext
        };

        MenuFile TavolaColori;
        TavolaColori.rect = {
            static_cast<float>(global.win.setNew.getSize().w) / 10 + global.win.setNew.GetStrTavolaColori().length() * 10 + 10,
            static_cast<float>(global.win.setNew.getSize().h) / 10 * 5 - 8,
            global.win.setNew.GetWBack(),
            hBack
        };

        global.win.Main.SetRectTavolaColori(TavolaColori.rect);
        SDL_FRect temp;
        ColorRgb tempColor;
        tempColor = { 64, 64, 64, 255 };
        temp = {
            static_cast<float>(global.win.setNew.getSize().w) / 10 + 21,
            static_cast<float>(global.win.setNew.getSize().h) / 10 * 2 - 8,
            global.win.setNew.GetWBack() - 10,
            global.win.setNew.GetBack().rect.h
        };
        global.win.setNew.GetTextbox().push_back(
            new TextBox(
                temp,
                TypeTxtBox::NUMBERS,
                4,
                0.0f,
                static_cast<float>(global.win.Main.level().GetLimitSize().h),
                0,
                global,
                &global.win.setNew,
                tempColor
            )
        );
        temp = {
            static_cast<float>(global.win.setNew.getSize().w) / 10 + 21,
            static_cast<float>(global.win.setNew.getSize().h) / 10 * 3 - 8,
            global.win.setNew.GetWBack() - 10,
            global.win.setNew.GetBack().rect.h
        };
        global.win.setNew.GetTextbox().push_back(
            new TextBox(
                temp,
                TypeTxtBox::NUMBERS,
                4,
                0.0f,
                static_cast<float>(global.win.Main.level().GetLimitSize().h),
                0,
                global,
                &global.win.setNew,
                tempColor)
        );
    }

    void saveWindow(VariabiliGlobali& global)
    {
        int sizeFont = 10;

        global.win.save.GetBack().text = "Back";
        float wBack = static_cast<float>(10 * global.win.save.GetBack().text.length() + 10);
        float hBack = static_cast<float>(sizeFont + 6);
        global.win.save.GetBack().rect = {
            static_cast<float>(global.win.save.getSize().w) / 10,
            static_cast<float>(global.win.save.getSize().h) / 10 * 9 - hBack,
            wBack,
            hBack
        };

        global.win.save.GetNext().text = "Next";
        float wNext = static_cast<float>(10 * global.win.save.GetNext().text.length() + 10);
        float hNext = static_cast<float>(sizeFont + 6);
        global.win.save.GetNext().rect = {
            static_cast<float>(global.win.save.getSize().w) / 10 * 9 - wNext,
            static_cast<float>(global.win.save.getSize().h) / 10 * 9 - hNext,
            wNext,
            hNext
        };

        bool project = global.win.save.IsProject();

        SDL_FRect temp;
        if (!project)
        {
            temp = {
                static_cast<float>(global.win.save.getSize().h / 13),
                static_cast<float>(global.win.save.getSize().h / 6),
                static_cast<float>(global.win.save.getSize().w / 8),
                static_cast<float>(global.win.save.getSize().h / 14)
            };
        }
        else
        {
            temp = {
               static_cast<float>(global.win.save.getSize().h / 13),
               static_cast<float>(global.win.save.getSize().h / 4),
               static_cast<float>(global.win.save.getSize().w / 8),
               static_cast<float>(global.win.save.getSize().h / 7)
            };
        }


        global.win.save.SetTextbox(
            new TextBox(
                temp,
                TypeTxtBox::LETTERS,
                20,
                global,
                &global.win.save,
                { 64, 64, 64, 255 }
            )
        );

        global.win.save.GetFileType().resize(2);
        for (size_t i = 0; i < global.win.save.GetFileType().size(); ++i)
        {
            global.win.save.GetFileType()[i].rect = {
                global.win.save.GetTextbox()->getRect().x,
                global.win.save.GetTextbox()->getRect().y + global.win.save.GetTextbox()->getRect().h * 2.0f + global.win.save.GetTextbox()->getRect().h * 1.5f * (i + 1),
                10.0f,
                10.0f
            };

            global.win.save.GetFileType()[i].type = static_cast<FileType>(i);
            global.win.save.GetFileType()[i].text = (i == 0) ? "png" : "mbp";
        }
    }

    void loadWindow(VariabiliGlobali& global)
    {
        int sizeFont = 10;
        global.win.load.SetLoadNext(false);

        bool project = global.win.load.IsProject();

        global.win.load.GetBack().text = "Back";
        float wBack = static_cast<float>(10 * global.win.load.GetBack().text.length() + 10);
        float hBack = static_cast<float>(sizeFont + 6);
        global.win.load.GetBack().rect = {
            static_cast<float>(global.win.load.getSize().w) / 10.0f,
            static_cast<float>(global.win.load.getSize().h) / 10.0f * 9.0f - hBack,
            wBack,
            hBack
        };

        global.win.load.GetNext().text = "Next";
        float wNext = static_cast<float>(10 * global.win.load.GetNext().text.length() + 10);
        float hNext = static_cast<float>(sizeFont + 6);
        global.win.load.GetNext().rect = {
            static_cast<float>(global.win.load.getSize().w) / 10.0f * 9.0f - wNext,
            static_cast<float>(global.win.load.getSize().h) / 10.0f * 9.0f - hNext,
            wNext,
            hNext
        };

        global.win.load.GetRectLoad() = {
            static_cast<float>(global.win.load.getSize().w) / 10.0f,
            static_cast<float>(global.win.load.getSize().h) / 12.5f * 1.75f,
            static_cast<float>(global.win.load.getSize().w) / 10.0f * 7.5f,
            static_cast<float>(global.win.load.getSize().h) / 3.0f
        };
        if (project)
        {
            global.win.load.GetRectLoad().y *= 1.1f;
            global.win.load.GetRectLoad().h *= 1.9f;
        }

        global.win.load.GetTexRect() = {
            global.win.load.GetRectLoad().x + global.win.load.GetRectLoad().w * 0.1f / 2.0f,
            global.win.load.GetRectLoad().y + global.win.load.GetRectLoad().h + static_cast<float>(global.win.load.getSize().h) / 15.0f,
            global.win.load.GetRectLoad().w * 0.9f,
            global.win.load.GetRectLoad().h * 0.8f
        };

        std::string cartella = (!project) ? "Disegni" : "Projects";
        std::vector<std::string> vect = APP::listaFileCartella('/' + cartella);
        global.fileCartella.resize(vect.size());
        global.fileRicerca = global.fileCartella;

        for (size_t i = 0; i < vect.size(); ++i)
        {
            global.fileCartella[i].name = vect[i];
            global.fileCartella[i].rect = {
                global.win.load.GetRectLoad().x,
                global.win.load.GetRectLoad().y + 1.0f + global.win.load.GetRectLoad().h / 8.0f * i,
                global.win.load.GetRectLoad().w,
                global.win.load.GetRectLoad().h / 8.0f - 1.0f
            };
            global.fileCartella[i].selected = false;
        }

        SDL_FRect temp = {
            static_cast<float>(global.win.load.getSize().w / 10.0f * 2.0f) + APP::GetTextWidth("Scegli il file da caricare:", 10, global.win.load.getTextures(), 0.5f),
            static_cast<float>(global.win.load.getSize().h / 15.0f),
            static_cast<float>(global.win.load.getSize().w / 10.0f * 2.0f),
            10.0f * 1.5f
        };

        global.win.load.SetTextbox(
            new TextBox(
                temp,
                TypeTxtBox::LETTERS,
                20,
                global,
                &global.win.load,
                { 64, 64, 64, 255 }
            )
        );
    }

    void levelMenu(VariabiliGlobali& global)
    {
        SDL_FRect levelRect = global.win.Main.GetLevelRect();
        float h = levelRect.h / 20;
        std::vector<std::string> names = { "add_level", "edit_level", "delete_level", "ancoraLivello" };
        global.win.Main.GetlevelMenu().clear();

        for (size_t i = 0; i < names.size(); ++i)
        {
            MenuFile rect;
            rect.rect = {
                levelRect.x + i * h,
                levelRect.y - h,
                h,
                h
            };
            rect.text = names[i];
            rect.open = false;

            global.win.Main.GetlevelMenu().push_back(rect);
        }

        SDL_FRect rect = {
            global.win.Main.GetlevelMenu()[0].rect.x + global.win.Main.GetlevelMenu()[0].rect.h / 2.0f,
            global.win.Main.GetlevelMenu()[0].rect.y - global.win.Main.GetlevelMenu()[0].rect.h,
            global.win.Main.getSize().w - rect.x - global.win.Main.GetlevelMenu()[0].rect.h / 2.0f,
            global.win.Main.GetlevelMenu()[0].rect.h / 1.5f
        };

        global.win.Main.SetOpacity(
            new Slider(
                rect,
                { 0, 0, 0, 255 },
                { 64, 64, 64, 255 },
                255.0f,
                255.0f,
                0.0f,
                false,
                &global.win.Main
            )
        );
    }

    void toolsSetting(VariabiliGlobali& global)
    {
        std::vector<SliderTextbox*>& toolsSetting = global.win.Main.GetToolsSetting();
        toolsSetting.clear();

        SDL_FRect rectGestione = global.win.Main.GetRectGestioneTools();
        float ratio = 0.8f;
        float charSize = 7.0f;

        SDL_FRect baseRect;
        baseRect.w = rectGestione.w * ratio;
        baseRect.h = baseRect.w / 10.0f;
        baseRect = {
            rectGestione.x + (rectGestione.w - baseRect.w) / 2.0f,
            rectGestione.y + baseRect.h / 2.0f,
            baseRect.w,
            baseRect.h
        };
        baseRect.x += baseRect.w / 5.0f;
        baseRect.w -= baseRect.w / 5.0f;

        ColorRgb rectColor = { 0, 0, 0, 255 };
        ColorRgb bgColor = { 64, 64, 64, 255 };

        auto getFinalRect = [baseRect](int line)
            {
                if (line < 0) line = 0;
                return SDL_FRect{
                    baseRect.x,
                    baseRect.y + (baseRect.h * 1.5f) * line + baseRect.h,
                    baseRect.w,
                    baseRect.h
                };
            };

        int numSetting = 0;
        std::vector<float*> valori;
        std::vector<float> valoriMin;
        std::vector<float> valoriMax;
        switch (global.win.Main.GetTools().current)
        {
        case Tools::NOTHING:
            break;

        case Tools::MOVE:
        {
            break;
        }

        case Tools::BRUSH:
        {
            numSetting = 1;
            valori.push_back(&global.win.Main.GetTools().setting.brush.size);
            valoriMin.push_back(1.0f);
            valoriMax.push_back(static_cast<float>(std::min(global.win.Main.level().GetBasicSize().w, global.win.Main.level().GetBasicSize().h)));
            break;
        }

        case Tools::ERASER:
        {
            numSetting = 1;
            valori.push_back(&global.win.Main.GetTools().setting.eraser.size);
            valoriMin.push_back(1.0f);
            valoriMax.push_back(static_cast<float>(std::min(global.win.Main.level().GetBasicSize().w, global.win.Main.level().GetBasicSize().h)));
            break;
        }

        case Tools::BUCKET:
        {
            numSetting = 1;
            valori.push_back(&global.win.Main.GetTools().setting.bucket.error);
            valoriMin.push_back(0.0f);
            valoriMax.push_back(255.0f);
            break;
        }

        case Tools::PIPETTE:
        {
            break;
        }

        case Tools::SELEZIONE_RETTANGOLARE:
        {
            break;
        }

        case Tools::SELEZIONE_CIRCOLARE:
        {
            break;
        }

        case Tools::SELEZIONE_LAZO:
        {
            break;
        }

        case Tools::SELEZIONE_COLORE:
        {
            numSetting = 1;
            valori.push_back(&global.win.Main.GetTools().setting.bucket.error);
            valoriMin.push_back(0.0f);
            valoriMax.push_back(255.0f);
            break;
        }
        }

        for (int i = 0; i < numSetting; ++i)
        {
            toolsSetting.push_back(
                new SliderTextbox(
                    getFinalRect(i),
                    rectColor,
                    bgColor,
                    valori[i],
                    valoriMax[i],
                    valoriMin[i],
                    0,
                    true,
                    &global.win.Main,
                    global,
                    charSize
                )
            );
        }
    }
}