#pragma once

#include "variabiliGlobali.h"

class Slider
{
private:
	SDL_FRect rect;
	ColorRgb rectColor;
	ColorRgb bgColor;
	float valore;
	float valMax;
	float valMin;
	bool cursorTriangle;
	Window* win;

	SDL_Texture* textureTriangle;
	float cursor;
	float percentuale;
	float intervallo;
	bool moving;

public:
	Slider(SDL_FRect rect, ColorRgb rectColor, ColorRgb bgColor, float valore, float valMax, float valMin, bool cursorTriangle, Window* win);
	~Slider();

	void Draw();
	void Update(Coord click, float& newVal, bool cursorInMove, bool cursorRealesed);

	
	SDL_FRect getRect() const;
	void setRect(SDL_FRect newRect);

	float getCursorPos() const;

	ColorRgb getRectColor() const;
	void setRectColor(ColorRgb color);

	float& GetValore();
	const float& GetValore() const;
	void SetValore(const float& val);
};

class TextBox;

class SliderTextbox
{
private:
	SDL_FRect rect;
	ColorRgb rectColor;
	ColorRgb bgColor;
	float* valore;
	Window* win;
	VariabiliGlobali& global;

	Slider* slider;
	TextBox* textbox;

public:
	SliderTextbox(SDL_FRect rect, ColorRgb rectColor, ColorRgb bgColor, float* valore, float valMax, float valMin, int maxDecimali, bool cursorTriangle, Window* win, VariabiliGlobali& global, float charSize = 10.0f);

	void Draw();
	void Update(Coord click, bool cursorInMove, bool cursorRealesed);

	SDL_FRect& GetRect();
	const SDL_FRect& GetRect() const;
	void SetRect(SDL_FRect newRect);
};