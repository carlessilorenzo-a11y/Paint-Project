#define SDL_MAIN_HANDLED
#include "loadWin.h"
#include "set.h"
#include "graphics.h"
#include "salvataggio.h"
#include "variabiliGlobali.h"
#include "draw_Draw.h"
#include "app.h"

Load::Load(VariabiliGlobali& global) :
    global(global),
    loadNext(false),
    project(false),
    back(),
    next(),
    rectLoad({ 0, 0, 0, 0 }),
    texRect{ 0, 0, 0, 0 },
    texScaleted{ 0, 0, 0, 0 },
    currentTex(nullptr),
    textbox(nullptr) {
}

void Load::Update()
{
    if (APP::isPixelInRect(global.click, &back.rect) && window)
    {
        Destroy();
        global.click = { -1, -1 };
        return;
    }

    std::vector<loadFiles>& files = (global.win.load.textbox->getText().empty()) ? global.fileCartella : global.fileRicerca;

    if (APP::isPixelInRect(global.click, &next.rect) && window)
    {
        for (auto& file : files)
        {
            if (file.selected)
            {
                global.doppioClick = false;
                loadNext = true;
                break;
            }
        }
    }

    for (auto& file : files)
    {
        if (APP::isPixelInRect(global.click, &file.rect) && window)
        {
            if (global.doppioClick && file.selected)
            {
                loadNext = true;
                break;
            }

            for (auto& temp : files)
            {
                temp.selected = false;
            }

            if (!file.selected)
            {
                file.selected = true;

                if (!project)
                {
                    std::string name = "Disegni/" + file.name;

                    SDL_Surface* surface = IMG_Load(name.c_str());
                    if (surface)
                    {
                        currentTex = SDL_CreateTextureFromSurface(global.win.load.getRenderer(), surface);

                        if (currentTex)
                        {
                            FSize size;
                            SDL_GetTextureSize(currentTex, &size.w, &size.h);

                            float fattore = texRect.h / size.h;
                            size.w *= fattore;
                            size.h *= fattore;

                            if (size.w > texRect.w)
                            {
                                fattore = texRect.w / size.w;
                                size.w *= fattore;
                                size.h *= fattore;
                            }

                            texScaleted = {
                                texRect.x + (texRect.w - size.w) / 2.0f,
                                texRect.y + (texRect.h - size.h) / 2.0f,
                                size.w,
                                size.h
                            };
                        }
                    }
                }
            }
            break;
        }
    }

    if (loadNext)
    {
        std::string filename;
        for (auto& file : files)
        {
            if (file.selected)
            {
                if (!project)
                {
                    global.win.Main.level().GetCurrentfile() = file.name;
                }
                filename = file.name;
                break;
            }
        }

        bool loadCompletato = false;
        if (!project)
        {
            if (SALVATAGGIO::LoadMapFromImage(global.win.Main.level()[global.currentLevel].map, "Disegni/" + filename, global.win.Main.getSize(), global.win.Main.level()[global.currentLevel].size))
            {
                global.win.Main.level()[global.currentLevel].startMap = global.win.Main.level()[global.currentLevel].map;

                global.win.Main.level()[global.currentLevel].name = global.win.Main.level().GetCurrentfile();

                float imgW = global.win.Main.level()[global.currentLevel].size.w;
                float imgH = global.win.Main.level()[global.currentLevel].size.h;

                float baseW = static_cast<float>(global.win.Main.level().GetBasicSize().w);
                float baseH = static_cast<float>(global.win.Main.level().GetBasicSize().h);

                float zoomX = baseW / imgW;
                float zoomY = baseH / imgH;

                global.win.Main.level().GetZoom() = ((zoomX < zoomY) ? zoomX : zoomY) / 1.1f;

                global.win.Main.level()[global.currentLevel].zoomSize.w = imgW * global.win.Main.level().GetZoom();
                global.win.Main.level()[global.currentLevel].zoomSize.h = imgH * global.win.Main.level().GetZoom();

                global.win.Main.level()[global.currentLevel].zoomSize.x = global.win.Main.level()[global.currentLevel].size.x + (global.win.Main.level()[global.currentLevel].size.w - global.win.Main.level()[global.currentLevel].zoomSize.w) / 2.0f;
                global.win.Main.level()[global.currentLevel].zoomSize.y = global.win.Main.level()[global.currentLevel].size.y + (global.win.Main.level()[global.currentLevel].size.h - global.win.Main.level()[global.currentLevel].zoomSize.h) / 2.0f;

                global.win.Main.level()[global.currentLevel].moveCoord = { global.win.Main.level()[global.currentLevel].zoomSize.x, global.win.Main.level()[global.currentLevel].zoomSize.y };

                global.win.Main.level().GetAlphaGridCoord() = global.win.Main.level()[global.currentLevel].moveCoord;
                global.baseLevelPos = global.currentLevel;

                loadCompletato = true;
            }
            else
            {
                loadNext = false;
            }
        }
        else
        {
            filename = "Projects/" + filename;
            if (!SALVATAGGIO::loadProjectData(filename, global))
            {
                SDL_Log("Errore nel load del progetto");
                loadNext = false;
            }
            else
            {
                loadCompletato = true;
            }
        }

        if (loadCompletato)
        {
            SET::menuTools(global);
            SET::levelMenu(global);
            global.win.Main.level().UpdateAlphaGrid();

            global.win.Main.level()[global.currentLevel].needsUpdate = true;
            global.win.Main.level().GetOpen() = true;

            global.win.Main.level()[global.currentLevel].chronology.Reset();
            APP::updateCronology(global);

            Destroy();
            global.click = { -1, -1 };
            return;
        }
    }

    if (global.win.load.textbox)
    {
        if (!global.win.load.textbox->getText().empty())
        {
            auto checkStrInStr = [](const std::string& mainStr, const std::string& str) -> bool
                {
                    if (str.empty()) return false;
                    return mainStr.find(str) != std::string::npos;
                };

            std::vector<loadFiles> temp;
            for (const auto& file : global.fileCartella)
            {
                std::string txt = APP::toLower(global.win.load.textbox->getText());
                std::string fileTxt = APP::toLower(file.name);

                if (checkStrInStr(fileTxt, txt))
                {
                    temp.push_back(file);
                }
            }

            if (temp.size() != global.fileRicerca.size())
            {
                global.fileRicerca.clear();
                global.fileRicerca = temp;

                for (size_t i = 0; i < global.fileRicerca.size(); ++i)
                {
                    global.fileRicerca[i].rect = {
                        rectLoad.x,
                        rectLoad.y + 1.0f + rectLoad.h / 8.0f * i,
                        rectLoad.w,
                        rectLoad.h / 8.0f - 1.0f
                    };
                    global.fileRicerca[i].selected = false;
                }
            }
        }

        global.win.load.textbox->Update();
    }
}

void Load::Draw()
{
    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderClear(renderer);

    for (auto& file : ((global.win.load.textbox->getText().empty()) ? global.fileCartella : global.fileRicerca))
    {
        if (file.selected)
        {
            SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
            SDL_RenderRect(renderer, &file.rect);
        }
        GRAPHICS::Print(file.name, file.rect.x + rectLoad.w / 30.0f, file.rect.y + file.rect.h / 3.0f, 10, renderer, textures, 0.35f);
    }

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_FRect temp = {
        0,
        0,
        static_cast<float>(size.w),
        rectLoad.y
    };
    SDL_RenderFillRect(renderer, &temp);

    temp = {
        0,
        0,
        rectLoad.x,
        static_cast<float>(size.h)
    };
    SDL_RenderFillRect(renderer, &temp);

    temp = {
        rectLoad.x + rectLoad.w,
        rectLoad.y,
        static_cast<float>(size.w) - rectLoad.x + rectLoad.w,
        static_cast<float>(size.h) - rectLoad.y
    };
    SDL_RenderFillRect(renderer, &temp);

    temp = {
        rectLoad.x,
        rectLoad.y + rectLoad.h,
        static_cast<float>(size.h) - rectLoad.y + rectLoad.h,
        static_cast<float>(size.w) - rectLoad.x
    };
    SDL_RenderFillRect(renderer, &temp);

    GRAPHICS::Print("Scegli il file da caricare:", static_cast<float>(size.w / 10), static_cast<float>(size.h / 15), 10.0f, renderer, textures);

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderFillRect(renderer, &global.win.load.back.rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &global.win.load.back.rect);
    GRAPHICS::PrintCentered(global.win.load.back.text, &global.win.load.back.rect, 8, renderer, textures);

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderFillRect(renderer, &global.win.load.next.rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &global.win.load.next.rect);
    GRAPHICS::PrintCentered(global.win.load.next.text, &global.win.load.next.rect, 8, renderer, textures);

    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &rectLoad);

    if (!project)
    {
        if (currentTex)
        {
            SDL_RenderTexture(global.win.load.getRenderer(), currentTex, nullptr, &texScaleted);
        }

        GRAPHICS::RenderRectTratteggiato(global.win.load.getRenderer(), &texRect, { 0, 0, 0, 255 }, { 200, 180, 0, 255 });
    }

    if (global.win.load.textbox)
    {
        global.win.load.textbox->Draw();
    }
}

// loadNext (Get/Set)
bool Load::IsLoadNext() const { return loadNext; }
void Load::SetLoadNext(bool isNext) { loadNext = isNext; }

// project (Get/Set)
bool Load::IsProject() const { return project; }
void Load::SetProject(bool newProject) { project = newProject; }

// back (Get/Set)
rectText& Load::GetBack() { return back; }
const rectText& Load::GetBack() const { return back; }
void Load::SetBack(const rectText& newBack) { back = newBack; }

// next (Get/Set)
rectText& Load::GetNext() { return next; }
const rectText& Load::GetNext() const { return next; }
void Load::SetNext(const rectText& newNext) { next = newNext; }

// rectLoad (Get/Set)
SDL_FRect& Load::GetRectLoad() { return rectLoad; }
const SDL_FRect& Load::GetRectLoad() const { return rectLoad; }
void Load::SetRectLoad(const SDL_FRect& newRect) { rectLoad = newRect; }

// texRect (Get/Set)
SDL_FRect& Load::GetTexRect() { return texRect; }
const SDL_FRect& Load::GetTexRect() const { return texRect; }
void Load::SetTexRect(const SDL_FRect& newTexRect) { texRect; }

// currentTex (Get/Set - Gestito come puntatore)
SDL_Texture* Load::GetCurrentTex() { return currentTex; }
const SDL_Texture* Load::GetCurrentTex() const { return currentTex; }
void Load::SetCurrentTex(SDL_Texture* newCurrentTex) { currentTex = newCurrentTex; }

// textbox (Get/Set - Gestito come puntatore)
TextBox* Load::GetTextbox() { return textbox; }
const TextBox* Load::GetTextbox() const { return textbox; }
void Load::SetTextbox(TextBox* newTextbox) { textbox = newTextbox; }