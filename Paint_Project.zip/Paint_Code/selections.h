#pragma once
#include "basicStruct.h"
#include "winTemplate.h"

class Selections
{
protected:
	Window* win;
	Tools& type;
    VariabiliGlobali& global;

	Tools lastType;
	bool selected;
    bool moving;
	ColorRgb color1;
	ColorRgb color2;
	std::vector<SDL_FRect> settingRect;
    Coord startCoord;
    Coord finalCoord;
    int currentRectPos;

	SDL_FRect rect;

	std::vector<SDL_FPoint> lazoCoord;
    std::vector<SDL_FPoint> preparationLazoCoord;
    std::vector<Coord> lazoMovingPoints;
    std::unordered_set<Coord> area;
    bool preparation;

    SDL_Texture* edge;
public:
	Selections(Window* win, Tools& type, VariabiliGlobali& global);

	void Draw();
	void Update(Coord click, bool cursorMotion, bool cursorRealesed, bool returnRealesed, bool reset);
    void UpdateRect(Coord click, bool cursorMotion, bool cursorRealesed, bool returnRealesed);
    void setRectCorner();
    bool IsPixelInArea(Coord coord);
    void SetArea();
    void UpdateLazo(Coord clickCoord, bool cursorMotion, bool cursorRealesed, bool returnRealesed);
    void UpdateColor(Coord click, bool cursorMotion, bool cursorRealesed, bool returnRealesed);
    SDL_Texture* createEdgeAreaTexture();


    void SetLastType(Tools t);
    Tools& GetLastType();
    const Tools& GetLastType() const;

    bool& IsSelected();
    bool IsSelected() const;

    bool& IsPreparation();
    bool IsPreparation() const;

    void SetColor1(ColorRgb c);
    ColorRgb& GetColor1();
    const ColorRgb& GetColor1() const;

    void SetColor2(ColorRgb c);
    ColorRgb& GetColor2();
    const ColorRgb& GetColor2() const;

    void SetSettingRect(const std::vector<SDL_FRect>& v);
    std::vector<SDL_FRect>& GetSettingRect();
    const std::vector<SDL_FRect>& GetSettingRect() const;

    void SetStartCoord(Coord c);
    Coord& GetStartCoord();
    const Coord& GetStartCoord() const;

    void SetFinalCoord(Coord c);
    Coord& GetFinalCoord();
    const Coord& GetFinalCoord() const;

    void SetRect(SDL_FRect r);
    SDL_FRect& GetRect();
    const SDL_FRect& GetRect() const;

    void SetLazoCoord(const std::vector<SDL_FPoint>& l);
    std::vector<SDL_FPoint>& GetLazoCoord();
    const std::vector<SDL_FPoint>& GetLazoCoord() const;

    void SetPreparationLazoCoord(const std::vector<SDL_FPoint>& l);
    std::vector<SDL_FPoint>& GetPreparationLazoCoord();
    const std::vector<SDL_FPoint>& GePreparationtLazoCoord() const;

    void SetLazoMovingPoints(const std::vector<Coord>& l);
    std::vector<Coord>& GetLazoMovingPoints();
    const std::vector<Coord>& GetLazoMovingPoints() const;

    std::unordered_set<Coord>& GetArea();
    const std::unordered_set<Coord>& GetArea() const;

    Tools& GetType();
    const Tools& GetType() const;

    SDL_Texture*& getTexture();
};