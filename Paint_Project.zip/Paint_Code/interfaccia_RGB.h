#pragma once
#include "winTemplate.h"

class Interfaccia_RGB
{
private:
    VariabiliGlobali& global;
    SDL_FRect& continueRect;
    SDL_FRect& rectNewColor;
    ColorRgb& finalColor;
    bool& colorPP;

    Uint8 alphaLevelRgb;
    rectColoredRgb alphaLine;
    std::vector<rectColoredRgb> alphaCircle;
    std::vector<std::vector<rectColored>> colorMap;
    std::vector<std::vector<bool>> rectSelected;
    int letterSize;
    SDL_Texture* alphaGrid;

public:
    Interfaccia_RGB(VariabiliGlobali& global, SDL_FRect& continueRect, SDL_FRect& rectNewColor, ColorRgb& finalColor, bool& colorPP);

    void Update();
    void Draw();

    void UpdateAlphaLevel(bool drawingInMove, bool mouseReleased);

    // alphaLevel (Get/Set)
    Uint8 GetAlphaLevelRgb() const;
    void SetAlphaLevelRgb(Uint8 level);

    // letterSize (Get/Set)
    int GetLetterSize() const;
    void SetLetterSize(int size);

    // alphaLine (Get/Set)
    const rectColoredRgb& GetAlphaLine() const;
    void SetAlphaLine(const rectColoredRgb& newLine);

    // alphaCircle (std::vector<rectColoredRgb>)
    std::vector<rectColoredRgb>& GetAlphaCircle();
    const std::vector<rectColoredRgb>& GetAlphaCircle() const;
    void SetAlphaCircle(const std::vector<rectColoredRgb>& newCircles);

    // colorMap (std::vector<std::vector<rectColored>>)
    std::vector<std::vector<rectColored>>& GetColorMap();
    const std::vector<std::vector<rectColored>>& GetColorMap() const;
    void SetColorMap(const std::vector<std::vector<rectColored>>& newMap);

    // rectSelected (std::vector<std::vector<bool>>)
    std::vector<std::vector<bool>>& GetRectSelected();
    const std::vector<std::vector<bool>>& GetRectSelected() const;
    void SetRectSelected(const std::vector<std::vector<bool>>& newRect);

    // alphaGrid
    SDL_Texture* GetAlphaGrid() const;
    SDL_Texture*& GetAlphaGrid();
    void SetAlphaGrid(SDL_Texture* newAlphaGrid);
};