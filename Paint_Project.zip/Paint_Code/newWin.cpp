#define SDL_MAIN_HANDLED
#include "newWin.h"
#include "textBox.h"
#include "set.h"
#include "texture.h"
#include "app.h"

New::New(VariabiliGlobali& global) :
    global(global),
    back({ 0, 0, 0, 0 }),
    next({ 0, 0, 0, 0 }),
    wBack(0.0f),
    pendingCloseSetNew(false),
    level(false),
    strTavolaColori("Scegli il colore del foglio:") {
}

void New::Update()
{
    if ((global.click.x >= back.rect.x && global.click.x <= back.rect.x + back.rect.w) &&
        (global.click.y >= back.rect.y && global.click.y <= back.rect.y + back.rect.h) && window)
    {
        Destroy();
        global.click = { -1, -1 };
    }
    else if ((global.click.x >= next.rect.x && global.click.x <= next.rect.x + next.rect.w) &&
        (global.click.y >= next.rect.y && global.click.y <= next.rect.y + next.rect.h) && window)
    {
        if (textbox[0]->getText().empty() || textbox[1]->getText().empty())
        {
            if (textbox[0]->getText().empty())
            {
                textbox[0]->setERROR(true);
            }
            else
            {
                textbox[0]->setERROR(false);
            }
            if (textbox[1]->getText().empty())
            {
                textbox[1]->setERROR(true);
            }
            else
            {
                textbox[1]->setERROR(false);
            }
        }
        else if (!textbox[0]->getText().empty() && !textbox[1]->getText().empty())
        {
            Size temp;
            temp.w = std::stoi(textbox[0]->getText());
            temp.h = std::stoi(textbox[1]->getText());

            if (temp.w <= 0 || temp.h <= 0 || temp.w > global.win.Main.level().GetLimitSize().w || temp.h > global.win.Main.level().GetLimitSize().h)
            {
                if (temp.w == 0)
                {
                    textbox[0]->setERROR(true);
                }
                else
                {
                    textbox[0]->setERROR(false);
                }
                if (temp.h == 0)
                {
                    textbox[1]->setERROR(true);
                }
                else
                {
                    textbox[1]->setERROR(false);
                }
            }
            else if (temp.w > 0 && temp.h > 0 && temp.w <= global.win.Main.level().GetLimitSize().w && temp.h <= global.win.Main.level().GetLimitSize().h)
            {
                if (level)
                {
                    Level newLevel;
                    newLevel.name = "level. " + std::to_string(global.win.Main.level().GetLevel().size());

                    global.win.Main.level().GetLevel().insert(global.win.Main.level().GetLevel().begin() + global.currentLevel, newLevel);
                    global.baseLevelPos += (global.baseLevelPos >= global.currentLevel) ? 1 : 0;
                }
                else
                {
                    global.win.Main.level().GetLevel().clear();
                    global.win.Main.level().GetLevel().push_back({});
                    global.currentLevel = 0;

                    global.win.Main.level()[global.currentLevel].name = "Sfondo";
                }

                global.win.Main.level()[global.currentLevel].size.w = static_cast<float>(temp.w);
                global.win.Main.level()[global.currentLevel].size.h = static_cast<float>(temp.h);
                global.win.Main.level().GetOpen() = true;
                global.win.Main.level()[global.currentLevel].bgColor = global.win.color.GetFinalColor();

                float baseW = static_cast<float>(global.win.Main.level().GetBasicSize().w);
                float baseH = static_cast<float>(global.win.Main.level().GetBasicSize().h);

                if (!level)
                {
                    float zoomX = baseW / temp.w;
                    float zoomY = baseH / temp.h;
                    global.win.Main.level().GetZoom() = ((zoomX < zoomY) ? zoomX : zoomY) / 1.1f;
                }

                float scaledW = temp.w * global.win.Main.level().GetZoom();
                float scaledH = temp.h * global.win.Main.level().GetZoom();

                float offsetX = (global.win.Main.getSize().w - scaledW) / 2.0f;
                float offsetY = (global.win.Main.getSize().h - scaledH) / 2.0f;


                global.win.Main.level()[global.currentLevel].size.x = offsetX;
                global.win.Main.level()[global.currentLevel].size.y = offsetY;

                global.win.Main.level()[global.currentLevel].map.clear();
                global.win.Main.level()[global.currentLevel].map.resize(temp.h);

                for (int y = 0; y < temp.h; ++y)
                {
                    global.win.Main.level()[global.currentLevel].map[y].resize(temp.w);
                    for (int x = 0; x < temp.w; ++x)
                    {
                        ColorRgb cell;
                        cell = global.win.Main.level()[global.currentLevel].bgColor;

                        global.win.Main.level()[global.currentLevel].map[y][x] = cell;
                    }
                }
                global.win.Main.level()[global.currentLevel].startMap = global.win.Main.level()[global.currentLevel].map;

                global.win.Main.level()[global.currentLevel].zoomSize = {
                    offsetX,
                    offsetY,
                    scaledW,
                    scaledH
                };

                global.win.Main.level()[global.currentLevel].moveCoord = {
                    global.win.Main.level()[global.currentLevel].zoomSize.x,
                    global.win.Main.level()[global.currentLevel].zoomSize.y
                };

                global.win.Main.level()[global.currentLevel].chronology.Reset();
                APP::updateCronology(global);

                if (!level)
                {
                    global.baseLevelPos = global.currentLevel;
                    global.win.Main.level().GetAlphaGridCoord() = global.win.Main.level()[global.currentLevel].moveCoord;
                }

                global.win.Main.level().Draw();
                SET::menuTools(global);
                SET::newTextBox(global, level);
                SET::levelMenu(global);
                global.win.Main.level().UpdateAlphaGrid();

                global.win.Main.level()[global.currentLevel].needsUpdate = true;

                Destroy();
                global.click = { -1, -1 };
                return;
            }
        }
    }

    if (textbox[0]) textbox[0]->Update();
    if (textbox[1]) textbox[1]->Update();

    if ((global.click.x >= global.win.Main.GetRectTavolaColori().x && global.click.x <= global.win.Main.GetRectTavolaColori().x + global.win.Main.GetRectTavolaColori().w) &&
        (global.click.y >= global.win.Main.GetRectTavolaColori().y && global.click.y <= global.win.Main.GetRectTavolaColori().y + global.win.Main.GetRectTavolaColori().h) && !global.win.color.getWindow() && !global.win.color.isOpen())
    {
        global.win.color.Initialize("Tavola Colori", 600, 380, &global.click, false, global.win.Main.getSize().w / 10, global.win.Main.getSize().h / 10, false);
        global.win.color.getTextures() = TEXTURE::CreateIconsTextures(global.win.color.getRenderer(), global.loadedSurfaces);
        global.click = { -1, -1 };
        global.win.color.Set();
    }
}

void New::Draw()
{
    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderClear(renderer);

    GRAPHICS::Print("Inserisci le dimensioni del foglio:", wBack, static_cast<float>(size.h / 10), 10, renderer, textures);
    GRAPHICS::Print("x:", static_cast<float>(size.w / 10), static_cast<float>(size.h / 10 * 2), 10, renderer, textures, 0.2f);
    GRAPHICS::Print("y:", static_cast<float>(size.w / 10), static_cast<float>(size.h / 10 * 3), 10, renderer, textures, 0.2f);
    GRAPHICS::Print("px", static_cast<float>(size.w / 10 + textbox[0]->getRect().w + 25), static_cast<float>(size.h / 10 * 2), 10.0f, renderer, textures);
    GRAPHICS::Print("px", static_cast<float>(size.w / 10 + textbox[0]->getRect().w + 25), static_cast<float>(size.h / 10 * 3), 10.0f, renderer, textures);

    GRAPHICS::Print(strTavolaColori, static_cast<float>(size.w / 10), static_cast<float>(size.h / 10 * 5), 10.0f, renderer, textures);

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderFillRect(renderer, &back.rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &back.rect);
    GRAPHICS::PrintCentered(back.text, &back.rect, 10, renderer, textures);

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderFillRect(renderer, &next.rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &next.rect);
    GRAPHICS::PrintCentered(next.text, &next.rect, 10, renderer, textures);

    if (textbox[0]) textbox[0]->Draw();
    if (textbox[1]) textbox[1]->Draw();

    SDL_SetRenderDrawColor(renderer, global.win.color.GetFinalColor().r, global.win.color.GetFinalColor().g, global.win.color.GetFinalColor().b, global.win.color.GetFinalColor().a);
    SDL_RenderFillRect(renderer, &global.win.Main.GetRectTavolaColori());
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &global.win.Main.GetRectTavolaColori());
    SDL_FRect tavolaTemp = {
        global.win.Main.GetRectTavolaColori().x - 1,
        global.win.Main.GetRectTavolaColori().y - 1,
        global.win.Main.GetRectTavolaColori().w + 2,
        global.win.Main.GetRectTavolaColori().h + 2
    };
    SDL_RenderRect(renderer, &tavolaTemp);
}


// back (Get/Set)
rectText& New::GetBack() { return back; }
const rectText& New::GetBack() const { return back; }
void New::SetBack(const rectText& newBack) { back = newBack; }

// next (Get/Set)
rectText& New::GetNext() { return next; }
const rectText& New::GetNext() const { return next; }
void New::SetNext(const rectText& newNext) { next = newNext; }

// wBack (Get/Set)
float New::GetWBack() const { return wBack; }
void New::SetWBack(float newWBack) { wBack = newWBack; }

// pendingCloseSetNew (Get/Set)
bool New::IsPendingCloseSetNew() const { return pendingCloseSetNew; }
void New::SetPendingCloseSetNew(bool isPending) { pendingCloseSetNew = isPending; }

bool New::IsLevel() const { return level; }
void New::SetIsLevel(bool isLevel) { level = isLevel; }

// strTavolaColori (Get/Set)
const std::string& New::GetStrTavolaColori() const { return strTavolaColori; }
void New::SetStrTavolaColori(const std::string& newStr) { strTavolaColori = newStr; }

// textbox (std::vector<TextBox*>)
std::vector<TextBox*>& New::GetTextbox() { return textbox; }
const std::vector<TextBox*>& New::GetTextbox() const { return textbox; }
void New::SetTextbox(const std::vector<TextBox*>& newTextbox) { textbox = newTextbox; }