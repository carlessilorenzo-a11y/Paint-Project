#pragma once
#include <vector>
#include <unordered_set>

struct VariabiliGlobali;
struct Coord;
struct ColorRgb;

bool isInsideCanvas(VariabiliGlobali& global);
Coord getMapClick(VariabiliGlobali& global);
float setSize(VariabiliGlobali& global, ColorRgb& color);
void pixelAt(int ix, int iy, VariabiliGlobali& global, ColorRgb& color, std::unordered_set<Coord>& area);
void setStillCircle(VariabiliGlobali& global, Coord& mapClick, float& size, ColorRgb& color, Coord& lastClick);
void setMoveCircle(VariabiliGlobali& global, Coord& mapClick, float& size, ColorRgb& color, Coord& lastClick);
void SetBrushEraser(VariabiliGlobali& global, Coord& lastClick, Coord& mapClick);
void SetBucket(VariabiliGlobali& global, Coord& mapClick);