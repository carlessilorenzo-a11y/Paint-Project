#pragma once
#include <vector>
#include "SDL3/SDL.h"

#include "basicStruct.h"

struct VariabiliGlobali;

class Window
{
protected:
    SDL_Window* window;
    SDL_Renderer* renderer;
    bool open;
    Size size;
    std::vector<Textures> textures;

public:
    Window(const Window&) = delete;
    Window& operator=(const Window&) = delete;
    Window(Window&&) = delete;
    Window& operator=(Window&&) = delete;

    Window();

    void Initialize(const char* title, int w, int h, bool centered, int x, int y, bool resizeble, bool maximized);

    void Destroy();

    virtual ~Window()
    {
        Destroy();
    }

    virtual void Update() = 0;
    virtual void Draw() = 0;

    SDL_Window* getWindow() const;
    SDL_Renderer* getRenderer() const;

    bool& isOpen();
    const bool& isOpen() const;

    Size& getSize();
    const Size& getSize() const;

    std::vector<Textures>& getTextures();
    const std::vector<Textures>& getTextures() const;
};