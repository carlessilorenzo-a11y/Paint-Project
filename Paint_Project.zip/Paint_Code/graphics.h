#pragma once

#include "variabiliGlobali.h"

namespace GRAPHICS
{
    void Print(const std::string& text, float x, float y, float size, SDL_Renderer* renderer, std::vector<Textures>& textures, float letterSpacing = 0.35);
    void PrintCentered(const std::string& text, const SDL_FRect* rect, float size, SDL_Renderer* renderer, std::vector<Textures>& textures, float letterSpacing = 0.35);
    ColorRgb getRgbColor(ColorType color, int shade);
    std::vector<rectColoredRgb> createCircle(float centerX, float centerY, float radius, ColorRgb fillColor, ColorRgb borderColor);
    std::vector<rectColoredRgb> createCircleFromMap(float centerX, float centerY, float radius, std::vector<std::vector<ColorRgb>> bgMap);
    void RenderCircle(SDL_Renderer* renderer, float cx, float cy, float radius, const ColorRgb& color);
    void RenderRectTratteggiato(SDL_Renderer* renderer, SDL_FRect* rect, ColorRgb color1, ColorRgb color2, float lengthTratto = 5.0f);
    void RenderEllisseInscritta(SDL_Renderer* renderer, SDL_FRect* rect, ColorRgb color);
    void RenderEllisseInscrittaTratteggiata(SDL_Renderer* renderer, SDL_FRect* rect, ColorRgb color1, ColorRgb color2, float lengthTratto = 5.0f);
    std::vector<rectColoredRgb> createEllisseInscritta(SDL_FRect* rect, ColorRgb color = { 255, 255, 255, 255 });
    void RenderPointsTratteggiati(SDL_Renderer* renderer, std::vector<SDL_FPoint> points, ColorRgb color1, ColorRgb color2, float lengthTratto = 5.0f);
    void RenderFillCircle(SDL_Renderer* renderer, float cx, float cy, float radius, const ColorRgb& color);
    void RenderAreaTratteggiata(SDL_Renderer* renderer, const std::unordered_set<Coord>& area, ColorRgb color1, ColorRgb color2, const Coord mapOffset, const float zoom, int mapWidth, int mapHeight);
    void fillMapWithSelectedArea(VariabiliGlobali& global, ColorRgb c);
}