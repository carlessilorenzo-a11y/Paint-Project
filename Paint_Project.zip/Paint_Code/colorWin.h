#pragma once
#include <vector>

#include "winTemplate.h"
#include "interfaccia_RGB.h"
#include "interfaccia_RGBHSV.h"

class Color : public Window
{
private:
    VariabiliGlobali& global;

    bool colorPP;
    ColorInterfaccia interfaccia;
    SDL_FRect staticRect;
    SDL_FRect baseRect;
    SDL_FRect avanzatoRect;
    SDL_FRect continueRect;
    SDL_FRect rectLastColor;
    SDL_FRect rectNewColor;
    ColorRgb finalColor;
    Interfaccia_RGB interfaccia_RGB;
    Interfaccia_RGBHSV interfaccia_RGBHSV;

public:
    Color(VariabiliGlobali& global);

    void Set();
    void Update() override;
    void Draw() override;

    ColorInterfaccia getCurrentInterfaccia() const;

    bool IsColorPP() const;
    void SetIsColorPP(bool isPP);

    ColorRgb& GetFinalColor();
    const ColorRgb& GetFinalColor() const;
    void SetFinalColor(const ColorRgb& color);

    SDL_FRect& GetStaticRect();
    const SDL_FRect& GetStaticRect() const;
    void SetStaticRect(const SDL_FRect& rect);

    SDL_FRect& GetRectLastColor();
    const SDL_FRect& GetRectLastColor() const;
    void SetRectLastColor(const SDL_FRect& newRectLastColor);

    SDL_FRect& GetRectNewColor();
    const SDL_FRect& GetRectNewColor() const;
    void SetRectNewColor(const SDL_FRect& newRectNewColor);

    Interfaccia_RGB& getRGBinterfaccia();
    const Interfaccia_RGB& getRGBinterfaccia() const;

    Interfaccia_RGBHSV& getRGBHSVinterfaccia();
    const Interfaccia_RGBHSV& getRGBHSVinterfaccia() const;
};