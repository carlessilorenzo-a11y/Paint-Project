#pragma once

#include <string>
#include <sstream>

#include "winTemplate.h"
#include "draw.h"
#include "selections.h"

class Slider;
class Selections;
class SliderTextbox;

class MainWin : public Window
{
protected:
    VariabiliGlobali& global;
    ColorRgb color_PP;
    ColorRgb color_SF;
    ColorRgb bgColor;
    Project level_;
    ToolsInformation tools;
    std::vector<rectBool> mainMenuRect;
    std::vector<MenuFile> menuFile;
    std::vector<MenuFile> levelMenu;
    std::vector<MenuEdit> menuEdit;
    std::vector<MenuProject> menuProject;
    std::vector<MenuSelection> menuSelection;
    int levelRectMovingPos;
    SDL_FRect fileRectMenu;
    SDL_FRect rectTavolaColori;
    SDL_FRect colorRect_PP;
    SDL_FRect colorRect_SF;
    SDL_FRect levelRect;
    SDL_FRect frecciaRect;
    SDL_FRect rectGestioneTools;
    SDL_FRect areaDiLavoro;
    Slider* opacity;
    Selections* selections;
    std::vector<SliderTextbox*> toolsSetting;

public:
    MainWin(VariabiliGlobali& global);

    void Update() override;
    void Draw() override;
    void UpdateCursorSkin();
    void UpdateMenuTools();
    void UpdateLevelSwaps(bool levelMoving, bool levelRealesed);


    // bgColor (Get/Set)
    ColorRgb& GetBgColor();
    const ColorRgb& GetBgColor() const;
    void SetBgColor(const ColorRgb& newBgColor);

    // fileRectMenu (Get/Set)
    SDL_FRect& GetFileRectMenu();
    const SDL_FRect& GetFileRectMenu() const;
    void SetFileRectMenu(const SDL_FRect& newRect);

    // rectTavolaColori (Get/Set)
    const SDL_FRect& GetRectTavolaColori() const;
    void SetRectTavolaColori(const SDL_FRect& newRect);

    // colorRect_PP (Get/Set)
    const SDL_FRect& GetColorRect_PP() const;
    void SetColorRect_PP(const SDL_FRect& newRect);

    // colorRect_SF (Get/Set)
    const SDL_FRect& GetColorRect_SF() const;
    void SetColorRect_SF(const SDL_FRect& newRect);

    // levelRect (Get/Set)
    const SDL_FRect& GetLevelRect() const;
    void SetLevelRect(const SDL_FRect& newRect);

    // frecciaRect (Get/Set)
    const SDL_FRect& GetFrecciaRect() const;
    void SetFrecciaRect(const SDL_FRect& newRect); 

    // rectGestioneTools (Get/Set)
    const SDL_FRect& GetRectGestioneTools() const;
    void SetRectGestioneTools(const SDL_FRect& newRect);

    // areaDiLavoro (Get/Set)
    SDL_FRect& GetAreaDiLavoro();
    const SDL_FRect& GetAreaDiLavoro() const;
    void SetAreaDiLavoro(const SDL_FRect& newRect);

    // level (std::vector<DrawMap>)
    Project& level();
    const Project& level() const;

    // color_PP 
    ColorRgb& GetColor_PP();
    const ColorRgb& GetColor_PP() const;
    void SetColor_PP(const ColorRgb& newColor);

    // color_SF 
    ColorRgb& GetColor_SF();
    const ColorRgb& GetColor_SF() const;
    void SetColor_SF(const ColorRgb& newColor);

    // tools (ToolsInformation)
    ToolsInformation& GetTools();
    const ToolsInformation& GetTools() const;
    void SetTools(const ToolsInformation& newTools);

    // mainMenuRect (std::vector<rectBool>)
    std::vector<rectBool>& GetMainMenuRect();
    const std::vector<rectBool>& GetMainMenuRect() const;
    void SetMainMenuRect(const std::vector<rectBool>& newMenu);

    // menuFile (std::vector<MenuFile>)
    std::vector<MenuFile>& GetMenuFile();
    const std::vector<MenuFile>& GetMenuFile() const;
    void SetMenuFile(const std::vector<MenuFile>& newMenu);

    // projectMenu (std::vector<MenuProject>)
    std::vector<MenuProject>& GetMenuProject();
    const std::vector<MenuProject>& GetMenuProject() const;
    void SetMenuProject(const std::vector<MenuProject>& newMenu);

    // menuEdit (std::vector<MenuEdit>)
    std::vector<MenuEdit>& GetMenuEdit();
    const std::vector<MenuEdit>& GetMenuEdit() const;
    void SetMenuEdit(const std::vector<MenuEdit>& newMenuEdit);

    // levelMenu (std::vector<MenuFile>)
    std::vector<MenuFile>& GetlevelMenu();
    const std::vector<MenuFile>& GetlevelMenu() const;
    void SetlevelMenu(const std::vector<MenuFile>& newlevelMenu);

    // menuSelection (std::vector<MenuSelection>)
    std::vector<MenuSelection>& GetMenuSelection();
    const std::vector<MenuSelection>& GetMenuSelection() const;
    void SetMenuSelection(const std::vector<MenuSelection>& newSelectionMenu);

    // opacity
    Slider* GetOpacity();
    const Slider* GetOpacity() const;
    void SetOpacity(Slider* newSlider);

    // selections
    Selections* GetSelections();
    const Selections* GetSelections() const;
    void SetSelections();

    // toolsSetting (std::vector<SliderTextbox*>)
    std::vector<SliderTextbox*>& GetToolsSetting();
    const std::vector<SliderTextbox*>& GetToolsSetting() const;
};