#pragma once
#include <SDL3/SDL_main.h>

struct VariabiliGlobali;
class Window;

void setRectClip(VariabiliGlobali& global);
void renderTexture(VariabiliGlobali& global);
