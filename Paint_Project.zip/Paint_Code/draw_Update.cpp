#define SDL_MAIN_HANDLED
#include "draw_Update.h"
#include "variabiliGlobali.h"
#include "graphics.h"
#include "app.h"

bool isInsideCanvas(VariabiliGlobali& global)
{
    SDL_FRect rect;

    if (!global.win.Main.GetSelections()->IsSelected()) 
    {
        rect = {
            (global.win.Main.getSize().w - global.win.Main.level().GetBasicSize().w) / 2.0f,
            (global.win.Main.getSize().h - global.win.Main.level().GetBasicSize().h) / 2.0f,
            static_cast<float>(global.win.Main.level().GetBasicSize().w),
            static_cast<float>(global.win.Main.level().GetBasicSize().h)
        };

        return APP::isPixelInRect(global.click, &rect);
    }
    else
    {
        switch (global.win.Main.GetSelections()->GetLastType())
        {
        case Tools::SELEZIONE_RETTANGOLARE:
        {
            rect = global.win.Main.GetSelections()->GetRect();
            return APP::isPixelInRect(global.click, &rect);
        }
        case Tools::SELEZIONE_CIRCOLARE:
        {
            rect = global.win.Main.GetSelections()->GetRect();
            return APP::isPixelInEllisse(global.click, &rect);
        }
        case Tools::SELEZIONE_LAZO:
        {
            rect = global.win.Main.GetSelections()->GetRect();
            if (APP::isPixelInEllisse(global.click, &rect))
            {
                return global.win.Main.GetSelections()->IsPixelInArea(global.click);
            }
            return false;
        }
        case Tools::SELEZIONE_COLORE:
        {
            return global.win.Main.GetSelections()->IsPixelInArea(global.click);
        }
        }
    }
    return false;
}

Coord getMapClick(VariabiliGlobali& global)
{
    Coord mapClick;
    mapClick.x = (global.click.x - global.win.Main.level()[global.currentLevel].moveCoord.x) / global.win.Main.level().GetZoom();
    mapClick.y = (global.click.y - global.win.Main.level()[global.currentLevel].moveCoord.y) / global.win.Main.level().GetZoom();
    return mapClick;
}

float setSize(VariabiliGlobali& global, ColorRgb& color)
{
    switch (global.win.Main.GetTools().current)
    {
    case Tools::BRUSH:
        color = global.win.Main.GetColor_PP();
        return global.win.Main.GetTools().setting.brush.size / 2.0f;
        break;

    case Tools::ERASER:
        return global.win.Main.GetTools().setting.eraser.size / 2.0f;
        break;
    }
    return 0.0f;
}

void pixelAt(int ix, int iy, VariabiliGlobali& global, ColorRgb& color, std::unordered_set<Coord>& area)
{
    if (iy < 0 || iy >= (int)global.win.Main.level()[global.currentLevel].map.size() ||
        ix < 0 || ix >= (int)global.win.Main.level()[global.currentLevel].map[iy].size())
        return;

    ColorRgb& mapPixel = global.win.Main.level()[global.currentLevel].map[iy][ix];
    ColorRgb startMapPixel = global.win.Main.level()[global.currentLevel].startMap[iy][ix];

    ColorRgb pixelColor = (global.win.Main.GetTools().current == Tools::ERASER) ?
        startMapPixel : color;

    if (!global.win.Main.GetSelections()->IsSelected())
    {
        mapPixel = pixelColor;
    }
    else
    {
        SDL_FRect rScreen = global.win.Main.GetSelections()->GetRect();

        float zoom = global.win.Main.level().GetZoom();
        Coord offset = global.win.Main.level()[global.currentLevel].moveCoord;

        SDL_FRect r = {
            (rScreen.x - offset.x) / zoom,
            (rScreen.y - offset.y) / zoom,
            rScreen.w / zoom,
            rScreen.h / zoom
        };

        switch (global.win.Main.GetSelections()->GetLastType())
        {
        case Tools::SELEZIONE_RETTANGOLARE:
            if (APP::isPixelInRect({ static_cast<float>(ix), static_cast<float>(iy) }, &r))
            {
                mapPixel = pixelColor;
            }
            break;

        case Tools::SELEZIONE_CIRCOLARE:
        {
            if (APP::isPixelInEllisse({ static_cast<float>(ix), static_cast<float>(iy) }, &r))
            {
                mapPixel = pixelColor;
            }
            break;
        }
        case Tools::SELEZIONE_LAZO:
        {
            Coord mapCoord = {
                static_cast<float>(ix), 
                static_cast<float>(iy)
            };

            if (area.count(mapCoord))
            {
                mapPixel = pixelColor;
            }
            break;
        }
        case Tools::SELEZIONE_COLORE:
        {
            Coord mapCoord = {
                static_cast<float>(ix),
                static_cast<float>(iy)
            };

            if (area.count(mapCoord))
            {
                mapPixel = pixelColor;
            }
            break;
        }
        }
    }
}

void setStillCircle(VariabiliGlobali& global, Coord& mapClick, float& size, ColorRgb& color, Coord& lastClick)
{
    std::vector<rectColoredRgb> circle = (global.win.Main.GetTools().current == Tools::BRUSH) ?
        GRAPHICS::createCircle(mapClick.x, mapClick.y, (float)size, color, color) :
        GRAPHICS::createCircleFromMap(mapClick.x, mapClick.y, (float)size, global.win.Main.level()[global.currentLevel].startMap);

    std::unordered_set<Coord> area = {};
    if (global.win.Main.GetSelections()->GetLastType() == Tools::SELEZIONE_LAZO ||
        global.win.Main.GetSelections()->GetLastType() == Tools::SELEZIONE_COLORE)
    {
        area = global.win.Main.GetSelections()->GetArea();
    }

    for (auto& pixel : circle)
    {
        pixelAt((int)pixel.rect.x, (int)pixel.rect.y, global, color, area);
    }

    lastClick = mapClick;
    global.hasLast = true;

    if (!global.leftMousePressed)
    {
        global.cronologyUpdate = true;
    }
}

void setMoveCircle(VariabiliGlobali& global, Coord& mapClick, float& size, ColorRgb& color, Coord& lastClick)
{
    global.hasMovedSinceClick = true;

    int x0 = (int)lastClick.x;
    int y0 = (int)lastClick.y;
    int x1 = (int)mapClick.x;
    int y1 = (int)mapClick.y;

    int dx = abs(x1 - x0);
    int sx = (x0 < x1) ? 1 : -1;
    int dy = -abs(y1 - y0);
    int sy = (y0 < y1) ? 1 : -1;
    int err = dx + dy;

    std::unordered_set<Coord> area = {};
    if (global.win.Main.GetSelections()->GetLastType() == Tools::SELEZIONE_LAZO ||
        global.win.Main.GetSelections()->GetLastType() == Tools::SELEZIONE_COLORE)
    {
        area = global.win.Main.GetSelections()->GetArea();
    }

    while (true)
    {
        std::vector<rectColoredRgb> circle = (global.win.Main.GetTools().current == Tools::BRUSH) ?
            GRAPHICS::createCircle(static_cast<float>(x0), static_cast<float>(y0), static_cast<float>(size), color, color) :
            GRAPHICS::createCircleFromMap(static_cast<float>(x0), static_cast<float>(y0), static_cast<float>(size), global.win.Main.level()[global.currentLevel].startMap);

        for (auto& pixel : circle)
        {
            pixelAt((int)pixel.rect.x, (int)pixel.rect.y, global, color, area);
        }

        if (x0 == x1 && y0 == y1)
        {
            break;
        }

        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }

    lastClick = mapClick;
}

void SetBrushEraser(VariabiliGlobali& global, Coord& lastClick, Coord& mapClick)
{
    ColorRgb color;
    float size = setSize(global, color);

    if (!global.hasLast)
    {
        setStillCircle(global, mapClick, size, color, lastClick);
    }
    else
    {
        setMoveCircle(global, mapClick, size, color, lastClick);
    }
}

void SetBucket(VariabiliGlobali& global, Coord& start)
{
    std::queue<Coord> q;
    Tools selectionType = Tools::NOTHING;

    Coord offset = global.win.Main.level()[global.currentLevel].moveCoord;
    float zoom = global.win.Main.level().GetZoom();

    SDL_FRect limit = {
        0.0f,
        0.0f,
        static_cast<float>(global.win.Main.level()[global.currentLevel].map[0].size()),
        static_cast<float>(global.win.Main.level()[global.currentLevel].map.size()),
    };

    if (global.win.Main.GetSelections()->IsSelected())
    {
        Selections* selection = global.win.Main.GetSelections();

        switch (global.win.Main.GetSelections()->GetLastType())
        {
        case Tools::SELEZIONE_RETTANGOLARE:
        {
            SDL_FRect& rect = selection->GetRect();
            limit = {
               (rect.x - offset.x) / zoom,
               (rect.y - offset.y) / zoom,
               rect.w / zoom,
               rect.h / zoom
            };

            if (!APP::isPixelInRect(start, &limit)) return;
            selectionType = Tools::SELEZIONE_RETTANGOLARE;
            break;
        }
        case Tools::SELEZIONE_CIRCOLARE:
        {
            SDL_FRect& rect = selection->GetRect();
            limit = {
              (rect.x - offset.x) / zoom,
              (rect.y - offset.y) / zoom,
              rect.w / zoom,
              rect.h / zoom
            };

            if(!APP::isPixelInEllisse(start, &limit)) return;
            selectionType = Tools::SELEZIONE_CIRCOLARE;
            break;
        }
        case Tools::SELEZIONE_LAZO:
            selectionType = Tools::SELEZIONE_LAZO;
            break;

        case Tools::SELEZIONE_COLORE:
            selectionType = Tools::SELEZIONE_COLORE;
            break;
        }
    }
    else if (!APP::isPixelInRect(start, &limit)) return;

    ColorRgb targetColor = global.win.Main.level()[global.currentLevel].map[static_cast<size_t>(start.y)][static_cast<size_t>(start.x)];

    if (targetColor == global.win.Main.GetColor_PP())
        return;
    
    q.push(start);
    global.win.Main.level()[global.currentLevel].map[static_cast<size_t>(start.y)][static_cast<size_t>(start.x)] = global.win.Main.GetColor_PP();
    float& error = global.win.Main.GetTools().setting.bucket.error;

    auto isPixelInArea = [&](Coord pixel) -> bool
        {
            if(selectionType == Tools::SELEZIONE_LAZO || selectionType == Tools::SELEZIONE_COLORE)
            {
                Coord screenPixel = { pixel.x * zoom + offset.x, pixel.y * zoom + offset.y };
                return global.win.Main.GetSelections()->IsPixelInArea(screenPixel);
            }
            else if (selectionType == Tools::SELEZIONE_CIRCOLARE)
            {
                return APP::isPixelInEllisse(pixel, &limit);
            }
            else
            {
                return APP::isPixelInRect(pixel, &limit);
            }
            return false;
        };

    while (!q.empty())
    {
        Coord p = q.front();
        q.pop();

        const int dx[4] = { 1, -1, 0, 0 };
        const int dy[4] = { 0, 0, 1, -1 };

        for (int i = 0; i < 4; i++)
        {
            int nx = static_cast<int>(p.x) + dx[i];
            int ny = static_cast<int>(p.y) + dy[i];

            if (isPixelInArea({static_cast<float>(nx), static_cast<float>(ny)}))
            {
                ColorRgb& c = global.win.Main.level()[global.currentLevel].map[ny][nx];
                if ((c.r >= targetColor.r - error && c.r <= targetColor.r + error) &&
                    (c.g >= targetColor.g - error && c.g <= targetColor.g + error) &&
                    (c.b >= targetColor.b - error && c.b <= targetColor.b + error) &&
                    (c.a >= targetColor.a - error && c.a <= targetColor.a + error))
                {
                    c = global.win.Main.GetColor_PP();
                    Coord next = { static_cast<float>(nx), static_cast<float>(ny) };
                    q.push(next);
                }
            }
        }
    }

    global.cronologyUpdate = true;
}