#define SDL_MAIN_HANDLED
#include "salvataggio.h"
#include "texture.h"
#include "app.h"

namespace SALVATAGGIO
{
    bool SaveMapToImage(const std::vector<std::vector<ColorRgb>>& map, const std::string& filename, bool savePNG)
    {
        if (map.empty() || map[0].empty()) {
            SDL_Log("Mappa vuota!");
            return false;
        }

        int height = static_cast<int>(map.size());
        int width = static_cast<int>(map[0].size());

        SDL_Surface* surface = SDL_CreateSurface(width, height, SDL_PIXELFORMAT_RGBA8888);
        if (!surface) {
            SDL_Log("Errore nella creazione della surface: %s", SDL_GetError());
            return false;
        }

        Uint32* pixels = static_cast<Uint32*>(surface->pixels);
        int pitch = surface->pitch / 4;

        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                const ColorRgb& c = map[y][x];
                pixels[y * pitch + x] = (c.r << 24) | (c.g << 16) | (c.b << 8) | c.a;
            }
        }

        int result = -1;
        SDL_ClearError();
        if (savePNG)
        {
            result = IMG_SavePNG(surface, filename.c_str());
        }
        else
        {
            result = SDL_SaveBMP(surface, filename.c_str());
        }

        if (result != 0 && result != 1) {
            SDL_Log("Errore nel salvataggio del file '%s': %s", filename.c_str(), SDL_GetError());
            SDL_DestroySurface(surface);
            return false;
        }

        SDL_DestroySurface(surface);
        return true;
    }

    bool LoadMapFromImage(std::vector<std::vector<ColorRgb>>& map, const std::string& filename, const Size windowSize, SDL_FRect& bmpSize)
    {
        bmpSize = { 0, 0, 0, 0 };

        SDL_Surface* surface = IMG_Load(filename.c_str());
        if (!surface) {
            SDL_Log("Errore nel caricamento immagine '%s': %s", filename.c_str(), SDL_GetError());
            return false;
        }

        if (surface->format != SDL_PIXELFORMAT_RGBA8888)
        {
            SDL_Surface* converted = SDL_CreateSurface(surface->w, surface->h, SDL_PIXELFORMAT_RGBA8888);
            if (!converted) {
                SDL_Log("Errore nella creazione della surface RGBA: %s", SDL_GetError());
                SDL_DestroySurface(surface);
                return false;
            }
            SDL_BlitSurface(surface, nullptr, converted, nullptr);
            SDL_DestroySurface(surface);
            surface = converted;
        }

        if (surface->w <= 0 || surface->h <= 0) {
            SDL_Log("Dimensioni immagine non valide: %d x %d", surface->w, surface->h);
            SDL_DestroySurface(surface);
            return false;
        }

        bmpSize.w = static_cast<float>(surface->w);
        bmpSize.h = static_cast<float>(surface->h);
        bmpSize.x = (windowSize.w - bmpSize.w) / 2.0f;
        bmpSize.y = (windowSize.h - bmpSize.h) / 2.0f;

        // Ridimensiona la mappa
        map.clear();
        map.resize(surface->h, std::vector<ColorRgb>(surface->w));

        // Accedi ai pixel
        Uint32* pixels = static_cast<Uint32*>(surface->pixels);
        int pitch = surface->pitch / 4; // pitch in Uint32

        for (int y = 0; y < surface->h; ++y) {
            for (int x = 0; x < surface->w; ++x) {
                Uint32 pixel = pixels[y * pitch + x];
                Uint8 r = (pixel >> 24) & 0xFF;
                Uint8 g = (pixel >> 16) & 0xFF;
                Uint8 b = (pixel >> 8) & 0xFF;
                Uint8 a = pixel & 0xFF;

                map[y][x] = { r, g, b, a };
            }
        }

        SDL_DestroySurface(surface);
        return true;
    }

    void setProjectData(VariabiliGlobali& global)
    {
        if (!global.projectData) global.projectData = new PntHeader;

        std::string str = "PNT_";
        for (size_t i = 0; i < str.size(); ++i) global.projectData->magic[i] = str[i];
        global.projectData->version = 1;

        global.projectData->currentLevel = static_cast<uint32_t>(global.currentLevel);
        global.projectData->baseLevelPos = static_cast<uint32_t>(global.baseLevelPos);
        global.projectData->numLevels = static_cast<uint32_t>(global.win.Main.level().GetLevel().size());

        global.projectData->zoom = global.win.Main.level().GetZoom();
        global.projectData->alphaLevel = static_cast<uint32_t>(global.win.Main.level().GetAlphaLevel());
        global.projectData->currentfile = global.win.Main.level().GetCurrentfile();
        global.projectData->alphaGridCoord = global.win.Main.level().GetAlphaGridCoord();

        global.projectData->color_PP = global.win.Main.GetColor_PP();
        global.projectData->color_SF = global.win.Main.GetColor_SF();
        global.projectData->bgColor = global.win.Main.GetBgColor();
        global.projectData->toolsSettings = global.win.Main.GetTools().setting;
    }

    void setGlobalFromProjectData(VariabiliGlobali& global, const PntHeader& header, const std::vector<Level>& levels)
    {
        delete global.projectData;
        global.projectData = new PntHeader(header);

        global.currentLevel = static_cast<size_t>(header.currentLevel);
        global.baseLevelPos = static_cast<size_t>(header.baseLevelPos);
        global.win.Main.level().GetLevel() = levels;

        global.win.Main.level().GetZoom() = global.projectData->zoom;
        global.win.Main.level().GetAlphaLevel() = global.projectData->alphaLevel;
        global.win.Main.level().GetCurrentfile() = global.projectData->currentfile;
        global.win.Main.level().GetAlphaGridCoord() = global.projectData->alphaGridCoord;

        global.win.Main.GetColor_PP() = global.projectData->color_PP;
        global.win.Main.GetColor_SF() = global.projectData->color_SF;
        global.win.Main.GetBgColor() = global.projectData->bgColor;
        global.win.Main.GetTools().setting = global.projectData->toolsSettings;
    }

    bool saveProjectData(std::string& filename, VariabiliGlobali& global)
    {
        std::string extension = ".pnt";
        if (filename.find(extension) == std::string::npos) filename += extension;

        std::ofstream file(filename, std::ios::binary);

        if (!file.is_open()) return false;

        setProjectData(global);

        std::vector<Level>& levels = global.win.Main.level().GetLevel();
        PntHeader& header = *global.projectData;

        file.write(header.magic, 4);                                                                  // magic
        file.write(reinterpret_cast<const char*>(&header.version), sizeof(uint32_t));                 // version
        file.write(reinterpret_cast<const char*>(&header.currentLevel), sizeof(uint32_t));            // version
        file.write(reinterpret_cast<const char*>(&header.baseLevelPos), sizeof(uint32_t));               // baseLevelPos
        file.write(reinterpret_cast<const char*>(&header.numLevels), sizeof(uint32_t));               // numLevels

        file.write(reinterpret_cast<const char*>(&header.zoom), sizeof(float));                       // zoom
        Uint8 alphaLvl = header.alphaLevel ? 1 : 0;
        file.write(reinterpret_cast<const char*>(&alphaLvl), sizeof(Uint8));                          // alphaLevel
        uint32_t strLen = static_cast<uint32_t>(header.currentfile.size());                  
        file.write(reinterpret_cast<const char*>(&strLen), sizeof(uint32_t));                         // len -> currentfile
        file.write(header.currentfile.c_str(), strLen);                                               // currentfile
        file.write(reinterpret_cast<const char*>(&header.alphaGridCoord), sizeof(Coord));             // alphaGridCoord

        file.write(reinterpret_cast<const char*>(&header.color_PP), sizeof(ColorRgb));                // color_PP
        file.write(reinterpret_cast<const char*>(&header.color_SF), sizeof(ColorRgb));                // color_SF
        file.write(reinterpret_cast<const char*>(&header.bgColor), sizeof(ColorRgb));                 // bgColor
        file.write(reinterpret_cast<const char*>(&header.toolsSettings), sizeof(ToolsSettings));      // tools

        for (auto& level : levels)
        {
            uint32_t nameLen = static_cast<uint32_t>(level.name.size());
            file.write(reinterpret_cast<const char*>(&nameLen), sizeof(uint32_t));
            file.write(level.name.c_str(), nameLen);

            file.write(reinterpret_cast<const char*>(&level.moveCoord), sizeof(Coord));
            file.write(reinterpret_cast<const char*>(&level.size), sizeof(SDL_FRect));
            file.write(reinterpret_cast<const char*>(&level.zoomSize), sizeof(SDL_FRect));

            file.write(reinterpret_cast<const char*>(&level.opacity), sizeof(Uint8));

            Uint8 visible = level.isVisible ? 1 : 0;
            file.write(reinterpret_cast<const char*>(&visible), sizeof(Uint8));

            file.write(reinterpret_cast<const char*>(&level.bgColor), sizeof(ColorRgb));

            Size mapSize = {
                    static_cast<int>(level.map[0].size()),
                    static_cast<int>(level.map.size())
            };
            file.write(reinterpret_cast<const char*>(&mapSize), sizeof(Size));

            for (const auto& riga : level.map)
            {
                file.write(reinterpret_cast<const char*>(riga.data()), riga.size() * sizeof(ColorRgb));
            }
        }

        for (size_t i = 0; i < extension.size(); ++i) filename.pop_back();
        global.win.Main.level().GetCurrentfileProject() = filename;

        file.close();
        return true;
    }

    bool loadProjectData(std::string& filename, VariabiliGlobali& global)
    {
        std::string extension = ".pnt";
        if (filename.find(extension) == std::string::npos) return false;

        std::ifstream file(filename, std::ios::binary);

        if (!file.is_open()) return false;

        PntHeader header;

        file.read(header.magic, 4);                                                         // magic
        file.read(reinterpret_cast<char*>(&header.version), sizeof(uint32_t));              // version
        file.read(reinterpret_cast<char*>(&header.currentLevel), sizeof(uint32_t));         // version
        file.read(reinterpret_cast<char*>(&header.baseLevelPos), sizeof(uint32_t));            // baseLevelPos
        file.read(reinterpret_cast<char*>(&header.numLevels), sizeof(uint32_t));            // numLevels

        file.read(reinterpret_cast<char*>(&header.zoom), sizeof(float));                    // zoom
        Uint8 alphaLvl;
        file.read(reinterpret_cast<char*>(&alphaLvl), sizeof(Uint8));                       // alphaLevel
        header.alphaLevel = alphaLvl ? 1 : 0;
        uint32_t strLen;
        file.read(reinterpret_cast<char*>(&strLen), sizeof(uint32_t));                      // len -> currentfile
        header.currentfile.resize(strLen);
        file.read(reinterpret_cast<char*>(&header.currentfile[0]), strLen);                 // currentfile
        file.read(reinterpret_cast<char*>(&header.alphaGridCoord), sizeof(Coord));          // alphaGridCoord

        file.read(reinterpret_cast<char*>(&header.color_PP), sizeof(ColorRgb));             // color_PP
        file.read(reinterpret_cast<char*>(&header.color_SF), sizeof(ColorRgb));             // color_SF
        file.read(reinterpret_cast<char*>(&header.bgColor), sizeof(ColorRgb));              // bgColor
        file.read(reinterpret_cast<char*>(&header.toolsSettings), sizeof(ToolsSettings));   // tools

        std::string str = "PNT_";
        for (size_t i = 0; i < str.size(); ++i) if (header.magic[i] != str[i])
        {
            SDL_Log("Errore di corrispondenza del numero magico, il file potrebbe essere esterno o corrotto");
            return false;
        }

        std::vector<Level> levels;

        levels.resize(header.numLevels);
        for (size_t i = 0; i < header.numLevels; ++i)
        {
            Level& level = levels[i];

            uint32_t nameLen;
            file.read(reinterpret_cast<char*>(&nameLen), sizeof(uint32_t));
            level.name.resize(nameLen);
            if (nameLen > 0)
            {
                file.read(reinterpret_cast<char*>(&level.name[0]), nameLen);
            }

            file.read(reinterpret_cast<char*>(&level.moveCoord), sizeof(Coord));
            file.read(reinterpret_cast<char*>(&level.size), sizeof(SDL_FRect));
            file.read(reinterpret_cast<char*>(&level.zoomSize), sizeof(SDL_FRect));

            file.read(reinterpret_cast<char*>(&level.opacity), sizeof(Uint8));

            Uint8 visible;
            file.read(reinterpret_cast<char*>(&visible), sizeof(Uint8));
            level.isVisible = visible ? 1 : 0;

            file.read(reinterpret_cast<char*>(&level.bgColor), sizeof(ColorRgb));

            Size mapSize;
            file.read(reinterpret_cast<char*>(&mapSize), sizeof(Size));

            level.map.resize(mapSize.h);
            for (size_t y = 0; y < mapSize.h; ++y)
            {
                level.map[y].resize(mapSize.w);
                if(!file.read(reinterpret_cast<char*>(level.map[y].data()), mapSize.w * sizeof(ColorRgb))) 
                {
                    SDL_Log("Errore fatale: Fallita lettura dati pixel alla riga %zu", y);
                    return false;
                }
            }
            level.startMap = level.map;

            APP::updateCronology(global);

            level.canvas = TEXTURE::CreateTextureFromMap(global.win.Main.getRenderer(), level.map);
            if (!level.canvas) {
                SDL_Log("Avviso: Impossibile creare la texture SDL per il livello %s", level.name.c_str());
            }
        }

        setGlobalFromProjectData(global, header, levels);

        for (size_t i = 0; i < extension.size(); ++i) filename.pop_back();
        global.win.Main.level().GetCurrentfileProject() = filename;

        file.close();
        return true;
    }
}