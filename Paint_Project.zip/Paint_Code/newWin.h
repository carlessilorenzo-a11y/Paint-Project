#pragma once

#include "winTemplate.h"

class New : public Window
{
protected:
    VariabiliGlobali& global;
    rectText back;
    rectText next;
    std::vector<TextBox*> textbox;
    float wBack;
    bool pendingCloseSetNew;
    bool level;
    std::string strTavolaColori;

public:
    New(VariabiliGlobali& global);

    void Update() override;
    void Draw() override;

    // back (Get/Set)
    rectText& GetBack();
    const rectText& GetBack() const;
    void SetBack(const rectText& newBack);

    // next (Get/Set)
    rectText& GetNext();
    const rectText& GetNext() const;
    void SetNext(const rectText& newNext);

    // wBack (Get/Set)
    float GetWBack() const;
    void SetWBack(float newWBack);

    // pendingCloseSetNew (Get/Set)
    bool IsPendingCloseSetNew() const;
    void SetPendingCloseSetNew(bool isPending);

    bool IsLevel() const;
    void SetIsLevel(bool isLevel);

    // strTavolaColori (Get/Set)
    const std::string& GetStrTavolaColori() const;
    void SetStrTavolaColori(const std::string& newStr);

    // textbox (std::vector<TextBox*>)
    std::vector<TextBox*>& GetTextbox();
    const std::vector<TextBox*>& GetTextbox() const;
    void SetTextbox(const std::vector<TextBox*>& newTextbox);
};