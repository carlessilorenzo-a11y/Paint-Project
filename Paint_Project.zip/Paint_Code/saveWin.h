#pragma once

#include "winTemplate.h"

class Save : public Window
{
protected:
    VariabiliGlobali& global;
    bool error;
    bool project;
    rectText back;
    rectText next;
    TextBox* textbox;
    std::vector<FileRect> fileType;

public:
    Save(VariabiliGlobali& global);

    void Update() override;
    void Draw() override;

    // error (Get/Set)
    bool HasError() const;
    void SetError(bool hasError);

    // project (Get/Set)
    bool IsProject() const;
    void SetProject(bool newProject);

    // back (Get/Set)
    rectText& GetBack();
    const rectText& GetBack() const;
    void SetBack(const rectText& newBack);

    // next (Get/Set)
    rectText& GetNext();
    const rectText& GetNext() const;
    void SetNext(const rectText& newNext);

    // textbox (Get/Set)
    TextBox* GetTextbox();
    const TextBox* GetTextbox() const;
    void SetTextbox(TextBox* newTextbox);

    // fileType (std::vector<FileRect>)
    std::vector<FileRect>& GetFileType();
    const std::vector<FileRect>& GetFileType() const;
    void SetFileType(const std::vector<FileRect>& newFileType);
};