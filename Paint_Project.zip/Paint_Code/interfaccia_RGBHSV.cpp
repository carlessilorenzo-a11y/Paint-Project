#define SDL_MAIN_HANDLED
#include "interfaccia_RGBHSV.h"
#include "variabiliGlobali.h"
#include "slider.h"
#include "textBox.h"
#include "graphics.h"
#include "app.h"

Interfaccia_RGBHSV::Interfaccia_RGBHSV(VariabiliGlobali& global, SDL_FRect& staticRect, SDL_FRect& continueRect, ColorRgb& finalColor, bool& colorPP) :
    global(global),
    staticRect(staticRect),
    continueRect(continueRect),
    finalColor(finalColor),
    colorPP(colorPP),
    rectCerchio{ 0.0f, 0.0f, 0.0f, 0.0f },
    centro{ 0.0f, 0.0f },
    RgbDegree(0.0f),
    outerRadius(0.0f),
    innerRadius(0.0f),
    triangolo{},
    currentColor{ 0, 0, 0, 255 },
    drawCursor(false),
    intersectionTriangle{ 0.0f, 0.0f },
    textbox{},
    str{ "R", "G", "B", "H", "S", "V" },
    barreScelta{},
    valPercentuale{},
    colorWheel(nullptr),
    HSV_Triangle(nullptr)
{}

float Interfaccia_RGBHSV::getPercentualeRGB(float variabile)
{
    int maxVal = 255;
    return variabile / (maxVal / 100.0f);
}

ColorRgb Interfaccia_RGBHSV::getHueColor(float h)
{
    // Ci assicuriamo che l'angolo sia nel range 0-360
    h = fmod(h, 360.0f);
    if (h < 0) h += 360.0f;

    float s = 1.0f; // Saturazione massima (bordo del cerchio)
    float v = 1.0f; // Valore massimo (massima brillantezza)

    float c = v * s; // Croma
    float x = c * (1.0f - std::abs(fmod(h / 60.0f, 2.0f) - 1.0f));
    float m = v - c;

    float r_temp, g_temp, b_temp;

    if (h >= 0 && h < 60) { r_temp = c; g_temp = x; b_temp = 0; }
    else if (h >= 60 && h < 120) { r_temp = x; g_temp = c; b_temp = 0; }
    else if (h >= 120 && h < 180) { r_temp = 0; g_temp = c; b_temp = x; }
    else if (h >= 180 && h < 240) { r_temp = 0; g_temp = x; b_temp = c; }
    else if (h >= 240 && h < 300) { r_temp = x; g_temp = 0; b_temp = c; }
    else { r_temp = c; g_temp = 0; b_temp = x; }

    ColorRgb color = {
        static_cast<Uint8>((r_temp + m) * 255),
        static_cast<Uint8>((g_temp + m) * 255),
        static_cast<Uint8>((b_temp + m) * 255),
        255
    };

    return color;
}

float Interfaccia_RGBHSV::getAngleFromRGB(ColorRgb color)
{
    float r = color.r / 255.0f;
    float g = color.g / 255.0f;
    float b = color.b / 255.0f;

    float maxVal = std::max({ r, g, b });
    float minVal = std::min({ r, g, b });
    float delta = maxVal - minVal;

    float h = 0.0f;

    if (delta == 0) {
        return 0.0f;
    }

    if (maxVal == r) {
        h = 60.0f * fmod(((g - b) / delta), 6.0f);
    }
    else if (maxVal == g) {
        h = 60.0f * (((b - r) / delta) + 2.0f);
    }
    else if (maxVal == b) {
        h = 60.0f * (((r - g) / delta) + 4.0f);
    }

    if (h < 0) {
        h += 360.0f;
    }

    return h;
}

bool Interfaccia_RGBHSV::isInRadius(float x, float y, float& dx, float& dy)
{
    dx = x - centro.x + rectCerchio.x;
    dy = y - centro.y + rectCerchio.y;
    float distance = std::sqrt(dx * dx + dy * dy);

    return (distance >= innerRadius && distance <= outerRadius);
}

SDL_Texture* Interfaccia_RGBHSV::createColorWheel()
{
    int w = static_cast<int>(rectCerchio.w);
    int h = static_cast<int>(rectCerchio.h);

    SDL_Texture* tex = SDL_CreateTexture(
        global.win.color.getRenderer(),
        SDL_PIXELFORMAT_RGBA8888,
        SDL_TEXTUREACCESS_STREAMING,
        w, h
    );

    if (!tex) {
        SDL_Log("Impossibile creare la texture: %s", SDL_GetError());
        return nullptr;
    }

    void* pixels = nullptr;
    int pitch = 0;

    if (!SDL_LockTexture(tex, nullptr, &pixels, &pitch))
    {
        SDL_Log("Errore nel lock della texture: %s", SDL_GetError());
        SDL_DestroyTexture(tex);
        return nullptr;
    }

    Uint32* buf = static_cast<Uint32*>(pixels);

    for (int y = 0; y < h; ++y)
    {
        for (int x = 0; x < w; ++x)
        {
            float dx, dy;
            if (isInRadius(static_cast<float>(x), static_cast<float>(y), dx, dy))
            {
                float angle = std::atan2(dy, dx);
                float hue = APP::fromRadToDeg(angle);
                if (hue < 0) hue += 360.0f;

                ColorRgb c = getHueColor(hue);
                c.a = 255;
                
                buf[y * (pitch / 4) + x] = (c.r << 24) | (c.g << 16) | (c.b << 8) | c.a;
            }
            else
            {
                buf[y * (pitch / 4) + x] = 0x00000000;
            }
        }
    }

    SDL_UnlockTexture(tex);

    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);

    return tex;
}

SDL_Texture* Interfaccia_RGBHSV::createHSV_Triangle()
{
    Coord rectCoord = {
        centro.x - innerRadius,
        centro.y - innerRadius
    };
    int texSize = static_cast<int>(innerRadius * 2);

    SDL_Texture* texture = SDL_CreateTexture(
        global.win.color.getRenderer(),
        SDL_PIXELFORMAT_RGBA8888,
        SDL_TEXTUREACCESS_STREAMING,
        texSize,
        texSize
    );

    void* pixels = nullptr;
    int pitch = 0;

    if (!SDL_LockTexture(texture, nullptr, &pixels, &pitch))
    {
        SDL_Log("Errore nel lock della texture: %s", SDL_GetError());
        SDL_DestroyTexture(texture);
        return nullptr;
    }

    Uint32* buf = static_cast<Uint32*>(pixels);

    for (int y = 0; y < texSize; ++y)
    {
        for (int x = 0; x < texSize; ++x)
        {
            float dx = x + rectCoord.x;
            float dy = y + rectCoord.y;
            float w1, w2, w3;

            if (isPixelInTriangle(&triangolo, dx, dy, w1, w2, w3))
            {
                ColorRgb c = getRgbFromCoefficient(w1, w2, w3);
                c.a = 255;

                buf[y * (pitch / 4) + x] = (c.r << 24) | (c.g << 16) | (c.b << 8) | c.a;
            }
            else
            {
                buf[y * (pitch / 4) + x] = 0X00000000;
            }
        }
    }

    SDL_UnlockTexture(texture);

    SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);

    return texture;
}

void Interfaccia_RGBHSV::SetTriangolo()
{
    Triangolo& tr = triangolo;

    tr.p1 = {
        centro.x + innerRadius * std::cos(APP::fromDegToRad(RgbDegree)),
        centro.y + innerRadius * std::sin(APP::fromDegToRad(RgbDegree))
    };

    tr.p2 = {
        centro.x + innerRadius * std::cos(APP::fromDegToRad(RgbDegree + 360.0f / 3.0f)),
        centro.y + innerRadius * std::sin(APP::fromDegToRad(RgbDegree + 360.0f / 3.0f))
    };

    tr.p3 = {
        centro.x + innerRadius * std::cos(APP::fromDegToRad(RgbDegree - 360.0f / 3.0f)),
        centro.y + innerRadius * std::sin(APP::fromDegToRad(RgbDegree - 360.0f / 3.0f))
    };

    if (HSV_Triangle) SDL_DestroyTexture(HSV_Triangle);
    HSV_Triangle = createHSV_Triangle();
}

bool Interfaccia_RGBHSV::isPixelInTriangle(Triangolo* tr, float x, float y, float& w1, float& w2, float& w3)
{
    float det = (tr->p2.y - tr->p3.y) * (tr->p1.x - tr->p3.x) + (tr->p3.x - tr->p2.x) * (tr->p1.y - tr->p3.y);

    w1 = ((tr->p2.y - tr->p3.y) * (x - tr->p3.x) + (tr->p3.x - tr->p2.x) * (y - tr->p3.y)) / det;
    w2 = ((tr->p3.y - tr->p1.y) * (x - tr->p3.x) + (tr->p1.x - tr->p3.x) * (y - tr->p3.y)) / det;
    w3 = 1 - w1 - w2;

    return ((w1 >= 0 && w1 <= 1) && (w2 >= 0 && w2 <= 1) && (w3 >= 0 && w3 <= 1));
}

ColorRgb Interfaccia_RGBHSV::getRgbFromCoefficient(float w1, float w2, float w3)
{
    ColorRgb c = {
        static_cast<Uint8>((currentColor.r * w1) + (255 * w2) + (0 * w3)),
        static_cast<Uint8>((currentColor.g * w1) + (255 * w2) + (0 * w3)),
        static_cast<Uint8>((currentColor.b * w1) + (255 * w2) + (0 * w3)),
        255
    };

    return c;
}

void Interfaccia_RGBHSV::getWeightsFromRGB(ColorRgb finalCol, float& w1, float& w2, float& w3)
{
    // Il sistema si basa su:
    // R_final = w1*R_hue + w2*255 + w3*0
    // Poiché R=G=B per bianco e nero, usiamo la luminosità o una componente
    // per isolare i pesi.

    float r = finalCol.r / 255.0f;
    float g = finalCol.g / 255.0f;
    float b = finalCol.b / 255.0f;

    float hueR = currentColor.r / 255.0f;
    float hueG = currentColor.g / 255.0f;
    float hueB = currentColor.b / 255.0f;

    // Calcoliamo la Saturation (S) e il Value (V) in stile HSV semplificato
    // per mappare i pesi baricentrici del triangolo
    float maxC = std::max({ r, g, b });
    float minC = std::min({ r, g, b });
    float delta = maxC - minC;

    // In questo modello di triangolo specifico:
    // w3 (Nero) aumenta se il valore massimo cala
    // w2 (Bianco) aumenta se il valore minimo cresce
    // w1 (Colore puro) è ciò che resta

    w3 = 1.0f - maxC; // Distanza dal vertice nero
    w2 = minC;        // Distanza dal vertice bianco
    w1 = 1.0f - w2 - w3;

    // Clamp di sicurezza per errori di floating point
    w1 = std::max(0.0f, std::min(1.0f, w1));
    w2 = std::max(0.0f, std::min(1.0f, w2));
    w3 = std::max(0.0f, std::min(1.0f, w3));
}

Coord Interfaccia_RGBHSV::intersectionLineandLine(Coord p1, Coord p2, Coord p3, Coord p4)
{
    float x;
    float y;

    float dx1 = p2.x - p1.x;
    float dx2 = p4.x - p3.x;

    const float eps = 0.000001f;

    if (std::abs(dx1) < eps)
    {
        x = p1.x;
        float m2 = (p4.y - p3.y) / (std::abs(dx2) < eps ? eps : dx2);
        y = m2 * (x - p3.x) + p3.y;
    }
    else if (std::abs(dx2) < eps)
    {
        x = p3.x;
        float m1 = (p2.y - p1.y) / dx1;
        y = m1 * (x - p1.x) + p1.y;
    }
    else
    {
        float m1 = (p2.y - p1.y) / dx1;
        float m2 = (p4.y - p3.y) / dx2;

        if (std::abs(m1 - m2) < eps) return p1;

        x = (m1 * p1.x - m2 * p3.x + p3.y - p1.y) / (m1 - m2);
        y = m1 * (x - p1.x) + p1.y;
    }

    return { x, y };
}

void Interfaccia_RGBHSV::UpdateCursor(bool moving, Triangolo* tr)
{
    static float savedRelativeAngle = 0.0f;
    static float savedDistance = 0.0f;
    static float lastP1Angle = 0.0f;

    float dx1 = tr->p1.x - centro.x;
    float dy1 = tr->p1.y - centro.y;
    float currentP1Angle = std::atan2(dy1, dx1);

    if (moving)
    {
        float totalAngleRad = currentP1Angle + savedRelativeAngle;

        intersectionTriangle.x = centro.x + savedDistance * std::cos(totalAngleRad);
        intersectionTriangle.y = centro.y + savedDistance * std::sin(totalAngleRad);
    }
    else
    {
        float dxCursor = intersectionTriangle.x - centro.x;
        float dyCursor = intersectionTriangle.y - centro.y;

        savedDistance = std::sqrt(dxCursor * dxCursor + dyCursor * dyCursor);
        float cursorAngle = std::atan2(dyCursor, dxCursor);

        savedRelativeAngle = cursorAngle - currentP1Angle;
    }

    float w1, w2, w3;
    isPixelInTriangle(tr, intersectionTriangle.x, intersectionTriangle.y, w1, w2, w3);
    finalColor = getRgbFromCoefficient(w1, w2, w3);
}

void Interfaccia_RGBHSV::SetRGBHSV(char type, float newVal)
{
    float w1 = 0.0f, w2 = 0.0f, w3 = 0.0f;
    bool moving = false;

    // --- FASE 1: AGGIORNAMENTO DATI ---
    if (type == 'R' || type == 'G' || type == 'B')
    {
        // Convertiamo newVal (0-100) in scala 0-255
        int val255 = static_cast<int>(std::round(newVal * 2.55f));

        if (type == 'R') finalColor.r = val255;
        if (type == 'G') finalColor.g = val255;
        if (type == 'B') finalColor.b = val255;

        // Sincronizziamo l'angolo HUE del cerchio esterno
        RgbDegree = getAngleFromRGB(finalColor);
        currentColor = getHueColor(RgbDegree);
        SetTriangolo();

        // Calcoliamo i pesi per muovere il cursore
        getWeightsFromRGB(finalColor, w1, w2, w3);
    }
    else if (type == 'H')
    {
        RgbDegree = newVal; // 0-360
        currentColor = getHueColor(RgbDegree);
        SetTriangolo();

        // Manteniamo la posizione attuale del cursore nel triangolo (S e V costanti)
        isPixelInTriangle(&triangolo, intersectionTriangle.x, intersectionTriangle.y, w1, w2, w3);

        moving = true;
    }
    else if (type == 'S' || type == 'V')
    {
        // Otteniamo i pesi attuali per estrarre S e V
        isPixelInTriangle(&triangolo, intersectionTriangle.x, intersectionTriangle.y, w1, w2, w3);

        float s_attuale = (w1 + w2 > 0) ? (w1 / (w1 + w2)) * 100.0f : 0.0f;
        float v_attuale = (w1 + w2) * 100.0f;

        if (type == 'S') s_attuale = newVal; // 0-100
        if (type == 'V') v_attuale = newVal; // 0-100

        // Trasformiamo S e V (0-100) in pesi baricentrici (0.0-1.0)
        float S_norm = s_attuale / 100.0f;
        float V_norm = v_attuale / 100.0f;

        w1 = S_norm * V_norm;
        w2 = (1.0f - S_norm) * V_norm;
        w3 = 1.0f - V_norm;
    }
    else return;

    // --- FASE 2: AGGIORNAMENTO POSIZIONE FISICA DEL CURSORE ---

    // Spostiamo le coordinate X e Y del cursore nel triangolo ruotato
    intersectionTriangle.x = (triangolo.p1.x * w1) + (triangolo.p2.x * w2) + (triangolo.p3.x * w3);
    intersectionTriangle.y = (triangolo.p1.y * w1) + (triangolo.p2.y * w2) + (triangolo.p3.y * w3);

    // Ricalcoliamo il colore finale dai pesi per coerenza totale
    finalColor = getRgbFromCoefficient(w1, w2, w3);

    drawCursor = true;
    UpdateCursor(moving, &triangolo);
}

void Interfaccia_RGBHSV::UpdateRGBHSV()
{
    for (size_t i = 0; i < str.size(); ++i)
    {
        if (str[i] == "R") textbox[i]->setText(std::to_string(getPercentualeRGB(finalColor.r)));
        else if (str[i] == "G") textbox[i]->setText(std::to_string(getPercentualeRGB(finalColor.g)));
        else if (str[i] == "B") textbox[i]->setText(std::to_string(getPercentualeRGB(finalColor.b)));
        else if (str[i] == "H") textbox[i]->setText(std::to_string(RgbDegree));
        else if (str[i] == "S" || str[i] == "V")
        {
            float w1, w2, w3;
            isPixelInTriangle(&triangolo, intersectionTriangle.x, intersectionTriangle.y, w1, w2, w3);

            if (str[i] == "S") textbox[i]->setText(std::to_string((w1 + w2) * 100.0f));
            else if (str[i] == "V") textbox[i]->setText(std::to_string((w1 / (w1 + w2)) * 100.0f));
        }
    }
}

void Interfaccia_RGBHSV::Set()
{
    float size = 320.0f;
    rectCerchio = {
        size / 10.0f,
        size / 7.0f,
        size / 10.0f * 8.0f,
        size / 10.0f * 8.0f
    };

    centro = {
        rectCerchio.x + rectCerchio.w / 2.0f,
        rectCerchio.y + rectCerchio.h / 2.0f
    };

    outerRadius = rectCerchio.w / 2.0f;
    innerRadius = outerRadius * 0.8f;

    currentColor = getHueColor(RgbDegree);
    finalColor = currentColor;

    SetTriangolo();
    intersectionTriangle = triangolo.p1;
    UpdateCursor(false, &triangolo);

    SDL_FRect temp = {
        rectCerchio.x - rectCerchio.w * 0.1f / 2.0f,
        rectCerchio.y - rectCerchio.h * 0.1f / 2.0f,
        rectCerchio.w * 1.1f,
        rectCerchio.h * 1.1f
    };

    float h = temp.h / 11.0f;
    ColorRgb color = { 64, 64, 64, 255 };
    valPercentuale.resize(str.size());

    textbox.clear();
    barreScelta.clear();

    for (size_t i = 0; i < str.size(); ++i)
    {
        SDL_FRect rect = {
            global.win.color.getSize().w / 10.0f * 8.75f,
            temp.y + (h * i) * 2,
            global.win.color.getSize().w / 11.0f,
            h
        };
        textbox.push_back(
            new TextBox(
                rect,
                TypeTxtBox::NUMBERS,
                3,
                0,
                (str[i] == "H") ? 360.0f : 100.0f,
                2,
                global,
                &global.win.color,
                color
            )
        );

        float newVal = 0.0f;
        if (str[i] == "R") newVal = getPercentualeRGB(finalColor.r);
        else if (str[i] == "G") newVal = getPercentualeRGB(finalColor.g);
        else if (str[i] == "B") newVal = getPercentualeRGB(finalColor.b);
        else if (str[i] == "H") newVal = RgbDegree;
        else if (str[i] == "S" || str[i] == "V")
        {
            float w1, w2, w3;
            isPixelInTriangle(&triangolo, intersectionTriangle.x, intersectionTriangle.y, w1, w2, w3);

            if (str[i] == "S") newVal = (w1 + w2) * 100.0f;
            else if (str[i] == "V") newVal = (w1 / (w1 + w2)) * 100.0f;
        }
        textbox[i]->setText(std::to_string(newVal));

        rect = {
            rect.x / 10.0f * 6.45f,
            rect.y + (rect.h / 4.0f) / 2.0f,
            rect.w * 3.25f,
            rect.h * 3.0f / 4.0f
        };
        barreScelta.push_back(
            new Slider(
                rect,
                { 0, 0, 0, 255 },
                color,
                newVal,
                (str[i] == "H") ? 360.0f : 100.0f,
                0,
                true,
                &global.win.color
            )
        );
    }

    if (colorWheel) SDL_DestroyTexture(colorWheel);
    colorWheel = createColorWheel();

    if (HSV_Triangle) SDL_DestroyTexture(HSV_Triangle);
    HSV_Triangle = createHSV_Triangle();
}

void Interfaccia_RGBHSV::Draw()
{
    SDL_SetRenderDrawColor(global.win.color.getRenderer(), 30, 30, 30, 255);
    SDL_RenderClear(global.win.color.getRenderer());

    if (colorWheel)
    {
        SDL_RenderTexture(global.win.color.getRenderer(), colorWheel, nullptr, &rectCerchio);
    }
    if (HSV_Triangle)
    {
        SDL_FRect rect = {
            centro.x - innerRadius,
            centro.y - innerRadius,
            innerRadius * 2.0f,
            innerRadius * 2.0f
        };

        SDL_RenderTexture(global.win.color.getRenderer(), HSV_Triangle, nullptr, &rect);
    }

    SDL_SetRenderDrawColor(global.win.color.getRenderer(), 0, 0, 0, 255);
    Triangolo& tr = triangolo;
    SDL_RenderLine(global.win.color.getRenderer(), tr.p1.x, tr.p1.y, tr.p2.x, tr.p2.y);
    SDL_RenderLine(global.win.color.getRenderer(), tr.p2.x, tr.p2.y, tr.p3.x, tr.p3.y);
    SDL_RenderLine(global.win.color.getRenderer(), tr.p1.x, tr.p1.y, tr.p3.x, tr.p3.y);

    GRAPHICS::RenderCircle(global.win.color.getRenderer(), centro.x, centro.y, innerRadius, { 0, 0, 0, 255 });
    GRAPHICS::RenderCircle(global.win.color.getRenderer(), centro.x, centro.y, outerRadius, { 0, 0, 0, 255 });

    GRAPHICS::RenderCircle(global.win.color.getRenderer(), intersectionTriangle.x, intersectionTriangle.y, 3.0f, { 0, 0, 0, 255 });
    GRAPHICS::RenderCircle(global.win.color.getRenderer(), intersectionTriangle.x, intersectionTriangle.y, 4.0f, { 0, 0, 0, 255 });

    if (!textbox.empty())
    {
        for (size_t i = 0; i < textbox.size(); ++i)
        {
            textbox[i]->Draw();

            SDL_FRect rect = {
                textbox[i]->getRect().x / 10.0f * 6.0f,
                textbox[i]->getRect().y,
                textbox[i]->getRect().w / 3.0f,
                staticRect.h / 11.0f
            };

            GRAPHICS::PrintCentered(
                str[i] + ":",
                &rect,
                10,
                global.win.color.getRenderer(),
                global.win.color.getTextures()
            );

            for (const auto& slider : barreScelta)
            {
                slider->Draw();
            }
        }
    }
}

void Interfaccia_RGBHSV::Update()
{
    if (!textbox.empty())
    {
        for (size_t i = 0; i < textbox.size(); ++i)
        {
            bool update = false;
            textbox[i]->Update(&update);

            if (update)
            {
                SetRGBHSV(str[i][0], std::stof(textbox[i]->getText()));
            }
        }
    }

    if (APP::isPixelInRect(global.click, &continueRect))
    {
        if (finalColor.r < 0) finalColor.r = 0;
        else if (finalColor.r > 255) finalColor.r = 255;
        if (finalColor.g < 0) finalColor.g = 0;
        else if (finalColor.g > 255) finalColor.g = 255;
        if (finalColor.b < 0) finalColor.b = 0;
        else if (finalColor.b > 255) finalColor.b = 255;
        if (finalColor.a < 0) finalColor.a = 0;
        else if (finalColor.a > 255) finalColor.a = 255;

        ColorRgb& color = (colorPP) ? global.win.Main.GetColor_PP() : global.win.Main.GetColor_SF();
        color = finalColor;

        global.win.color.Destroy();
        global.click = { -1, -1 };
        return;
    }
}

void Interfaccia_RGBHSV::UpdateRgbCerchio(bool cursorInMove, bool cursorRealesed)
{
    static bool moving = false;
    static bool isCircle = false;
    static bool isTriangle = false;

    SDL_GetMouseState(&global.cursorPosition.x, &global.cursorPosition.y);
    Coord clickCircle = {
        global.click.x - rectCerchio.x,
        global.click.y - rectCerchio.y
    };
    Coord clickTriangle = {
        global.click.x,
        global.click.y
    };

    if (!cursorInMove && !cursorRealesed && !moving)
    {
        float dx, dy, w1, w2, w3;

        if (isInRadius(clickCircle.x, clickCircle.y, dx, dy))
        {
            float angle = std::atan2(dy, dx);

            float hue = angle * static_cast<float>(180.0f / M_PI);
            if (hue < 0) hue += 360.0f;

            RgbDegree = hue;
            currentColor = getHueColor(hue);

            SetTriangolo();
            UpdateCursor(true, &triangolo);

            moving = true;
            isCircle = true;
        }
        else if (isPixelInTriangle(&triangolo, clickTriangle.x, clickTriangle.y, w1, w2, w3))
        {
            intersectionTriangle = clickTriangle;

            UpdateCursor(false, &triangolo);

            isTriangle = true;
            moving = true;
            drawCursor = true;
        }
    }
    else if (cursorRealesed)
    {
        moving = false;
        isCircle = false;
        isTriangle = false;
    }
    else if (cursorInMove && moving)
    {
        if (isCircle)
        {
            float dx, dy;
            isInRadius(clickCircle.x, clickCircle.y, dx, dy);

            float angle = std::atan2(dy, dx);

            float hue = angle * static_cast<float>(180.0f / M_PI);
            if (hue < 0) hue += 360.0f;

            UpdateCursor(true, &triangolo);

            RgbDegree = hue;

            currentColor = getHueColor(hue);
            SetTriangolo();
        }
        else if (isTriangle)
        {
            float w1, w2, w3;
            if (isPixelInTriangle(&triangolo, clickTriangle.x, clickTriangle.y, w1, w2, w3))
            {
                intersectionTriangle = clickTriangle;
            }
            else
            {
                Triangolo* tr = &triangolo;

                float d1 = std::sqrt((tr->p1.x - clickTriangle.x) * (tr->p1.x - clickTriangle.x) + (tr->p1.y - clickTriangle.y) * (tr->p1.y - clickTriangle.y));
                float d2 = std::sqrt((tr->p2.x - clickTriangle.x) * (tr->p2.x - clickTriangle.x) + (tr->p2.y - clickTriangle.y) * (tr->p2.y - clickTriangle.y));
                float d3 = std::sqrt((tr->p3.x - clickTriangle.x) * (tr->p3.x - clickTriangle.x) + (tr->p3.y - clickTriangle.y) * (tr->p3.y - clickTriangle.y));

                Coord p1 = { 0.0f, 0.0f }, p2 = { 0.0f, 0.0f };

                if (d1 >= d2 && d1 >= d3)
                {
                    p1 = tr->p2;
                    p2 = tr->p3;
                }
                else if (d2 >= d1 && d2 >= d3)
                {
                    p1 = tr->p1;
                    p2 = tr->p3;
                }
                else
                {
                    p1 = tr->p1;
                    p2 = tr->p2;
                }

                Coord hue = intersectionLineandLine(p1, p2, centro, clickTriangle);
                intersectionTriangle = hue;

                float w1, w2, w3;
                isPixelInTriangle(&triangolo, hue.x, hue.y, w1, w2, w3);
            }

            UpdateCursor(false, &triangolo);
        }
    }

    for (size_t i = 0; i < barreScelta.size(); ++i)
    {
        float valore = -1.0f;
        barreScelta[i]->Update(global.click, valore, cursorInMove, cursorRealesed);

        if (valore != -1.0f)
        {
            SetRGBHSV(str[i][0], valore);
            break;
        }
        else
        {
            barreScelta[i]->GetValore() = std::stof(textbox[i]->getText());
        }
    }
    UpdateRGBHSV();
}

// RectCerchio
SDL_FRect& Interfaccia_RGBHSV::GetRectCerchio() { return rectCerchio; }
const SDL_FRect& Interfaccia_RGBHSV::GetRectCerchio() const { return rectCerchio; }
void Interfaccia_RGBHSV::SetRectCerchio(const SDL_FRect& rect) { rectCerchio = rect; }

// Centro
Coord& Interfaccia_RGBHSV::GetCentro() { return centro; }
const Coord& Interfaccia_RGBHSV::GetCentro() const { return centro; }
void Interfaccia_RGBHSV::SetCentro(const Coord& c) { centro = c; }

// RgbDegree
float& Interfaccia_RGBHSV::GetRgbDegree() { return RgbDegree; }
float Interfaccia_RGBHSV::GetRgbDegree() const { return RgbDegree; }
void Interfaccia_RGBHSV::SetRgbDegree(float degree) { RgbDegree = degree; }

// Radii
float& Interfaccia_RGBHSV::GetOuterRadius() { return outerRadius; }
float Interfaccia_RGBHSV::GetOuterRadius() const { return outerRadius; }
void Interfaccia_RGBHSV::SetOuterRadius(float radius) { outerRadius = radius; }

float& Interfaccia_RGBHSV::GetInnerRadius() { return innerRadius; }
float Interfaccia_RGBHSV::GetInnerRadius() const { return innerRadius; }
void Interfaccia_RGBHSV::SetInnerRadius(float radius) { innerRadius = radius; }

// Triangolo
Triangolo& Interfaccia_RGBHSV::GetTriangolo() { return triangolo; }
const Triangolo& Interfaccia_RGBHSV::GetTriangolo() const { return triangolo; }
void Interfaccia_RGBHSV::SetTriangolo(const Triangolo& t) { triangolo = t; }

// Colori
ColorRgb& Interfaccia_RGBHSV::GetCurrentColor() { return currentColor; }
const ColorRgb& Interfaccia_RGBHSV::GetCurrentColor() const { return currentColor; }
void Interfaccia_RGBHSV::SetCurrentColor(const ColorRgb& color) { currentColor = color; }

// Cursor & Intersection
bool& Interfaccia_RGBHSV::GetDrawCursor() { return drawCursor; }
bool Interfaccia_RGBHSV::GetDrawCursor() const { return drawCursor; }
void Interfaccia_RGBHSV::SetDrawCursor(bool draw) { drawCursor = draw; }

Coord& Interfaccia_RGBHSV::GetIntersectionTriangle() { return intersectionTriangle; }
const Coord& Interfaccia_RGBHSV::GetIntersectionTriangle() const { return intersectionTriangle; }
void Interfaccia_RGBHSV::SetIntersectionTriangle(const Coord& coord) { intersectionTriangle = coord; }

SDL_FRect& Interfaccia_RGBHSV::GetStaticRect() { return staticRect; }
const SDL_FRect& Interfaccia_RGBHSV::GetStaticRect() const { return staticRect; }
void Interfaccia_RGBHSV::SetStaticRect(const SDL_FRect& rect) { staticRect = rect; }

// Liste (Solo getter, le liste si gestiscono tramite i metodi del vector)
std::vector<TextBox*>& Interfaccia_RGBHSV::GetTextbox() { return textbox; }
const std::vector<TextBox*>& Interfaccia_RGBHSV::GetTextbox() const { return textbox; }

std::vector<std::string>& Interfaccia_RGBHSV::GetStr() { return str; }
const std::vector<std::string>& Interfaccia_RGBHSV::GetStr() const { return str; }

std::vector<Slider*>& Interfaccia_RGBHSV::GetBarreScelta() { return barreScelta; }
const std::vector<Slider*>& Interfaccia_RGBHSV::GetBarreScelta() const { return barreScelta; }

std::vector<float>& Interfaccia_RGBHSV::GetValPercentuale() { return valPercentuale; }
const std::vector<float>& Interfaccia_RGBHSV::GetValPercentuale() const { return valPercentuale; }