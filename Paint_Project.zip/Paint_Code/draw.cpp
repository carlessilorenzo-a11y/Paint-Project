#define SDL_MAIN_HANDLED
#include "draw.h"
#include "graphics.h"
#include "textBox.h"
#include "draw_Draw.h"
#include "draw_Update.h"
#include "draw_UpdateCanvas.h"
#include "app.h"

Project::Project(VariabiliGlobali& global) :
    global(global),
    zoom(1.0f),
    alphaLevel(true),
    isOpen(false),
    baseLevelDeleted(false),
    currentfile("\0"),
    alphaGridCoord{ -1, -1 },
    basicSize{ 0, 0 },
    limitSize{ 0, 0 },
    alphaGrid(nullptr) 
{}

Project::~Project()
{
    if (alphaGrid)
    {
        SDL_DestroyTexture(alphaGrid);
        alphaGrid = nullptr;
    }
}

Level& Project::operator[](size_t pos) { return level[pos]; }
const Level& Project::operator[](size_t pos) const { return level[pos]; }

void Project::Draw()
{
    UpdateCanvas();

    setRectClip(global);

    SDL_SetRenderClipRect(global.win.Main.getRenderer(), nullptr);

    if (global.win.Main.GetTools().current == Tools::BRUSH || global.win.Main.GetTools().current == Tools::ERASER)
    {
        if (global.win.Main.GetTools().textBoxe)
        {
            global.win.Main.GetTools().textBoxe->Draw();
        }
    }
}

void Project::Update()
{
    if (isInsideCanvas(global))
    {
        Coord mapClick = getMapClick(global);

        static Coord lastClick;

        if (mapClick.y < 0 || mapClick.y >= (int)global.win.Main.level()[global.currentLevel].map.size() ||
            mapClick.x < 0 || mapClick.x >= (int)global.win.Main.level()[global.currentLevel].map[0].size())
        {
            global.hasLast = false;
            return;
        }

        if ((global.win.Main.GetTools().current == Tools::BRUSH && global.leftMousePressed) ||
            (global.win.Main.GetTools().current == Tools::ERASER && global.leftMousePressed))
        {
            SetBrushEraser(global, lastClick, mapClick);
        }
        else if (global.win.Main.GetTools().current == Tools::BUCKET)
        {
            SetBucket(global, mapClick);
        }
        else if (global.win.Main.GetTools().current == Tools::PIPETTE)
        {
            global.win.Main.SetColor_PP(global.win.Main.level().GetLevel().back().map[static_cast<size_t>(mapClick.y)][static_cast<size_t>(mapClick.x)]);
        }
        else if (global.win.Main.GetTools().current == Tools::MOVE)
        {
            moveDraw(true);
        }
    }
}

void Project::UpdateCanvas()
{
    if (!global.win.Main.level().IsOpen()) return;

    for (size_t i = 0; i < global.win.Main.level().GetLevel().size(); ++i)
    {
        FSize tex = getTexSize(global, i);

        if (textureNeedUpdate(global, tex, i))
        {
            creteNewTexture(global, i);
        }
    }

    if (!global.win.Main.level()[global.currentLevel].needsUpdate) return;

    setMap(global);

    if (global.cronologyUpdate)
    {
        APP::updateCronology(global);
    }

    SDL_UnlockTexture(global.win.Main.level()[global.currentLevel].canvas);
    global.win.Main.level()[global.currentLevel].needsUpdate = false;
}

void Project::UpdateAlphaGrid()
{
    if (!alphaLevel || !alphaGrid)
        return;

    void* pixels = nullptr;
    int pitch = 0;
    if (!SDL_LockTexture(alphaGrid, nullptr, &pixels, &pitch))
    {
        SDL_Log("Impossibile bloccare texture alphaGrid: %s", SDL_GetError());
        return;
    }

    const float segment = 10.0f;
    const int w = basicSize.w;
    const int h = basicSize.h;

    Uint32* px = static_cast<Uint32*>(pixels);

    Uint32 colorLight = SDL_MapRGBA(SDL_GetPixelFormatDetails(SDL_PIXELFORMAT_RGBA8888), nullptr, 192, 192, 192, 255);
    Uint32 colorDark = SDL_MapRGBA(SDL_GetPixelFormatDetails(SDL_PIXELFORMAT_RGBA8888), nullptr, 128, 128, 128, 255);

    int seg = static_cast<int>(segment);
    for (int y = 0; y < h; ++y)
    {
        Uint32* row = reinterpret_cast<Uint32*>((Uint8*)pixels + y * pitch);

        bool rowLight = ((y / seg) % 2 == 0);

        for (int x = 0; x < w; ++x)
        {
            bool colLight = ((x / seg) % 2 == 0);
            bool useLight = (rowLight == colLight);
            row[x] = useLight ? colorLight : colorDark;
        }
    }

    SDL_UnlockTexture(alphaGrid);
}

void Project::moveDraw(bool tool)
{
    SDL_FRect screenLimit = {
        (global.win.Main.getSize().w - basicSize.w) / 2.0f,
        (global.win.Main.getSize().h - basicSize.h) / 2.0f,
        static_cast<float>(basicSize.w),
        static_cast<float>(basicSize.h)
    };
    if (!APP::isPixelInRect(global.click, &screenLimit)) return;

    static Coord lastCoord;
    static Coord startMoveCoord;

    if (!level[global.currentLevel].pressed)
    {
        level[global.currentLevel].pressed = true;

        lastCoord = global.click;

        if (tool)
        {
            startMoveCoord = level[global.currentLevel].moveCoord;
        }

        return;
    }

    Coord newCoord = { global.click.x - lastCoord.x, global.click.y - lastCoord.y };

    if (!tool)
    {
        alphaGridCoord.x += newCoord.x;
        alphaGridCoord.y += newCoord.y;

        for (size_t i = 0; i < level.size(); ++i)
        {
            level[i].moveCoord.x += newCoord.x;
            level[i].moveCoord.y += newCoord.y;

            level[i].zoomSize.x += newCoord.x;
            level[i].zoomSize.y += newCoord.y;
        }

        if (baseLevelDeleted)
        {
            finalLevel.moveCoord.x += newCoord.x;
            finalLevel.moveCoord.y += newCoord.y;

            finalLevel.zoomSize.x += newCoord.x;
            finalLevel.zoomSize.y += newCoord.y;
        }

        Selections* selection = global.win.Main.GetSelections();
        if (selection)
        {
            if (selection->IsSelected())
            {
                selection->GetRect().x += newCoord.x;
                selection->GetRect().y += newCoord.y;

                if (selection->GetLastType() == Tools::SELEZIONE_LAZO)
                {
                    std::vector<SDL_FPoint>& frame = selection->GetLazoCoord();
                    for (auto& pixel : frame)
                    {
                        pixel.x += newCoord.x;
                        pixel.y += newCoord.y;
                    }
                }
            }

            switch (selection->GetType())
            {
            case Tools::SELEZIONE_RETTANGOLARE:
            {
                selection->GetStartCoord().x += newCoord.x;
                selection->GetStartCoord().y += newCoord.y;
                selection->GetFinalCoord().x += newCoord.x;
                selection->GetFinalCoord().y += newCoord.y;

                for (size_t i = 0; i < selection->GetSettingRect().size(); ++i)
                {
                    selection->GetSettingRect()[i].x += newCoord.x;
                    selection->GetSettingRect()[i].y += newCoord.y;
                }
                break;
            }
            case Tools::SELEZIONE_CIRCOLARE:
            {
                selection->GetStartCoord().x += newCoord.x;
                selection->GetStartCoord().y += newCoord.y;
                selection->GetFinalCoord().x += newCoord.x;
                selection->GetFinalCoord().y += newCoord.y;

                for (size_t i = 0; i < selection->GetSettingRect().size(); ++i)
                {
                    selection->GetSettingRect()[i].x += newCoord.x;
                    selection->GetSettingRect()[i].y += newCoord.y;
                }
                break;
            }
            case Tools::SELEZIONE_LAZO:
            {
                selection->GetStartCoord().x += newCoord.x;
                selection->GetStartCoord().y += newCoord.y;

                std::vector<Coord>& cerchi = selection->GetLazoMovingPoints();
                for (auto& pixel : cerchi)
                {
                    pixel.x += newCoord.x;
                    pixel.y += newCoord.y;
                }

                std::vector<SDL_FPoint>& preparationFrame = selection->GetPreparationLazoCoord();
                for (auto& pixel : preparationFrame)
                {
                    pixel.x += newCoord.x;
                    pixel.y += newCoord.y;
                }
                break;
            }
            }
        }

        lastCoord = global.click;
    }
    else
    {
        level[global.currentLevel].moveCoord.x = startMoveCoord.x + newCoord.x;
        level[global.currentLevel].moveCoord.y = startMoveCoord.y + newCoord.y;
    }
}

float Project::GetZoom() const { return zoom; }
float& Project::GetZoom() { return zoom; }
void Project::SetZoom(float newZoom) { zoom = newZoom; }

// alphaLevel
bool Project::IsAlphaLevel() const { return alphaLevel; }
bool& Project::GetAlphaLevel() { return alphaLevel; }
void Project::SetAlphaLevel(bool newAlphaLevel) { alphaLevel = newAlphaLevel; }

// isOpen
bool Project::IsOpen() const { return isOpen; }
bool& Project::GetOpen() { return isOpen; }
void Project::SetOpen(bool newOpen) { isOpen = newOpen; }

// baseLevelDeleted
bool Project::IsBaseLevelDeleted() const { return baseLevelDeleted; }
bool& Project::GetBaseLevelDeleted() { return baseLevelDeleted; }
void Project::SetBaseLevelDeleted(bool newBaseLevelDeleted) 
{ 
    baseLevelDeleted = newBaseLevelDeleted; 
    finalLevel = level[global.baseLevelPos];
}

// currentfile
const std::string& Project::GetCurrentfile() const { return currentfile; }
std::string& Project::GetCurrentfile() { return currentfile; }
void Project::SetCurrentfile(const std::string& newCurrentfile) { currentfile = newCurrentfile; }

// currentfileProject
const std::string& Project::GetCurrentfileProject() const { return currentfileProject; }
std::string& Project::GetCurrentfileProject() { return currentfileProject; }
void  Project::SetCurrentfileProject(const std::string& newCurrentfile) { currentfileProject = newCurrentfile; }

const Coord& Project::GetAlphaGridCoord() const { return alphaGridCoord; }
Coord& Project::GetAlphaGridCoord() { return alphaGridCoord; }
void Project::SetAlphaGridCoord(const Coord& newAlphaGridCoord) { alphaGridCoord = newAlphaGridCoord; }

// basicSize
const Size& Project::GetBasicSize() const { return basicSize; }
Size& Project::GetBasicSize() { return basicSize; }
void Project::SetBasicSize(const Size& newSize) { basicSize = newSize; }

// limitSize
const Size& Project::GetLimitSize() const { return limitSize; }
Size& Project::GetLimitSize() { return limitSize; }
void Project::SetLimitSize(const Size& newLimitSize) { limitSize = newLimitSize; }

// finalLevel 
Level& Project::GetFinalLevel() { return finalLevel; }
const Level& Project::GetFinalLevel() const { return finalLevel; }
void Project::SetFinalLevel(const Level& newRect) { finalLevel = newRect; }

// level
const std::vector<Level>& Project::GetLevel() const { return level; }
std::vector<Level>& Project::GetLevel() { return level; }
void Project::SetLevel(const std::vector<Level>& newLevel) { level = newLevel; }

// alphaGrid
SDL_Texture* Project::GetAlphaGrid() const { return alphaGrid; }
SDL_Texture*& Project::GetAlphaGrid() { return alphaGrid; }
void Project::SetAlphaGrid(SDL_Texture* newAlphaGrid) { alphaGrid = newAlphaGrid; }