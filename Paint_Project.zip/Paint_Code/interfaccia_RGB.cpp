#define SDL_MAIN_HANDLED
#include "interfaccia_RGB.h"
#include "graphics.h"
#include "variabiliGlobali.h"
#include "app.h"

Interfaccia_RGB::Interfaccia_RGB(VariabiliGlobali& global, SDL_FRect& continueRect, SDL_FRect& rectNewColor, ColorRgb& finalColor, bool& colorPP) :
    global(global),
    continueRect(continueRect),
    rectNewColor(rectNewColor),
    finalColor(finalColor),
    colorPP(colorPP),
    alphaLevelRgb(255),
    alphaLine({ {0, 0, 0, 0}, {0, 0, 0, 255} }),
    alphaCircle({}),
    colorMap({}),
    letterSize(8),
    alphaGrid(nullptr)
{}

void Interfaccia_RGB::Update()
{
    for (int j = 0; j < letterSize; j++)
    {
        for (int i = 0; i < letterSize; i++)
        {
            rectColored& rect = colorMap[j][i];
            if (APP::isPixelInRect(global.click, &rect.rect) && rectSelected[j][i])
            {
                global.win.color.isOpen() = false;
                if (!global.win.setNew.getWindow())
                {
                    if(colorPP) global.win.Main.SetColor_PP(finalColor);
                    else global.win.Main.SetColor_SF(finalColor);

                    global.win.Main.Update();
                }

                global.win.color.Destroy();
                global.click = { -1, -1 };
                return;
            }
            else if(APP::isPixelInRect(global.click, &rect.rect))
            {
                for (size_t k = 0; k < rectSelected.size(); ++k)
                {
                    for (size_t w = 0; w < rectSelected[k].size(); ++w)
                    {
                        if (rectSelected[k][w])
                        {
                            rectSelected[k][w] = false;
                            break;
                        }
                    }
                }

                rectSelected[j][i] = true;

                finalColor = GRAPHICS::getRgbColor(colorMap[j][i].color, j);
                finalColor.a = alphaLevelRgb;
            }
        }
    }

    if (APP::isPixelInRect(global.click, &continueRect))
    {
        global.win.color.isOpen() = false;
        if (!global.win.setNew.getWindow())
        {
            if (colorPP) global.win.Main.SetColor_PP(finalColor);
            else global.win.Main.SetColor_SF(finalColor);

            global.win.Main.Update();
        }

        global.win.color.Destroy();
        global.click = { -1, -1 };
        return;
    }
}

void Interfaccia_RGB::Draw()
{
    SDL_SetRenderDrawColor(global.win.color.getRenderer(), 30, 30, 30, 30);
    SDL_RenderClear(global.win.color.getRenderer());

    SDL_FRect staticRect = {
        colorMap[0][0].rect.x,
        colorMap[0][0].rect.y,
        colorMap[0][0].rect.w * colorMap[0].size(),
        colorMap[0][0].rect.h * colorMap.size()
    };

    if (alphaGrid)
    {
        SDL_RenderTexture(global.win.color.getRenderer(), alphaGrid, nullptr, &staticRect); 
        SDL_RenderTexture(global.win.color.getRenderer(), alphaGrid, nullptr, &rectNewColor);
    }
    else
    {
        SDL_Log("texture non valida");
    }

    if (!colorMap.empty())
    {
        for (int j = 0; j < letterSize; j++)
        {
            for (int i = 0; i < letterSize; i++)
            {
                SDL_FRect rect = colorMap[j][i].rect;
                ColorRgb tempColor = GRAPHICS::getRgbColor(static_cast<ColorType>(colorMap[j][i].color), j);
                tempColor.a = alphaLevelRgb;

                SDL_SetRenderDrawColor(global.win.color.getRenderer(), tempColor.r, tempColor.g, tempColor.b, tempColor.a);
                SDL_RenderFillRect(global.win.color.getRenderer(), &rect);
                SDL_SetRenderDrawColor(global.win.color.getRenderer(), 0, 0, 0, 255);
                SDL_RenderRect(global.win.color.getRenderer(), &rect);
                if (rectSelected[j][i])
                {
                    SDL_FRect colorMapFrame = {
                        rect.x - 1,
                        rect.y - 1,
                        rect.w + 2,
                        rect.h + 2
                    };
                    SDL_RenderRect(global.win.color.getRenderer(), &colorMapFrame);
                    colorMapFrame = {
                        rect.x - 2,
                        rect.y - 2,
                        rect.w + 4,
                        rect.h + 4
                    };
                    SDL_RenderRect(global.win.color.getRenderer(), &colorMapFrame);
                }
            }
        }

        for (int j = 0; j < letterSize; j++)
        {
            for (int i = 0; i < letterSize; i++)
            {
                if (rectSelected[j][i])
                {
                    SDL_FRect rect = colorMap[j][i].rect;
                    SDL_FRect colorMapFrame = {
                        rect.x - 2,
                        rect.y - 2,
                        rect.w + 4,
                        rect.h + 4
                    };
                    SDL_RenderRect(global.win.color.getRenderer(), &colorMapFrame);
                }
            }
        }
    }

    SDL_SetRenderDrawColor(global.win.color.getRenderer(),
        alphaLine.color.r,
        alphaLine.color.g,
        alphaLine.color.b,
        alphaLine.color.a
    );
    SDL_RenderFillRect(global.win.color.getRenderer(), &alphaLine.rect);

    GRAPHICS::Print(
        "Livello alpha:", 
        staticRect.x + staticRect.w * 1.2f, 
        staticRect.y + staticRect.h / 2.0f - 10.0f / 2.0f, 
        10.0f, 
        global.win.color.getRenderer(), 
        global.win.color.getTextures(), 
        0.35f
    );

    if (!alphaCircle.empty())
    {
        SDL_SetRenderDrawColor(global.win.color.getRenderer(),
            alphaCircle[0].color.r,
            alphaCircle[0].color.g,
            alphaCircle[0].color.b,
            alphaCircle[0].color.a);

        std::vector<rectColoredRgb> tempCircle;
        for (auto& tool : alphaCircle)
        {
            rectColoredRgb colorTemp;
            colorTemp = tool;
            colorTemp.rect.y += static_cast<float>(alphaLevelRgb - 1);
            tempCircle.push_back(colorTemp);
        }

        for (auto& pixel : tempCircle)
        {
            SDL_SetRenderDrawColor(global.win.color.getRenderer(), pixel.color.r, pixel.color.g, pixel.color.b, pixel.color.a);
            SDL_RenderFillRect(global.win.color.getRenderer(), &pixel.rect);
        }
    }
}

void Interfaccia_RGB::UpdateAlphaLevel(bool drawingInMove, bool mouseReleased)
{
    static uint8_t lastAlpha = 255;
    static bool resizing = false;

    if (mouseReleased)
    {
        resizing = false;
        return;
    }

    auto calculateAlphaFromPosition = [](float posY, const SDL_FRect& lineRect)
        {
            float percent = (posY - lineRect.y) / lineRect.h;
            if (percent < 0.0f) percent = 0.0f;
            if (percent > 1.0f) percent = 1.0f;
            return static_cast<uint8_t>(percent * 255.0f);
        };

    if (!drawingInMove)
    {
        if ((global.click.x >= alphaLine.rect.x - 5 && global.click.x <= alphaLine.rect.x + alphaLine.rect.w + 5) &&
            (global.click.y >= alphaLine.rect.y && global.click.y <= alphaLine.rect.y + alphaLine.rect.h))
        {
            resizing = true;
            global.lastClick = global.click;

            alphaLevelRgb = calculateAlphaFromPosition(global.click.y, alphaLine.rect);
            finalColor.a = alphaLevelRgb;
        }
    }

    if (drawingInMove && resizing)
    {
        alphaLevelRgb = calculateAlphaFromPosition(global.click.y, alphaLine.rect);
        finalColor.a = alphaLevelRgb;
    }

    lastAlpha = alphaLevelRgb;
}

// alphaLevel (Get/Set)
Uint8 Interfaccia_RGB::GetAlphaLevelRgb() const { return alphaLevelRgb; }
void Interfaccia_RGB::SetAlphaLevelRgb(Uint8 level) { alphaLevelRgb = level; }

// letterSize (Get/Set)
int Interfaccia_RGB::GetLetterSize() const { return letterSize; }
void Interfaccia_RGB::SetLetterSize(int size) { letterSize = size; }

// alphaLine (Get/Set)
const rectColoredRgb& Interfaccia_RGB::GetAlphaLine() const { return alphaLine; }
void Interfaccia_RGB::SetAlphaLine(const rectColoredRgb& newLine) { alphaLine = newLine; }

// alphaCircle (std::vector<rectColoredRgb>)
std::vector<rectColoredRgb>& Interfaccia_RGB::GetAlphaCircle() { return alphaCircle; }
const std::vector<rectColoredRgb>& Interfaccia_RGB::GetAlphaCircle() const { return alphaCircle; }
void Interfaccia_RGB::SetAlphaCircle(const std::vector<rectColoredRgb>& newCircles) { alphaCircle = newCircles; }

// colorMap (std::vector<std::vector<rectColored>>)
std::vector<std::vector<rectColored>>& Interfaccia_RGB::GetColorMap() { return colorMap; }
const std::vector<std::vector<rectColored>>& Interfaccia_RGB::GetColorMap() const { return colorMap; }
void Interfaccia_RGB::SetColorMap(const std::vector<std::vector<rectColored>>& newMap) { colorMap = newMap; }

// rectSelected (std::vector<std::vector<bool>>)
std::vector<std::vector<bool>>& Interfaccia_RGB::GetRectSelected() { return rectSelected; }
const std::vector<std::vector<bool>>& Interfaccia_RGB::GetRectSelected() const { return rectSelected; }
void Interfaccia_RGB::SetRectSelected(const std::vector<std::vector<bool>>& newRect) { rectSelected = newRect; }

// alphaGrid
SDL_Texture* Interfaccia_RGB::GetAlphaGrid() const { return alphaGrid; }
SDL_Texture*& Interfaccia_RGB::GetAlphaGrid() { return alphaGrid; }
void Interfaccia_RGB::SetAlphaGrid(SDL_Texture* newAlphaGrid) { alphaGrid = newAlphaGrid; }