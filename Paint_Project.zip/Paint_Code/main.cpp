#include "texture.h"
#include "set.h"
#include "salvataggio.h"
#include "slider.h"
#include "selections.h"
#include "app.h"

int main(int argc, char* argv[])
{
    VariabiliGlobali global;
    Win& win = global.win;

    win.Main.SetSelections();

    int result = SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS);
    if (result < 0)
    {
        return -1;
    }

    win.Main.Initialize("Paint", 0, 0, true, 0, 0, true, true);

    SDL_GetWindowSize(win.Main.getWindow(), &win.Main.getSize().w, &win.Main.getSize().h);

    SDL_Log("Righe Totali progetto: %i", static_cast<int>(APP::countProjectLines()));

    TEXTURE::LoadTextureSurfaces(global.loadedSurfaces);
    win.Main.getTextures() = TEXTURE::CreateIconsTextures(win.Main.getRenderer(), global.loadedSurfaces);

    SET::menuFile(global);
    SET::levelMenu(global);
    SET::menuTools(global);

    global.win.Main.level().GetLevel().push_back(Level{});

    win.Main.level()[global.currentLevel].canvas = SDL_CreateTexture(
        win.Main.getRenderer(),
        SDL_PIXELFORMAT_RGBA8888,
        SDL_TEXTUREACCESS_STREAMING,
        win.Main.level().GetBasicSize().w,
        win.Main.level().GetBasicSize().h
    );

    win.Main.level().GetAlphaGrid() = SDL_CreateTexture(
        win.Main.getRenderer(),
        SDL_PIXELFORMAT_RGBA8888,
        SDL_TEXTUREACCESS_STREAMING,
        win.Main.level().GetBasicSize().w,
        win.Main.level().GetBasicSize().h
    );

    Uint64 NOW = SDL_GetPerformanceCounter();
    Uint64 LAST = 0;
    double deltaTime = 0;

    bool quitAfter = false;

    SDL_Event event;
    int quit = 0;

    while (!quit)
    {
        LAST = NOW;
        NOW = SDL_GetPerformanceCounter();

        deltaTime = (double)((NOW - LAST) * 1000 / (double)SDL_GetPerformanceFrequency());

        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
            case SDL_EVENT_QUIT:
            {
                Level& currentLvl = win.Main.level()[global.currentLevel];
                if (global.win.Main.level().IsOpen() && APP::messageBoxYesNo("Salvataggio", "Stai uscendo senza salvare, vuoi salvare?") == 1)
                {
                    if (!global.win.Main.level().GetCurrentfile().empty())
                    {
                        if (SALVATAGGIO::SaveMapToImage(currentLvl.map, global.directoryDraw + global.win.Main.level().GetCurrentfile() + ".bmp", false))
                        {
                            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "OPERAZIONE COMPLEATA", "Disegno salvato con successo", NULL);
                        }
                        else
                        {
                            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Errore nel savataggio del disegno", NULL);
                        }
                    }
                    else
                    {
                        global.win.save.Initialize("Save", 350, 250, &global.click, true, 0, 0, false);
                        global.win.save.getTextures() = TEXTURE::CreateIconsTextures(global.win.save.getRenderer(), global.loadedSurfaces);
                        global.click = { -1, -1 };
                        SET::saveWindow(global);

                        quitAfter = true;
                        break;
                    }
                }

                quit = 1;
                win.Main.isOpen() = false;
                break;
            }

            case SDL_EVENT_WINDOW_CLOSE_REQUESTED:
            {
                if (event.window.windowID == SDL_GetWindowID(win.Main.getWindow()))
                {
                    quit = true;
                    win.Main.isOpen() = false;
                }
                else if (event.window.windowID == SDL_GetWindowID(win.setNew.getWindow()))
                {
                    win.setNew.Destroy();
                    global.click = { -1, -1 };
                }
                else if (event.window.windowID == SDL_GetWindowID(win.color.getWindow()))
                {
                    win.color.Destroy();
                    global.click = { -1, -1 };
                }
                else if (event.window.windowID == SDL_GetWindowID(win.save.getWindow()))
                {
                    if (quitAfter)
                    {
                        quit = 1;
                        win.Main.isOpen() = false;
                    }
                    win.save.Destroy();
                    global.click = { -1, -1 };
                }
                else if (event.window.windowID == SDL_GetWindowID(win.load.getWindow()))
                {
                    win.load.Destroy();
                    global.click = { -1, -1 };
                }
                break;
            }

            case SDL_EVENT_MOUSE_BUTTON_DOWN:
            {
                Level& currentLvl = win.Main.level()[global.currentLevel];
                if (event.button.button == SDL_BUTTON_LEFT)
                {
                    global.leftMousePressed = true;
                    global.hasMovedSinceClick = false;
                    global.click = { static_cast<float>(event.button.x), static_cast<float>(event.button.y) };

                    if (APP::isMainWindowFocus(global))
                    {
                        win.Main.Update();
                        win.Main.UpdateMenuTools();

                        std::vector<SliderTextbox*>& toolsSetting = global.win.Main.GetToolsSetting();
                        for (const auto& slider : toolsSetting)
                        {
                            if (slider)
                            {
                                slider->Update(global.click, false, false);
                            }
                        }

                        if (win.Main.level().IsOpen())
                        {
                            win.Main.level().Update();
                            win.Main.UpdateLevelSwaps(false, false);

                            currentLvl.needsUpdate = true;

                            if (win.Main.GetOpacity())
                            {
                                float valore = -1.0f;
                                win.Main.GetOpacity()->Update(global.click, valore, false, false);

                                if (valore != -1.0f)
                                {
                                    currentLvl.opacity = static_cast<Uint8>(win.Main.GetOpacity()->GetValore());
                                }
                            }

                            if (win.Main.GetSelections())
                            {
                                win.Main.GetSelections()->Update(global.click, false, false, false, false);
                            }
                        }
                    }

                    if (win.setNew.isOpen())
                    {
                        win.setNew.Update();
                    }

                    if (win.color.isOpen())
                    {
                        win.color.Update();
                        switch (global.win.color.getCurrentInterfaccia())
                        {
                        case ColorInterfaccia::RGB:
                            win.color.getRGBinterfaccia().UpdateAlphaLevel(false, false);
                            break;

                        case ColorInterfaccia::RGBHSV:
                            win.color.getRGBHSVinterfaccia().UpdateRgbCerchio(false, false);
                            break;
                        }
                    }

                    if (win.save.isOpen())
                    {
                        win.save.Update();
                    }

                    if (win.load.isOpen())
                    {
                        win.load.SetLoadNext((event.button.clicks == 2) ? true : false);
                        win.load.Update();
                    }
                }
                break;
            }

            case SDL_EVENT_MOUSE_BUTTON_UP:
            {
                Level& currentLvl = win.Main.level()[global.currentLevel];
                if (event.button.button == SDL_BUTTON_LEFT)
                {
                    global.leftMousePressed = false;
                    global.click = { static_cast<float>(event.button.x), static_cast<float>(event.button.y) };

                    if (APP::isMainWindowFocus(global))
                    {
                        if (global.hasLast && (win.Main.GetTools().current == Tools::BRUSH || win.Main.GetTools().current == Tools::ERASER))
                        {
                            global.cronologyUpdate = true;

                            if (!global.hasMovedSinceClick)
                            {
                                win.Main.level().Update();
                            }

                            global.hasMovedSinceClick = false;
                            global.hasLast = false;
                        }

                        std::vector<SliderTextbox*>& toolsSetting = global.win.Main.GetToolsSetting();
                        for (const auto& slider : toolsSetting)
                        {
                            if (slider)
                            {
                                slider->Update(global.click, false, true);
                            }
                        }

                        if (win.Main.level().IsOpen())
                        {
                            win.Main.UpdateLevelSwaps(false, true);

                            if (win.Main.GetOpacity())
                            {
                                float valore = -1.0f;
                                win.Main.GetOpacity()->Update(global.click, valore, false, true);

                                if (valore != -1.0f)
                                {
                                    currentLvl.opacity = static_cast<Uint8>(win.Main.GetOpacity()->GetValore());
                                }
                            }

                            if (win.Main.GetSelections())
                            {
                                win.Main.GetSelections()->Update(global.click, false, true, false, false);
                            }
                        }
                    }
                    
                    if (win.color.isOpen())
                    {
                        switch (global.win.color.getCurrentInterfaccia())
                        {
                        case ColorInterfaccia::RGB:
                            win.color.getRGBinterfaccia().UpdateAlphaLevel(false, true);
                            break;

                        case ColorInterfaccia::RGBHSV:
                            win.color.getRGBHSVinterfaccia().UpdateRgbCerchio(false, true);
                            break;
                        }
                    }

                    if (global.win.Main.GetTools().current == Tools::MOVE)
                    {
                        if (currentLvl.pressed)
                        {
                            currentLvl.pressed = false;
                        }

                        global.cronologyUpdate = true;
                    }
                }
                else if (event.button.button == SDL_BUTTON_MIDDLE)
                {
                    currentLvl.pressed = false;
                }
                break;
            }

            case SDL_EVENT_MOUSE_MOTION:
            {
                Level& currentLvl = win.Main.level()[global.currentLevel];
                global.hasMovedSinceClick = true;

                if (event.button.button == SDL_BUTTON_MIDDLE)
                {
                    global.click = { static_cast<float>(event.button.x), static_cast<float>(event.button.y) };
                    win.Main.level().moveDraw(false);
                }
                else if (global.leftMousePressed)
                {
                    global.click = { static_cast<float>(event.motion.x), static_cast<float>(event.motion.y) };

                    if (APP::isMainWindowFocus(global))
                    {
                        std::vector<SliderTextbox*>& toolsSetting = global.win.Main.GetToolsSetting();
                        for (const auto& slider : toolsSetting)
                        {
                            if (slider)
                            {
                                slider->Update(global.click, true, false);
                            }
                        }

                        if (win.Main.level().IsOpen())
                        {
                            win.Main.level().Update();
                            win.Main.UpdateLevelSwaps(true, false);

                            currentLvl.needsUpdate = true;

                            if (win.Main.GetOpacity())
                            {
                                float valore = -1.0f;
                                win.Main.GetOpacity()->Update(global.click, valore, true, false);

                                if (valore != -1.0f)
                                {
                                    currentLvl.opacity = static_cast<Uint8>(win.Main.GetOpacity()->GetValore());
                                }
                            }

                            if (win.Main.GetSelections())
                            {
                                win.Main.GetSelections()->Update(global.click, true, false, false, false);
                            }
                        }
                    }
                    if (win.color.isOpen())
                    {
                        switch (global.win.color.getCurrentInterfaccia())
                        {
                        case ColorInterfaccia::RGB:
                            win.color.getRGBinterfaccia().UpdateAlphaLevel(true, false);
                            break;

                        case ColorInterfaccia::RGBHSV:
                            win.color.getRGBHSVinterfaccia().UpdateRgbCerchio(true, false);
                            break;
                        }
                    }
                    if (global.win.Main.GetTools().current == Tools::MOVE && !currentLvl.pressed)
                    {
                        currentLvl.pressed = true;
                    }
                }
                break;
            }

            case SDL_EVENT_KEY_DOWN:
            {
                Level& currentLvl = win.Main.level()[global.currentLevel];
                if (win.Main.GetTools().textBoxe)
                {
                    win.Main.GetTools().textBoxe->UpdateText(event);
                    float& size = (win.Main.GetTools().current == Tools::BRUSH) ? win.Main.GetTools().setting.brush.size : win.Main.GetTools().setting.eraser.size;
                    if (!win.Main.GetTools().textBoxe->getText().empty()) size = static_cast<float>(std::stoi(win.Main.GetTools().textBoxe->getText()));
                }

                if (SDL_GetModState() & (SDL_KMOD_LCTRL | SDL_KMOD_RCTRL))
                {
                    global.ctrl = true;

                    if (win.Main.level().IsOpen())
                    {
                        switch (event.key.key)
                        {
                        case SDLK_Z:
                        {
                            APP::Undo(global);
                            break;
                        }
                        case SDLK_Y:
                        {
                            APP::Redo(global);
                            break;
                        }
                        case SDLK_C:
                        {
                            APP::copy(global);
                            break;
                        }
                        case SDLK_V:
                        {
                            APP::paste(global, false);
                            break;
                        }
                        }
                    }
                }

                if (win.setNew.isOpen())
                {
                    if (win.setNew.GetTextbox()[0]) win.setNew.GetTextbox()[0]->UpdateText(event);
                    if (win.setNew.GetTextbox()[1]) win.setNew.GetTextbox()[1]->UpdateText(event);
                }

                if (win.save.isOpen())
                {
                    if (win.save.GetTextbox()) win.save.GetTextbox()->UpdateText(event);
                }

                if (win.load.isOpen())
                {
                    if (win.load.GetTextbox()) win.load.GetTextbox()->UpdateText(event);
                }

                if (event.key.key == SDLK_ESCAPE)
                {
                    Window* winTemp = nullptr;

                    if (win.setNew.isOpen()) winTemp = &win.setNew;
                    else if (win.save.isOpen()) winTemp = &win.save;
                    else if (win.color.isOpen()) winTemp = &win.color;
                    else if (win.load.isOpen()) winTemp = &win.load;

                    if (winTemp)
                    {
                        winTemp->Destroy();
                    }
                }
                break;
            }

            case SDL_EVENT_KEY_UP:
            {
                if (event.key.key == SDLK_LCTRL || event.key.key == SDLK_RCTRL)
                {
                    global.ctrl = false;
                }
                else if (event.key.key == SDLK_RETURN)
                {
                    if (win.Main.GetSelections())
                    {
                        win.Main.GetSelections()->Update(global.click, false, false, true, false);
                    }
                }
                else if (event.key.key == SDLK_DELETE)
                {
                    GRAPHICS::fillMapWithSelectedArea(global, { 0, 0, 0, 0 });
                }
                else if (event.key.key == SDLK_ESCAPE)
                {
                    if (win.Main.level().IsOpen() && win.Main.GetSelections())
                    {
                        win.Main.GetSelections()->Update(global.click, false, false, false, true);
                    }
                }
                break;
            }

            case SDL_EVENT_TEXT_INPUT:
            {
                if (win.save.isOpen())
                {
                    if (win.save.GetTextbox()) win.save.GetTextbox()->UpdateText(event);
                }

                if (win.load.isOpen())
                {
                    if (win.load.GetTextbox()) win.load.GetTextbox()->UpdateText(event);
                    win.load.SetLoadNext(false);
                    win.load.Update();
                }
                break;
            }

            case SDL_EVENT_MOUSE_WHEEL:
            {
                if (win.Main.level().IsOpen() && !win.load.isOpen() && global.ctrl)
                {
                    SDL_GetMouseState(&global.cursorPosition.x, &global.cursorPosition.y);

                    APP::applyZoom(global, event, 1.1f);
                }
                if (win.load.isOpen())
                {
                    static float startY = global.fileCartella[0].rect.y;
                    float move = 0.0f;

                    if (event.wheel.y > 0 && global.fileCartella[0].rect.y < startY) move = 8.0f;
                    else if (event.wheel.y < 0 && global.fileCartella[global.fileCartella.size() - 1].rect.y > win.load.GetRectLoad().y) move = -8.0f;

                    for (auto& file : global.fileCartella)
                    {
                        file.rect.y += move;
                    }
                }

                break;
            }

            case SDL_EVENT_WINDOW_RESIZED:
            {
                win.Main.Update();
                SDL_GetWindowSize(win.Main.getWindow(), &win.Main.getSize().w, &win.Main.getSize().h);

                if (win.Main.level().IsOpen())
                {
                    win.Main.UpdateMenuTools();
                    win.Main.level().Update();
                    SET::menuTools(global);
                }

                if (win.setNew.isOpen())
                {
                    SDL_GetWindowSize(win.color.getWindow(), &win.color.getSize().w, &win.color.getSize().h);
                    win.setNew.Update();
                    SET::newTextBox(global, global.win.setNew.IsLevel());
                }

                if (win.color.isOpen())
                {
                    SDL_GetWindowSize(win.setNew.getWindow(), &win.setNew.getSize().w, &win.setNew.getSize().h);
                    win.color.Update();
                }

                if (win.save.isOpen())
                {
                    SDL_GetWindowSize(win.save.getWindow(), &win.save.getSize().w, &win.save.getSize().h);
                    SET::alphaLevel(global);
                    SET::saveWindow(global);
                }

                if (win.load.isOpen())
                {
                    SDL_GetWindowSize(win.save.getWindow(), &win.save.getSize().w, &win.save.getSize().h);
                    SET::loadWindow(global);
                }
                break;
            }

            case SDL_EVENT_WINDOW_FOCUS_GAINED:
            {
                Level& currentLvl = win.Main.level()[global.currentLevel];
                float x, y;
                uint32_t buttons = SDL_GetMouseState(&x, &y);

                if (!(buttons & SDL_BUTTON_LMASK))
                {
                    global.leftMousePressed = false;
                }

                if (!(buttons & SDL_BUTTON_MMASK))
                {
                    currentLvl.pressed = false;
                }

                break;
            }

            case SDL_EVENT_WINDOW_FOCUS_LOST:
            {
                Level& currentLvl = win.Main.level()[global.currentLevel];
                SDL_FlushEvents(SDL_EVENT_MOUSE_BUTTON_DOWN, SDL_EVENT_MOUSE_BUTTON_UP);

                global.leftMousePressed = false;
                currentLvl.pressed = false;

                if (event.window.windowID == SDL_GetWindowID(win.Main.getWindow()))
                {
                    global.leftMousePressed = false;
                    global.hasLast = false;
                }
                break;
            }

            case SDL_EVENT_RENDER_DEVICE_RESET:
            {
                SDL_Log("Renderer device reset — ricreo le texture");
                TEXTURE::LoadTextureSurfaces(global.loadedSurfaces);
                win.Main.getTextures() = TEXTURE::CreateIconsTextures(win.Main.getRenderer(), global.loadedSurfaces);
                break;
            }
            }
        }

        SDL_SetRenderDrawColor(win.Main.getRenderer(), 30, 30, 30, 255);
        SDL_RenderClear(win.Main.getRenderer());
        if (win.Main.level().IsOpen())
        {
            win.Main.level().Draw();
            win.Main.UpdateCursorSkin();
        }
        win.Main.Draw();
        SDL_RenderPresent(win.Main.getRenderer());

        if (win.setNew.isOpen())
        {
            win.setNew.Draw();
            SDL_RenderPresent(win.setNew.getRenderer());
        }

        if (win.color.isOpen())
        {
            win.color.Draw();
            SDL_RenderPresent(win.color.getRenderer());
        }

        if (win.save.isOpen())
        {
            win.save.Draw();
            SDL_RenderPresent(win.save.getRenderer());
        }

        if (win.load.isOpen())
        {
            win.load.Draw();
            SDL_RenderPresent(win.load.getRenderer());
        }

        if (deltaTime < 16.0) SDL_Delay((Uint32)(16.0 - deltaTime));
    }

    for (auto& pair : win.Main.getTextures())
    {
        SDL_DestroyTexture(pair.texture);
    }
    delete win.Main.GetSelections();
    delete win.Main.GetTools().textBoxe;

    for (auto& pair : win.setNew.getTextures())
    {
        SDL_DestroyTexture(pair.texture);
    }

    if (win.Main.getRenderer())
    {
        SDL_DestroyRenderer(win.Main.getRenderer());
    }

    for (const auto& elem : win.setNew.GetTextbox())
    {
        delete elem;
    }
    delete win.save.GetTextbox();
    delete win.load.GetTextbox();

    SDL_DestroyWindow(win.Main.getWindow());
    SDL_DestroyWindow(win.setNew.getWindow());
    SDL_DestroyWindow(win.color.getWindow());
    SDL_DestroyWindow(win.save.getWindow());
    SDL_DestroyWindow(win.load.getWindow());

    for (const auto& level : win.Main.level().GetLevel())
    {
        if (level.canvas)
        {
            SDL_DestroyTexture(level.canvas);
        }
    }
    SDL_Quit();

    return 0;
}