#define SDL_MAIN_HANDLED
#include "mainWin.h"
#include "salvataggio.h"
#include "set.h"
#include "texture.h"
#include "slider.h"
#include "graphics.h"
#include "app.h"

MainWin::MainWin(VariabiliGlobali& global) :
    global(global),
    color_PP({ 0, 0, 0, 255 }),
    color_SF({ 255, 255, 255, 255 }),
    bgColor({ 30, 30, 30, 255 }),
    level_(global),
    tools{},
    mainMenuRect{},
    menuFile{},
    levelMenu{},
    menuProject{},
    menuSelection{},
    levelRectMovingPos(-1),
    fileRectMenu{ 0, 0, 0, 0 },
    rectTavolaColori{ 0, 0, 0, 0 },
    colorRect_PP{ 0, 0, 0, 0 },
    colorRect_SF{ 0, 0, 0, 0 },
    levelRect{ 0, 0, 0, 0 },
    frecciaRect{ 0, 0, 0, 0 },
    rectGestioneTools{ 0, 0, 0, 0 },
    areaDiLavoro{ 0, 0, 0, 0 },
    opacity(nullptr),
    selections(nullptr),
    toolsSetting{}
{}

void MainWin::Update()
{
    if (APP::isMainWindowFocus(global))
    {
        for (size_t i = 0; i < mainMenuRect.size(); ++i) //Gestione menu
        {
            if (APP::isPixelInRect(global.click, &mainMenuRect[i].rect))
            {
                mainMenuRect[i].condition = !mainMenuRect[i].condition;

                for (size_t j = 0; j < mainMenuRect.size(); ++j)
                {
                    if (j != i && mainMenuRect[j].condition) mainMenuRect[j].condition = false;
                }
            }
            
            if (mainMenuRect[i].condition)
            {
                switch (i)
                {
                case 0:
                {
                    for (auto& menuRect : menuFile) // Menu File
                    {
                        if (APP::isPixelInRect(global.click, &menuRect.rect))
                        {
                            mainMenuRect[i].condition = false;

                            switch (menuRect.type)
                            {
                            case MenuFileType::New:
                            {
                                if (!global.win.setNew.isOpen())
                                {
                                    global.win.setNew.Initialize("New", 500, 300, &global.click, true, 0, 0, false);
                                    global.win.setNew.getTextures() = TEXTURE::CreateIconsTextures(global.win.setNew.getRenderer(), global.loadedSurfaces);
                                    global.click = { -1, -1 };
                                    SET::newTextBox(global, false);
                                }
                                break;
                            }
                            case MenuFileType::Save:
                            {
                                if (!global.win.save.isOpen())
                                {
                                    if (!level().IsOpen())
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non hai aperto nessun disegno", NULL);
                                        break;
                                    }
                                    else if (level().GetCurrentfile().empty())
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non hai mai salvato questo disegno", NULL);
                                        break;
                                    }

                                    if (SALVATAGGIO::SaveMapToImage(level()[global.currentLevel].map, global.directoryDraw + level().GetCurrentfile() + ".bmp", false))
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "OPERAZIONE COMPLEATA", "Disegno salvato con successo", NULL);
                                    }
                                    else
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Errore nel salvataggio del disegno", NULL);
                                    }
                                }
                                break;
                            }
                            case MenuFileType::SaveAs:
                            {
                                if (!level().IsOpen())
                                {
                                    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non hai aperto nessun disegno", NULL);
                                    break;
                                }

                                global.win.save.Initialize("Save", 350, 250, &global.click, true, 0, 0, false);
                                global.win.save.SetProject(false);
                                global.win.save.getTextures() = TEXTURE::CreateIconsTextures(global.win.save.getRenderer(), global.loadedSurfaces);
                                global.click = { -1, -1 };
                                SET::saveWindow(global);
                                break;
                            }
                            case MenuFileType::Load:
                            {
                                if (!global.win.load.isOpen())
                                {
                                    if (APP::listaFileCartella("/Disegni").empty())
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non e' presente nessun file da caricare", NULL);
                                        break;
                                    }
                                    else
                                    {
                                        global.win.load.Initialize("Load", 500, 650, &global.click, true, 0, 0, false);
                                        global.win.load.getTextures() = TEXTURE::CreateIconsTextures(global.win.load.getRenderer(), global.loadedSurfaces);
                                        global.click = { -1, -1 };
                                        global.win.load.SetProject(false);
                                        SET::loadWindow(global);
                                    }
                                }
                                break;
                            }
                            }
                        }
                    }
                    break;
                }
                case 1:
                {
                    for (auto& menuRect : menuProject) // Menu Project
                    {
                        if (APP::isPixelInRect(global.click, &menuRect.rect))
                        {
                            mainMenuRect[i].condition = false;

                            switch (menuRect.type)
                            {
                            case MenuProjectType::Save:
                            {
                                if (!global.win.save.isOpen())
                                {
                                    std::string currentFileProject = level().GetCurrentfileProject();
                                    if (!level().IsOpen())
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non hai aperto nessun disegno", NULL);
                                        break;
                                    }
                                    else if (currentFileProject.empty())
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non hai mai salvato questo progetto", NULL);
                                        break;
                                    }

                                    std::string filename = currentFileProject + ".pnt";
                                    if (SALVATAGGIO::saveProjectData(filename, global))
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "OPERAZIONE COMPLEATA", "Progetto salvato con successo", NULL);
                                    }
                                    else
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Errore nel salvataggio del progetto", NULL);
                                    }
                                }
                                break;
                            }
                            case MenuProjectType::SaveAs:
                            {
                                if (!level().IsOpen())
                                {
                                    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non hai aperto nessun disegno aperto", NULL);
                                    break;
                                }

                                global.win.save.Initialize("Save", 350, 130, &global.click, true, 0, 0, false);
                                global.win.save.SetProject(true);
                                global.win.save.getTextures() = TEXTURE::CreateIconsTextures(global.win.save.getRenderer(), global.loadedSurfaces);
                                global.click = { -1, -1 };
                                SET::saveWindow(global);
                                break;
                            }
                            case MenuProjectType::Load:
                            {
                                if (!global.win.load.isOpen())
                                {
                                    if (APP::listaFileCartella("/Projects").empty())
                                    {
                                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Non e' presente nessun progetto da caricare", NULL);
                                        break;
                                    }
                                    else
                                    {
                                        global.win.load.Initialize("Load", 500, 300, &global.click, true, 0, 0, false);
                                        global.win.load.getTextures() = TEXTURE::CreateIconsTextures(global.win.load.getRenderer(), global.loadedSurfaces);
                                        global.click = { -1, -1 };
                                        global.win.load.SetProject(true);
                                        SET::loadWindow(global);
                                    }
                                }
                                break;
                            }
                            }
                        }
                    }
                    break;
                }
                case 2:
                {
                    for (auto& menuRect : menuEdit) // Menu Edit
                    {
                        if (APP::isPixelInRect(global.click, &menuRect.rect))
                        {
                            mainMenuRect[i].condition = false;

                            switch (menuRect.type)
                            {
                            case MenuEditType::Undo:
                            {
                                APP::Undo(global);
                                break;
                            }
                            case MenuEditType::Redo:
                            {
                                APP::Redo(global);
                                break;
                            }
                            case MenuEditType::Copy:
                            {
                                APP::copy(global);
                                break;
                            }
                            case MenuEditType::Paste:
                            {
                                APP::paste(global, false);
                                break;
                            }
                            case MenuEditType::PasteInPlace:
                            {
                                APP::paste(global, true);
                                break;
                            }
                            case MenuEditType::RiempiConPP:
                            {
                                GRAPHICS::fillMapWithSelectedArea(global, color_PP);
                                break;
                            }
                            case MenuEditType::RiempiConSF:
                            {
                                GRAPHICS::fillMapWithSelectedArea(global, color_SF);
                                break;
                            }
                            }
                        }
                    }
                    break;
                }
                case 3:
                {
                    for (auto& menuRect : menuSelection) // Menu Selection
                    {
                        if (APP::isPixelInRect(global.click, &menuRect.rect))
                        {   
                            mainMenuRect[i].condition = false;

                            switch (menuRect.type)
                            {
                            case MenuSelectionType::All:
                            {
                                SDL_FRect drawRect = {
                                    level()[global.currentLevel].moveCoord.x,
                                    level()[global.currentLevel].moveCoord.y,
                                    level()[global.currentLevel].zoomSize.w,
                                    level()[global.currentLevel].zoomSize.h
                                };

                                selections->GetLastType() = Tools::SELEZIONE_RETTANGOLARE;
                                selections->GetRect() = drawRect;
                                selections->IsSelected() = true;
                                break;
                            }
                            case MenuSelectionType::Nothing:
                            {
                                if (selections && selections->IsSelected())
                                {
                                    selections->IsSelected() = false;
                                    selections->Update({ 0.0f, 0.0f }, false, false, false, true);
                                    selections->GetLastType() = Tools::NOTHING;
                                }
                                break;
                            }
                            case MenuSelectionType::Invert:
                            {
                                if (selections && selections->IsSelected())
                                {
                                    SDL_FRect rect = selections->GetRect();
                                    Coord offset = global.win.Main.level()[global.currentLevel].moveCoord;
                                    float zoom = global.win.Main.level().GetZoom();

                                    auto isPixelInSelection = [&](Coord pixel) -> bool
                                        {
                                            switch (selections->GetLastType())
                                            {
                                            case Tools::SELEZIONE_RETTANGOLARE:
                                            {
                                                SDL_FRect mapRect = {
                                                    (rect.x - offset.x) / zoom,
                                                    (rect.y - offset.y) / zoom,
                                                    rect.w / zoom,
                                                    rect.h / zoom
                                                };

                                                return APP::isPixelInRect(pixel, &mapRect);
                                            }
                                            case Tools::SELEZIONE_CIRCOLARE:
                                            {
                                                SDL_FRect mapRect = {
                                                    (rect.x - offset.x) / zoom,
                                                    (rect.y - offset.y) / zoom,
                                                    rect.w / zoom,
                                                    rect.h / zoom
                                                };

                                                return APP::isPixelInEllisse(pixel, &mapRect);
                                            }
                                            case Tools::SELEZIONE_LAZO:
                                            {
                                                return selections->GetArea().count(pixel);
                                            };
                                            case Tools::SELEZIONE_COLORE:
                                            {
                                                return selections->GetArea().count(pixel);
                                                break;
                                            }
                                            }
                                            return false;
                                        };

                                    std::unordered_set<Coord> invertedArea;

                                    std::vector<std::vector<ColorRgb>> map = level()[global.currentLevel].map;
                                    for (size_t y = 0; y < map.size(); ++y)
                                    {
                                        for (size_t x = 0; x < map[y].size(); ++x)
                                        {
                                            if (!isPixelInSelection({ static_cast<float>(x), static_cast<float>(y) }))
                                            {
                                                invertedArea.insert({ static_cast<float>(x), static_cast<float>(y) });
                                            }
                                        }
                                    }

                                    selections->GetArea() = invertedArea;
                                    selections->SetLastType(Tools::SELEZIONE_COLORE);

                                    SDL_DestroyTexture(selections->getTexture());
                                    selections->getTexture() = selections->createEdgeAreaTexture();
                                }
                                break;
                            }
                            case MenuSelectionType::NewLevel:
                            {
                                APP::createNewLevelFromSelection(global);
                                break;
                            }
                            }
                        }
                    }
                    break;
                }
                }

                SDL_FRect limit = { 0.0f, 0.0f, 0.0f, 0.0f };

                switch (i)
                {
                case 0:
                {
                    limit = {
                        mainMenuRect[i].rect.x - (mainMenuRect[i].rect.x - menuFile[0].rect.x) / 2.0f,
                        0.0f,
                        mainMenuRect[i].rect.x + mainMenuRect[i].rect.w + (mainMenuRect[i].rect.x - menuFile[0].rect.x),
                        menuFile.back().rect.y + menuFile.back().rect.h
                    };
                    break;
                }
                case 1:
                {
                    limit = {
                        mainMenuRect[i].rect.x - (mainMenuRect[i].rect.x - menuProject[0].rect.x) / 2.0f,
                        0.0f,
                        mainMenuRect[i].rect.x + mainMenuRect[i].rect.w + (mainMenuRect[i].rect.x - menuProject[0].rect.x),
                        menuProject.back().rect.y + menuProject.back().rect.h
                    };
                    break;
                }
                case 2:
                {
                    limit = {
                        mainMenuRect[i].rect.x - (mainMenuRect[i].rect.x - menuEdit[0].rect.x) / 2.0f,
                        0.0f,
                        mainMenuRect[i].rect.x + mainMenuRect[i].rect.w + (mainMenuRect[i].rect.x - menuEdit[0].rect.x),
                        menuEdit.back().rect.y + menuEdit.back().rect.h
                    };
                    break;
                }
                case 3:
                {
                    limit = {
                        mainMenuRect[i].rect.x - (mainMenuRect[i].rect.x - menuSelection[0].rect.x) / 2.0f,
                        0.0f,
                        mainMenuRect[i].rect.x + mainMenuRect[i].rect.w + (mainMenuRect[i].rect.x - menuSelection[0].rect.x),
                        menuSelection.back().rect.y + menuSelection.back().rect.h
                    };
                    break;
                }
                }

                if (!APP::isPixelInRect(global.click, &limit)) // Controllo limiti
                {
                    for (size_t j = 0; j < mainMenuRect.size(); ++j)
                    {
                        if (mainMenuRect[j].condition) mainMenuRect[j].condition = false;
                    }
                }
            }
        }

        if (!level().GetLevel().empty())
        {
            for (size_t i = 0; i < levelMenu.size(); ++i) // Gestione menu livelli
            {
                if (APP::isPixelInRect(global.click, &levelMenu[i].rect))
                {
                    switch (i)
                    {
                    case 0:
                    {
                        if (!global.win.setNew.isOpen())
                        {
                            global.win.setNew.Initialize("New", 500, 300, &global.click, true, 0, 0, false);
                            global.win.setNew.getTextures() = TEXTURE::CreateIconsTextures(global.win.setNew.getRenderer(), global.loadedSurfaces);
                            global.click = { -1, -1 };
                            SET::newTextBox(global, true);
                        }
                        break;
                    }
                    case 1:
                    {
                        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "Errore", "Questa operazione non e' ancora disponibile", nullptr);
                        break;
                    }
                    case 2:
                    {
                        if (level().GetLevel().size() > 1)
                        {
                            if (APP::messageBoxYesNo("Elimina", "Vuoi davvero eliminare il livello '" + level()[global.currentLevel].name + "'?") == 1)
                            {
                                level().GetLevel().erase(level().GetLevel().begin() + global.currentLevel);

                                if (global.currentLevel == global.baseLevelPos)
                                {
                                    global.win.Main.level().SetBaseLevelDeleted(true);
                                }

                                if (global.currentLevel != 0) global.currentLevel--;
                            }
                        }
                        else
                        {
                            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "Errore", "Non e' possibile eliminare l'ultimo livello", nullptr);
                        }
                        break;
                    }
                    case 3:
                    {
                        APP::ancoraLivello(global, global.currentLevel);
                        break;
                    }
                    }
                }
            }
        }
    }
}

void MainWin::Draw()
{
    for (size_t i = 0; i < mainMenuRect.size(); ++i) // Menu Principale
    {
        std::string text;
        switch (i)
        {
        case 0: text = "File"; break;
        case 1: text = "Project"; break;
        case 2: text = "Edit"; break;
        case 3: text = "Selection"; break;
        }

        SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
        SDL_RenderFillRect(renderer, &mainMenuRect[i].rect);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderRect(renderer, &mainMenuRect[i].rect);
        GRAPHICS::PrintCentered(text, &mainMenuRect[i].rect, 15, renderer, getTextures());
    }

    for (int i = 0; i < 2; ++i) // Quadrati Selezione Colore
    {
        SDL_FRect* colorRect = (i == 1) ? &colorRect_PP : &colorRect_SF;
        ColorRgb* color = (i == 1) ? &color_PP : &color_SF;

        SDL_SetRenderDrawColor(renderer, color->r, color->g, color->b, color->a);
        SDL_RenderFillRect(renderer, colorRect);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_FRect cornice_1 = {
            colorRect->x - 1,
            colorRect->y - 1,
            colorRect->w + 2,
            colorRect->h + 2
        };
        SDL_RenderRect(renderer, &cornice_1);
        SDL_FRect cornice_2 = {
            colorRect->x - 2,
            colorRect->y - 2,
            colorRect->w + 4,
            colorRect->h + 4
        };
        SDL_RenderRect(renderer, &cornice_2);
    }
    SDL_RenderTexture(renderer, TEXTURE::getTexture(getTextures(), "Freccia2Punte").texture, nullptr, &frecciaRect);

    SDL_FRect areaLavoroInt = {
        std::floor(areaDiLavoro.x),
        std::floor(areaDiLavoro.y),
        std::floor(areaDiLavoro.w),
        std::floor(areaDiLavoro.h)
    };
    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255); // Area di lavoro
    SDL_RenderRect(renderer, &areaLavoroInt);

    for (size_t i = 0; i < global.win.Main.GetTools().menuFile.size(); ++i) // Tools
    {
        for (auto& name : textures)
        {
            if (name.name == global.win.Main.GetTools().menuFile[i].text && name.texture)
            {
                SDL_RenderTexture(renderer, name.texture, NULL, &global.win.Main.GetTools().menuFile[i].rect);
                break;
            }
        }
    }

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255); 
    SDL_RenderRect(renderer, &rectGestioneTools); // Rettangolo gestione tools

    std::string toolStr = APP::getToolString(tools.current);
    if (!toolStr.empty())
    {
        float h = rectGestioneTools.h / 30.0f;
        SDL_RenderLine(renderer, rectGestioneTools.x, rectGestioneTools.y + h, rectGestioneTools.x + rectGestioneTools.w, rectGestioneTools.y + h);

        SDL_FRect temp = rectGestioneTools;
        temp.h = h;

        SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
        SDL_RenderFillRect(renderer, &temp);
        GRAPHICS::PrintCentered(toolStr, &temp, 10, renderer, textures);
    }

    for (const auto& tool : tools.menuFile) // Cornice Tools Corrente
    {
        if ((tool.text == "MOVE" && tools.current == Tools::MOVE) ||
            (tool.text == "PENNELLO" && tools.current == Tools::BRUSH) ||
            (tool.text == "GOMMA" && tools.current == Tools::ERASER) ||
            (tool.text == "BUCKET" && tools.current == Tools::BUCKET) ||
            (tool.text == "PIPETTA" && tools.current == Tools::PIPETTE) ||
            (tool.text == "selezioneRettangolare" && tools.current == Tools::SELEZIONE_RETTANGOLARE) || 
            (tool.text == "selezioneCircolare" && tools.current == Tools::SELEZIONE_CIRCOLARE) ||
            (tool.text == "selezioneLazo" && tools.current == Tools::SELEZIONE_LAZO) ||
            (tool.text == "selezioneColore" && tools.current == Tools::SELEZIONE_COLORE))
        {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_FRect frame = {
                tool.rect.x - 1,
                tool.rect.y - 1,
                tool.rect.w + 2,
                tool.rect.h + 2
            };
            SDL_RenderRect(renderer, &frame);
            frame = {
                tool.rect.x - 2, 
                tool.rect.y - 2, 
                tool.rect.w + 4, 
                tool.rect.h + 4 
            };
            SDL_RenderRect(renderer, &frame);
            break;
        }
    }

    for (size_t i = 0; i < mainMenuRect.size(); ++i) // Menu Selezionato
    {
        if (mainMenuRect[i].condition)
        {
            switch (i)
            {
            case 0:
            {
                float offset = (menuFile[0].rect.w - mainMenuRect[i].rect.w) / 4.0f;
                SDL_FRect backGrRect = {
                    mainMenuRect[i].rect.x - offset,
                    mainMenuRect[i].rect.y + mainMenuRect[i].rect.h,
                    mainMenuRect[i].rect.w + offset * 2.0f,
                    menuFile.back().rect.y + menuFile.back().rect.h - mainMenuRect[i].rect.h
                };
                SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                SDL_RenderFillRect(renderer, &backGrRect);
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderRect(renderer, &backGrRect);

                for (const auto& menu : menuFile)
                {
                    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                    SDL_RenderFillRect(renderer, &menu.rect);
                    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                    SDL_RenderRect(renderer, &menu.rect);

                    GRAPHICS::PrintCentered(menu.text, &menu.rect, 10, renderer, getTextures());
                }
                break;
            }
            case 1:
            {
                float offset = (menuProject[0].rect.w - mainMenuRect[i].rect.w) / 4.0f;
                SDL_FRect backGrRect = {
                    mainMenuRect[i].rect.x - offset,
                    mainMenuRect[i].rect.y + mainMenuRect[i].rect.h,
                    mainMenuRect[i].rect.w + offset * 2.0f,
                    menuProject.back().rect.y + menuProject.back().rect.h - mainMenuRect[i].rect.h
                };
                SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                SDL_RenderFillRect(renderer, &backGrRect);
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderRect(renderer, &backGrRect);

                for (const auto& menu : menuProject)
                {
                    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                    SDL_RenderFillRect(renderer, &menu.rect);
                    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                    SDL_RenderRect(renderer, &menu.rect);

                    GRAPHICS::PrintCentered(menu.text, &menu.rect, 10, renderer, getTextures());
                }
                break;
            }
            case 2:
            {
                float offset = (menuEdit[0].rect.w - mainMenuRect[i].rect.w) / 4.0f;
                SDL_FRect backGrRect = {
                    mainMenuRect[i].rect.x - offset,
                    mainMenuRect[i].rect.y + mainMenuRect[i].rect.h,
                    mainMenuRect[i].rect.w + offset * 2.0f,
                    menuEdit.back().rect.y + menuEdit.back().rect.h - mainMenuRect[i].rect.h
                };
                SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                SDL_RenderFillRect(renderer, &backGrRect);
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderRect(renderer, &backGrRect);

                for (const auto& menu : menuEdit)
                {
                    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                    SDL_RenderFillRect(renderer, &menu.rect);
                    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                    SDL_RenderRect(renderer, &menu.rect);

                    GRAPHICS::PrintCentered(menu.text, &menu.rect, 10, renderer, getTextures());
                }
                break;
            }
            case 3:
            {
                float offset = (menuSelection[0].rect.w - mainMenuRect[i].rect.w) / 4.0f;
                SDL_FRect backGrRect = {
                    mainMenuRect[i].rect.x - offset,
                    mainMenuRect[i].rect.y + mainMenuRect[i].rect.h,
                    mainMenuRect[i].rect.w + offset * 2.0f,
                    menuSelection.back().rect.y + menuSelection.back().rect.h - mainMenuRect[i].rect.h
                };
                SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                SDL_RenderFillRect(renderer, &backGrRect);
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderRect(renderer, &backGrRect);

                for (const auto& menu : menuSelection)
                {
                    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
                    SDL_RenderFillRect(renderer, &menu.rect);
                    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                    SDL_RenderRect(renderer, &menu.rect);

                    GRAPHICS::PrintCentered(menu.text, &menu.rect, 10, renderer, getTextures());
                }
                break;
            }
            }
        }
    }

    for (size_t i = 0; i < toolsSetting.size(); ++i) // Tools Setting
    {
        const auto& slider = toolsSetting[i];
        if (slider)
        {
            slider->Draw();

            std::string toolStr = APP::getToolsSettingString(tools.current, static_cast<int>(i)) += ':';
            SDL_FRect sliderRect = slider->GetRect();

            SDL_FRect strRect = {
                sliderRect.x - rectGestioneTools.w / 5.0f,
                sliderRect.y,
                0.0f,
                sliderRect.h
            };
            strRect.w = sliderRect.x - strRect.x;
            strRect.w *= 0.9f;

            GRAPHICS::PrintCentered(toolStr, &strRect, 7, renderer, textures);
        }
    }

    if (!level().GetLevel().empty() && level().IsOpen())
    {
        SDL_GetMouseState(&global.cursorPosition.x, &global.cursorPosition.y);
        Coord clickPos = {
            (global.cursorPosition.x - level()[global.currentLevel].moveCoord.x) / level().GetZoom(),
            (global.cursorPosition.y - level()[global.currentLevel].moveCoord.y) / level().GetZoom(),
        };

        SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255); 
        SDL_FRect temp = {
            areaDiLavoro.x,
            static_cast<float>(global.win.Main.getSize().h - (global.win.Main.getSize().h - areaDiLavoro.h) / 2.0f) - 1.0f,
            areaDiLavoro.w / 9.50f,
            areaDiLavoro.h / 40.0f
        };
        SDL_RenderRect(renderer, &temp); // Rettangolo Coordinate Mouse
        GRAPHICS::PrintCentered(
            "x:" + std::to_string(static_cast<int>(clickPos.x)) + " y:" + std::to_string(static_cast<int>(clickPos.y)),
            &temp,
            8.0f,
            global.win.Main.getRenderer(),
            global.win.Main.getTextures()
        );

        temp = {
            areaDiLavoro.x + temp.w,
            temp.y,
            areaDiLavoro.w / 15.0f,
            temp.h
        };
        SDL_RenderRect(renderer, &temp); // Rettangolo Zoom
        std::stringstream ss;
        ss << std::fixed << std::setprecision(2) << level().GetZoom() * 100.0f;
        std::string s = ss.str();
        GRAPHICS::PrintCentered(s + "%", &temp, 8.0f, global.win.Main.getRenderer(), global.win.Main.getTextures());

        float h = levelRect.h / 20;

        temp = {
            levelRect.x,
            levelRect.y - h,
            levelRect.w,
            h
        };
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderRect(renderer, &temp);

        std::vector<Uint8> colori = { 180, 160 };
        for (size_t i = 0; i < colori.size(); ++i) // Cornice levelRect
        {
            temp = {
                levelRect.x - (i * 1),
                levelRect.y - (i * 1),
                levelRect.w + (i * 2),
                levelRect.h + (i * 2)
            };

            SDL_SetRenderDrawColor(renderer, colori[i], colori[i], colori[i], 255);
            SDL_RenderRect(renderer, &temp);
        }

        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        for (size_t i = 0; i < levelMenu.size(); ++i) // LevelMenu
        {
            float scala = 0.6f;
            temp = {
                levelMenu[i].rect.x + (levelMenu[i].rect.w - levelMenu[i].rect.w * scala) / 2.0f,
                levelMenu[i].rect.y + (levelMenu[i].rect.h - levelMenu[i].rect.h * scala) / 2.0f,
                levelMenu[i].rect.w * scala,
                levelMenu[i].rect.h * scala
            };

            SDL_RenderLine(renderer, levelRect.x + (i + 1) * h, levelRect.y - h, levelRect.x + (i + 1) * h, levelRect.y);
            SDL_RenderTexture(renderer, TEXTURE::getTexture(getTextures(), levelMenu[i].text).texture, NULL, &temp);
        }
        for (size_t i = 0; i < level().GetLevel().size(); ++i) // LevelRect
        {
            temp = {
                levelRect.x,
                levelRect.y + h * i,
                levelRect.w,
                h
            };
            if (levelRectMovingPos == i && levelRectMovingPos != -1)
            {
                float newVal = global.cursorPosition.y - temp.h / 2.0f;
                if (newVal < levelRect.y) newVal = levelRect.y;
                else if (newVal + h > levelRect.y + levelRect.h) newVal = levelRect.y + levelRect.h - h;
                
                temp.y = newVal;
            }

            Uint8 c = (i == global.currentLevel) ? 16 : 32;
            SDL_SetRenderDrawColor(renderer, c, c, c, 255);
            SDL_RenderFillRect(renderer, &temp);

            GRAPHICS::PrintCentered(level()[static_cast<int>(i)].name, &temp, h * 0.4f, renderer, getTextures());

            float occhioSize = levelRect.w / 9;
            temp = {
                global.win.Main.getSize().w - occhioSize,
                temp.y,
                occhioSize,
                temp.h
            };
            SDL_RenderFillRect(renderer, &temp);

            std::string occhioStr = ((level()[i].isVisible) ? "Visibile" : "NonVisibile"); // Occhio Livello
            FSize scale = { 0.8f, ((occhioStr == "Visibile") ? 0.6f : 0.8f)};
            temp = {
                temp.x + (temp.w - temp.w * scale.w) / 2.0f,
                temp.y + (temp.h - temp.h * scale.h) / 2.0f,
                temp.w * scale.w,
                temp.h * scale.h
            };
            SDL_RenderFillRect(renderer, &temp);
            SDL_RenderTexture(renderer, TEXTURE::getTexture(getTextures(), occhioStr).texture, nullptr, &temp);
        }

        if (opacity) // textBox Opacity
        {
            opacity->Draw();
            SDL_FRect rect = opacity->getRect();

            std::string str = "Opacity";
            float size = APP::GetTextWidth(str, 10.0f, textures, 0.35f);
            temp = {
                rect.x,
                rect.y,
                size * 1.3f,
                rect.h
            };
            GRAPHICS::PrintCentered(str, &temp, 10.0f, renderer, textures);

            std::stringstream ss;
            ss << std::fixed << std::setprecision(2) << level()[global.currentLevel].opacity / 255.0f * 100.0f;
            str = ss.str() + '%';
            float space = size * 1.3f - size;
            size = APP::GetTextWidth(str, 10.0f, textures, 0.35f);
            temp = {
                rect.x + rect.w - size - space,
                rect.y,
                size + space,
                rect.h
            };
            GRAPHICS::PrintCentered(str, &temp, 10.0f, renderer, textures);
        }
    }
}

void MainWin::UpdateCursorSkin()
{
    static SDL_Cursor* defaultCursor = nullptr;
    static SDL_Cursor* handCursor = nullptr;
    static bool cursorsLoaded = false;
    static bool handActive = false;
    static std::string currentPath;

    auto& lvl = level();

    auto loadCursor = [&](int w, int h, std::string path)
        {
            defaultCursor = SDL_GetDefaultCursor();

            SDL_Surface* surface = IMG_Load(path.c_str());
            if (!surface)
            {
                SDL_Log("Errore caricamento cursore ManoChiusa: %s", SDL_GetError());
                cursorsLoaded = true;
                return;
            }

            SDL_Surface* scaled = SDL_CreateSurface(w, h, SDL_PIXELFORMAT_RGBA32);
            if (!scaled)
            {
                SDL_Log("Errore creazione surface scalata cursore: %s", SDL_GetError());
                SDL_DestroySurface(surface);
                cursorsLoaded = true;
                return;
            }

            SDL_BlitSurfaceScaled(surface, nullptr, scaled, nullptr, SDL_SCALEMODE_LINEAR);
            handCursor = SDL_CreateColorCursor(scaled, w / 2, h / 2);

            SDL_DestroySurface(surface);
            SDL_DestroySurface(scaled);

            if (!handCursor)
            {
                SDL_Log("Errore creazione cursore mano SDL: %s", SDL_GetError());
                cursorsLoaded = true;
                return;
            }

            cursorsLoaded = true;
            currentPath = path;
        };

    auto isCursorInDraw = [&]() -> bool
        {
            if (global.cursorPosition.x >= lvl[global.currentLevel].moveCoord.x &&
                global.cursorPosition.x <= lvl[global.currentLevel].moveCoord.x + lvl[global.currentLevel].zoomSize.w &&
                global.cursorPosition.y >= lvl[global.currentLevel].moveCoord.y &&
                global.cursorPosition.y <= lvl[global.currentLevel].moveCoord.y + lvl[global.currentLevel].zoomSize.h) return true;

            return false;
        };

    auto isCursorInLevelRects = [&]() ->bool
        {
            float h = levelRect.h / 20;

            SDL_FRect rect = {
                levelRect.x,
                levelRect.y,
                levelRect.w,
                h * static_cast<float>(level().GetLevel().size())
            };

            return APP::isPixelInRect(global.cursorPosition, &rect);
        };

    if (lvl[global.currentLevel].pressed)
    {
        std::string path = "Texture/Simboli/ManoChiusa.png";
        if (!cursorsLoaded || currentPath != path)
        {
            loadCursor(20, 20, path);
        }

        if (!handActive && (isCursorInDraw() || isCursorInLevelRects()))
        {
            SDL_SetCursor(handCursor);
            SDL_ShowCursor();
            handActive = true;
        }
    }
    else if (tools.current == Tools::PIPETTE && isCursorInDraw() && !lvl[global.currentLevel].pressed)
    {
        std::string path = "Texture/Simboli/PipettaMouse.png";
        if (!cursorsLoaded || currentPath != path)
        {
            loadCursor(50, 50, path);
        }

        if (!handActive)
        {
            SDL_SetCursor(handCursor);
            SDL_ShowCursor();
            handActive = true;
        }
    }
    else
    {
        if (handActive)
        {
            SDL_SetCursor(defaultCursor);
            SDL_ShowCursor();
            handActive = false;
        }
    }

    if ((tools.current == Tools::BRUSH || tools.current == Tools::ERASER) && !lvl[global.currentLevel].pressed)
    {
        float currentSize = (tools.current == Tools::BRUSH)
            ? tools.setting.brush.size
            : tools.setting.eraser.size;

        currentSize /= 2.0f;
        if (isCursorInDraw())
        {
            ColorRgb colorTemp = { 0, 0, 0, 255 };

            size_t mapX = static_cast<size_t>((global.cursorPosition.x - lvl[global.currentLevel].moveCoord.x) / lvl.GetZoom());
            size_t mapY = static_cast<size_t>((global.cursorPosition.y - lvl[global.currentLevel].moveCoord.y) / lvl.GetZoom());

            if (mapY < lvl[global.currentLevel].map.size() && mapX < lvl[global.currentLevel].map[mapY].size())
            {
                auto& pixel = lvl[global.currentLevel].map[mapY][mapX];
                if (pixel.r <= 20 && pixel.g <= 20 && pixel.b <= 20 && pixel.a >= 240)
                    colorTemp = { 255, 255, 255, 255 };
            }

            GRAPHICS::RenderCircle(
                renderer,
                global.cursorPosition.x,
                global.cursorPosition.y,
                currentSize * lvl.GetZoom(),
                colorTemp
            );

            if (global.mouseVisible)
            {
                global.mouseVisible = false;
                SDL_HideCursor();
            }
        }
        else if (!global.mouseVisible)
        {
            global.mouseVisible = true;
            SDL_ShowCursor();
        }
    }
    else if (!lvl[global.currentLevel].pressed && !global.mouseVisible)
    {
        global.mouseVisible = true;
        SDL_ShowCursor();
    }
}

void MainWin::UpdateMenuTools()
{
    for (auto& tool : tools.menuFile)
    {
        if (APP::isPixelInRect(global.click, &tool.rect))
        {
            bool notFound = false;

            if (tool.text == "MOVE")
            {
                tools.current = Tools::MOVE;
            }
            else if (tool.text == "PENNELLO")
            {
                tools.current = Tools::BRUSH;
            }
            else if (tool.text == "GOMMA")
            {
                tools.current = Tools::ERASER;
            }
            else if (tool.text == "BUCKET")
            {
                tools.current = Tools::BUCKET;
            }
            else if (tool.text == "PIPETTA")
            {
                tools.current = Tools::PIPETTE;
            }
            else if (tool.text == "selezioneRettangolare")
            {
                tools.current = Tools::SELEZIONE_RETTANGOLARE;

                if (selections->GetLastType() != Tools::SELEZIONE_RETTANGOLARE && !selections->IsSelected())
                {
                    selections->Update({ 0.0f, 0.0f }, false, false, false, true);
                    selections->GetLastType() = Tools::SELEZIONE_RETTANGOLARE;
                }
            }
            else if (tool.text == "selezioneCircolare")
            {
                tools.current = Tools::SELEZIONE_CIRCOLARE;
                
                if (selections->GetLastType() != Tools::SELEZIONE_CIRCOLARE && !selections->IsSelected())
                {
                    selections->Update({ 0.0f, 0.0f }, false, false, false, true);
                    selections->GetLastType() = Tools::SELEZIONE_CIRCOLARE;
                }
            }
            else if (tool.text == "selezioneLazo")
            {
                tools.current = Tools::SELEZIONE_LAZO;
                
                if (selections->GetLastType() != Tools::SELEZIONE_LAZO && !selections->IsSelected())
                {
                    selections->Update({ 0.0f, 0.0f }, false, false, false, true);
                    selections->GetLastType() = Tools::SELEZIONE_LAZO;
                }
            }
            else if (tool.text == "selezioneColore")
            {
                tools.current = Tools::SELEZIONE_COLORE;

                if (selections->GetLastType() != Tools::SELEZIONE_COLORE && !selections->IsSelected())
                {
                    selections->Update({ 0.0f, 0.0f }, false, false, false, true);
                    selections->GetLastType() = Tools::SELEZIONE_COLORE;
                }
            }
            else
            {
                notFound = true;
            }

            if (!notFound)
            {
                SET::toolsSetting(global);
            }
        }
    }

    if (APP::isPixelInRect(global.click, &colorRect_PP) && !global.win.color.isOpen())
    {
        global.win.color.Initialize("Seleziona colore PP", 600, 400, false, getSize().w / 5, getSize().h / 10, false, false);
        global.win.color.getTextures() = TEXTURE::CreateIconsTextures(global.win.color.getRenderer(), global.loadedSurfaces);
        global.click = { -1, -1 };
        global.win.color.Set();
        global.win.color.SetIsColorPP(true);
    }
    else if (APP::isPixelInRect(global.click, &colorRect_SF) && !global.win.color.isOpen())
    {
        global.win.color.Initialize("Seleziona colore SF", 600, 400, false, getSize().w / 5, getSize().h / 10, false, false);
        global.win.color.getTextures() = TEXTURE::CreateIconsTextures(global.win.color.getRenderer(), global.loadedSurfaces);
        global.click = { -1, -1 };
        global.win.color.Set();
        global.win.color.SetIsColorPP(false);
    }

    if (APP::isPixelInRect(global.click, &frecciaRect))
    {
        ColorRgb temp = color_PP;
        color_PP = color_SF;
        color_SF = temp;
    }
}

void MainWin::UpdateLevelSwaps(bool levelMoving, bool levelRealesed)
{
    static bool isMoving = false;
    static size_t pos = global.currentLevel;
    static bool levelRectGrabbed = false; 

    float h = levelRect.h / 20.0f;
    size_t levelCount = level().GetLevel().size();

    if (!isMoving && !levelMoving && !levelRealesed)
    {
        if (global.leftMousePressed && !global.hasMovedSinceClick)
        {
            SDL_FRect listRect = {
                levelRect.x,
                levelRect.y,
                levelRect.w,
                h * static_cast<float>(levelCount)
            };

            levelRectGrabbed = APP::isPixelInRect(global.click, &listRect);
        }

        if (!levelRectGrabbed) return;

        for (size_t i = 0; i < levelCount; ++i)
        {
            SDL_FRect temp = {
                levelRect.x,
                levelRect.y + h * static_cast<float>(i),
                levelRect.w,
                h
            };

            float occhioSize = levelRect.w / 9.0f;
            SDL_FRect rectOcchio = {
                global.win.Main.getSize().w - occhioSize,
                temp.y,
                occhioSize,
                temp.h
            };

            if (APP::isPixelInRect(global.click, &rectOcchio))
            {
                level()[i].isVisible = !level()[i].isVisible;
                return;
            }
            else if (APP::isPixelInRect(global.click, &temp))
            {
                pos = i;
            }
        }
    }
    else if (levelMoving)
    {
        if (!isMoving && levelRectGrabbed)
        {
            isMoving = true;
            levelRectMovingPos = static_cast<int>(pos);
        }
    }
    else if (levelRealesed)
    {
        if (levelRectGrabbed)
        {
            if (isMoving)
            {
                for (size_t i = 0; i < levelCount; ++i)
                {
                    SDL_FRect temp = {
                        levelRect.x,
                        levelRect.y + h * static_cast<float>(i),
                        levelRect.w,
                        h
                    };

                    if (APP::isPixelInRect(global.click, &temp))
                    {
                        if (i != pos)
                        {
                            std::swap(level()[i], level()[pos]);
                            global.currentLevel = static_cast<int>(i);

                            global.baseLevelPos = (i == global.baseLevelPos) ? pos : (pos == global.baseLevelPos) ? i : global.baseLevelPos;
                        }
                    }
                }

                isMoving = false;
            }
            else
            {
                if (pos != global.currentLevel)
                {
                    global.currentLevel = static_cast<int>(pos);

                    if (opacity)
                    {
                        opacity->SetValore(level()[pos].opacity);
                    }
                }
            }

            if (levelRectMovingPos != -1)
            {
                levelRectMovingPos = -1;
            }
            levelRectGrabbed = false;
        }
    }
}


// bgColor (Get/Set)
ColorRgb& MainWin::GetBgColor() { return bgColor; }
const ColorRgb& MainWin::GetBgColor() const { return bgColor; }
void MainWin::SetBgColor(const ColorRgb& newBgColor) { bgColor = newBgColor; }

// fileRectMenu (Get/Set)
SDL_FRect& MainWin::GetFileRectMenu() { return fileRectMenu; }
const SDL_FRect& MainWin::GetFileRectMenu() const { return fileRectMenu; }
void MainWin::SetFileRectMenu(const SDL_FRect& newRect) { fileRectMenu = newRect; }

// rectTavolaColori (Get/Set)
const SDL_FRect& MainWin::GetRectTavolaColori() const { return rectTavolaColori; }
void MainWin::SetRectTavolaColori(const SDL_FRect& newRect) { rectTavolaColori = newRect; }

// colorRect_PP (Get/Set)
const SDL_FRect& MainWin::GetColorRect_PP() const { return colorRect_PP; }
void MainWin::SetColorRect_PP(const SDL_FRect& newRect) { colorRect_PP = newRect; }

// colorRect_PP (Get/Set)
const SDL_FRect& MainWin::GetColorRect_SF() const { return colorRect_SF; }
void MainWin::SetColorRect_SF(const SDL_FRect& newRect) { colorRect_SF = newRect; }

// levelRect (Get/Set)
const SDL_FRect& MainWin::GetLevelRect() const { return levelRect; }
void MainWin::SetLevelRect(const SDL_FRect& newRect) { levelRect = newRect; }

// frecciaRect (Get/Set)
const SDL_FRect& MainWin::GetFrecciaRect() const { return frecciaRect; }
void MainWin::SetFrecciaRect(const SDL_FRect& newRect) { frecciaRect = newRect; }

// rectGestioneTools (Get/Set)
const SDL_FRect& MainWin::GetRectGestioneTools() const { return rectGestioneTools; }
void MainWin::SetRectGestioneTools(const SDL_FRect& newRect) { rectGestioneTools = newRect; }

// areaDiLavoro (Get/Set)
SDL_FRect& MainWin::GetAreaDiLavoro() { return areaDiLavoro; }
const SDL_FRect& MainWin::GetAreaDiLavoro() const { return areaDiLavoro; }
void MainWin::SetAreaDiLavoro(const SDL_FRect& newRect) { areaDiLavoro = newRect; }

// level (std::vector<DrawMap>)
Project& MainWin::level() { return level_; }
const Project& MainWin::level() const { return level_; }

// color_PP 
ColorRgb& MainWin::GetColor_PP() { return color_PP; }
const ColorRgb& MainWin::GetColor_PP() const { return color_PP; }
void MainWin::SetColor_PP(const ColorRgb& newColor) { color_PP = newColor; }

// color_SF 
ColorRgb& MainWin::GetColor_SF() { return color_SF; }
const ColorRgb& MainWin::GetColor_SF() const { return color_SF; }
void MainWin::SetColor_SF(const ColorRgb& newColor) { color_SF = newColor; }

// tools (ToolsInformation)
ToolsInformation& MainWin::GetTools() { return tools; }
const ToolsInformation& MainWin::GetTools() const { return tools; }
void MainWin::SetTools(const ToolsInformation& newTools) { tools = newTools; }

// mainMenuRect (std::vector<rectBool>)
std::vector<rectBool>& MainWin::GetMainMenuRect() { return mainMenuRect; }
const std::vector<rectBool>& MainWin::GetMainMenuRect() const { return mainMenuRect; }
void MainWin::SetMainMenuRect(const std::vector<rectBool>& newMenu) { mainMenuRect = newMenu; }

// menuFile (std::vector<MenuFile>)
std::vector<MenuFile>& MainWin::GetMenuFile() { return menuFile; }
const std::vector<MenuFile>& MainWin::GetMenuFile() const { return menuFile; }
void MainWin::SetMenuFile(const std::vector<MenuFile>& newMenu) { menuFile = newMenu; }

// menuEdit (std::vector<MenuEdit>)
std::vector<MenuEdit>& MainWin::GetMenuEdit() { return menuEdit; }
const std::vector<MenuEdit>& MainWin::GetMenuEdit() const { return menuEdit; }
void MainWin::SetMenuEdit(const std::vector<MenuEdit>& newMenuEdit) { menuEdit = newMenuEdit; }

// projectMenu (std::vector<MenuProject>)
std::vector<MenuProject>& MainWin::GetMenuProject() { return menuProject; }
const std::vector<MenuProject>& MainWin::GetMenuProject() const { return menuProject; }
void MainWin::SetMenuProject(const std::vector<MenuProject>& newMenu) { menuProject = newMenu; }

// levelMenu (std::vector<MenuFile>)
std::vector<MenuFile>& MainWin::GetlevelMenu() { return levelMenu; }
const std::vector<MenuFile>& MainWin::GetlevelMenu() const { return levelMenu; }
void MainWin::SetlevelMenu(const std::vector<MenuFile>& newlevelMenu) { levelMenu = newlevelMenu; }

// menuSelection (std::vector<MenuSelection>)
std::vector<MenuSelection>& MainWin::GetMenuSelection() { return menuSelection; }
const std::vector<MenuSelection>& MainWin::GetMenuSelection() const { return menuSelection; }
void MainWin::SetMenuSelection(const std::vector<MenuSelection>& newSelectionMenu) { menuSelection = newSelectionMenu; }

// opacity
Slider* MainWin::GetOpacity() { return opacity; }
const Slider* MainWin::GetOpacity() const { return opacity; } 
void MainWin::SetOpacity(Slider* newSlider) { opacity = newSlider; }

// selections
Selections* MainWin::GetSelections() { return selections; }
const Selections* MainWin::GetSelections() const { return selections; }
void MainWin::SetSelections() { selections = new Selections(this, tools.current, global); }

// toolsSetting (std::vector<SliderTextbox*>)
std::vector<SliderTextbox*>& MainWin::GetToolsSetting() { return toolsSetting; }
const std::vector<SliderTextbox*>& MainWin::GetToolsSetting() const { return toolsSetting; }