#pragma once

#include <fstream>
#include <filesystem>

namespace fs = std::filesystem;

#include "variabiliGlobali.h"
#include "graphics.h"
#include "textBox.h"

namespace APP
{
    bool isMainWindowFocus(VariabiliGlobali& global);
    size_t countProjectLines();
    float GetTextWidth(const std::string& text, float size, std::vector<Textures>& textures, float letterSpacing);
    std::vector<std::string> listaFileCartella(const std::string& cartella);
    std::string toLower(std::string s);
    bool isPixelInRect(Coord coord, SDL_FRect* rect);
    void Log(std::string text);
    int messageBoxYesNo(std::string title, std::string msg);
    void applyZoom(VariabiliGlobali& global, SDL_Event& event, float zoomFactor = 1.1f);
    float fromDegToRad(float degrees);
    float fromRadToDeg(float radians);
    bool isPixelInEllisse(Coord pixel, SDL_FRect* ellisse);
    bool isPixelInCircle(Coord coord, Coord center, float radius);
    void createNewLevelFromSelection(VariabiliGlobali& global);
    bool isPixelInDrawAndBasic(Coord pixel, VariabiliGlobali& global);
    void copy(VariabiliGlobali& global);
    void paste(VariabiliGlobali& global, bool isPlace);
    void updateCronology(VariabiliGlobali& global);
    void Undo(VariabiliGlobali& global);
    void Redo(VariabiliGlobali& global);
    std::string getToolString(Tools tool);
    std::string getToolsSettingString(Tools tool, int nSetting);
    void ancoraLivello(VariabiliGlobali& global, size_t lvlPos);
}