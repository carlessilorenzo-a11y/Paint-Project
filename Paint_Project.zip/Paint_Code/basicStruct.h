#pragma once
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_image/SDL_image.h>
#include <vector>
#include <string>
#include <unordered_set>
#include <functional>

class TextBox;

enum class Tools
{
    NOTHING,
    MOVE,
    BRUSH,
    ERASER,
    BUCKET,
    PIPETTE,
    SELEZIONE_RETTANGOLARE,
    SELEZIONE_CIRCOLARE,
    SELEZIONE_LAZO,
    SELEZIONE_COLORE
};

enum class ColorType
{
    BLACK,
    WHITE,
    RED,
    GREEN,
    BLUE,
    YELLOW,
    CYAN,
    MAGENTA
};

enum class MenuFileType
{
    New,
    Save,
    SaveAs,
    Load
};

enum class MenuEditType
{
    Undo,
    Redo,
    Copy,
    Paste,
    PasteInPlace,
    RiempiConPP,
    RiempiConSF
};

enum class MenuSelectionType
{
    All,
    Nothing,
    Invert,
    NewLevel,
};

enum class MenuProjectType
{
    Save,
    SaveAs,
    Load,
};

enum class TypeTxtBox
{
    NUMBERS,
    LETTERS
};

enum class FileType
{
    PNG,
    MBP
};

enum class ColorInterfaccia
{
    RGB,
    RGBHSV
};

struct Coord
{
    float x;
    float y;

    bool operator==(const Coord& other) const
    {
        return x == other.x &&
            y == other.y;
    }

    bool operator!=(const Coord& other) const
    {
        return !(*this == other);
    }
};

namespace std 
{
    template <>
    struct hash<Coord> 
    {
        size_t operator()(const Coord& c) const 
        {
            // Combiniamo l'hash di x e y. 
            // Lo shift a sinistra (<< 1) aiuta a distinguere {1, 2} da {2, 1}
            size_t h1 = hash<float>{}(c.x);
            size_t h2 = hash<float>{}(c.y);
            return h1 ^ (h2 << 1);
        }
    };
}

struct Size
{
    int w;
    int h;

    bool operator==(const Size& other) const
    {
        return w == other.w &&
            h == other.h;
    }

    bool operator!=(const Size& other) const
    {
        return !(*this == other);
    }
};

struct FSize
{
    float w;
    float h;

    bool operator==(const FSize& other) const
    {
        return w == other.w &&
            h == other.h;
    }

    bool operator!=(const FSize& other) const
    {
        return !(*this == other);
    }
};

struct ColorRgb
{
    Uint8 r, g, b, a;

    bool operator==(const ColorRgb& other) const
    {
        return r == other.r &&
            g == other.g &&
            b == other.b &&
            a == other.a;
    }

    bool operator!=(const ColorRgb& other) const
    {
        return !(*this == other);
    }

    ColorRgb& operator=(const ColorRgb& other) 
    {
        if (this == &other) return *this;

        this->r = other.r;
        this->g = other.g;
        this->b = other.b;
        this->a = other.a;

        return *this;
    }
};

struct rectColored
{
    SDL_FRect rect = { 0, 0, 0, 0 };
    ColorType color = {};
};

struct rectColoredRgb
{
    SDL_FRect rect = { 0, 0, 0, 0 };
    ColorRgb color = { 0, 0, 0, 0 };
};

struct rectText
{
    SDL_FRect rect = { 0, 0, 0, 0 };
    std::string text;
};

struct rectBool
{
    SDL_FRect rect = { 0, 0, 0, 0 };
    bool condition = false;
};

struct Textures
{
    std::string name;
    SDL_Texture* texture = nullptr;
};

struct Features
{
    SDL_Window* window;
    SDL_Renderer* renderer;
    bool isOpen = false;
    Size size;
    std::vector<Textures> textures;
};

struct IconsSurface
{
    std::string name;
    SDL_Surface* surface = {};
};

struct MenuFile
{
    MenuFileType type = {};
    bool open = false;
    SDL_FRect rect = {};
    std::string text = "";
};

struct FileRect
{
    FileType type = {};
    bool open = false;
    SDL_FRect rect = {};
    std::string text = "";
};

struct MenuEdit
{
    MenuEditType type = {};
    bool open = false;
    SDL_FRect rect = {};
    std::string text = "";
};

struct MenuSelection
{
    MenuSelectionType type = {};
    bool open = false;
    SDL_FRect rect = {};
    std::string text = "";
};

struct MenuProject
{
    MenuProjectType type = {};
    bool open = false;
    SDL_FRect rect = {};
    std::string text = "";
};

struct ChronologyElements
{
    std::vector<std::vector<ColorRgb>> map;
    Coord moveCoord = { 0.0f, 0.0f };
    SDL_FRect zoomSize = { 0.0f, 0.0f, 0.0f, 0.0f };

    bool operator==(const Coord& other) const {
        return moveCoord == other;
    }

    bool operator!=(const Coord& other) const {
        return *this != other;
    }
};

struct Chronology
{
    std::vector<ChronologyElements> elements = {};
    size_t pos = 0;

    void Reset()
    {
        elements.clear();
        pos = 0;
    }
};

struct SettingBrush
{
    float size = 1.0f;
};

struct SettingEraser
{
    float size = 1.0f;
};

struct SettingBucket
{
    float error = 10.0f;
};

struct SettingColorSelection
{
    float error = 10.0f;
};

struct ToolsSettings
{
    SettingBrush brush;
    SettingEraser eraser;
    SettingBucket bucket;
    SettingColorSelection colorSelection;
};

struct ToolsInformation
{
    Tools current = Tools::NOTHING;
    ToolsSettings setting;
    TextBox* textBoxe = nullptr;
    std::vector<MenuFile> menuFile = {};
};

struct loadFiles
{
    std::string name;
    SDL_FRect rect = { 0 ,0, 0, 0 };
    bool selected = false;
};

struct Triangolo
{
    Coord p1, p2, p3;
};

struct CopySelection
{
    std::string name;
    std::vector<std::vector<ColorRgb>> map;
    SDL_FRect rect = { 0.0f, 0.0f, 0.0f, 0.0f };
    Uint8 opacity = 255;
};

struct Level
{
    std::string name;
    std::vector<std::vector<ColorRgb>> map = {};
    std::vector<std::vector<ColorRgb>> startMap = {};

    Coord moveCoord = { -1, -1 };
    SDL_FRect size = { 0, 0, 0, 0 };
    SDL_FRect zoomSize = { 0, 0, 0, 0 };

    Uint8 opacity = 255;
    bool isVisible = true;
    bool pressed = false;
    ColorRgb bgColor = { 255, 255, 255, 255 };

    Chronology chronology;
    SDL_Texture* canvas = nullptr;
    bool needsUpdate = true;
};