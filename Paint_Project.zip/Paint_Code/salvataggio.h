#pragma once

#include <fstream>

#include "variabiliGlobali.h"

namespace SALVATAGGIO
{
	bool SaveMapToImage(const std::vector<std::vector<ColorRgb>>& map, const std::string& filename, bool savePNG);
	bool LoadMapFromImage(std::vector<std::vector<ColorRgb>>& map, const std::string& filename, const Size windowSize, SDL_FRect& bmpSize);
	void setProjectData(VariabiliGlobali& global);
	void setGlobalFromProjectData(VariabiliGlobali& global, const PntHeader& header, const std::vector<Level>& levels);
	bool saveProjectData(std::string& filename, VariabiliGlobali& global);
	bool loadProjectData(std::string& filename, VariabiliGlobali& global);
}