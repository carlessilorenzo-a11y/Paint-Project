#define SDL_MAIN_HANDLED

#include "editLevel.h"

EditLevel::EditLevel(VariabiliGlobali& global) :
	Window(),
	global(global),
	back({ 0, 0, 0, 0 }),
	next({ 0, 0, 0, 0 }),
	textbox()
{
}

void EditLevel::Draw() {}

void EditLevel::Update() {}