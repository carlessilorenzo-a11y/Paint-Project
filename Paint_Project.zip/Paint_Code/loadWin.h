#pragma once

#include "winTemplate.h"

class Load : public Window
{
protected:
    VariabiliGlobali& global;
    bool loadNext;
    bool project;
    rectText back;
    rectText next;
    SDL_FRect rectLoad;
    SDL_FRect texRect;
    SDL_FRect texScaleted;
    SDL_Texture* currentTex;
    TextBox* textbox;

public:
    Load(VariabiliGlobali& global);

    void Update() override;
    void Draw() override;

    // loadNext (Get/Set)
    bool IsLoadNext() const;
    void SetLoadNext(bool isNext);

    // project (Get/Set)
    bool IsProject() const;
    void SetProject(bool newProject);

    // back (Get/Set)
    rectText& GetBack();
    const rectText& GetBack() const;
    void SetBack(const rectText& newBack);

    // next (Get/Set)
    rectText& GetNext();
    const rectText& GetNext() const;
    void SetNext(const rectText& newNext);

    // rectLoad (Get/Set)
    SDL_FRect& GetRectLoad();
    const SDL_FRect& GetRectLoad() const;
    void SetRectLoad(const SDL_FRect& newRect);

    // texRect (Get/Set)
    SDL_FRect& GetTexRect();
    const SDL_FRect& GetTexRect() const;
    void SetTexRect(const SDL_FRect& newTexRect);

    // currentTex (Get/Set - Gestito come puntatore)
    SDL_Texture* GetCurrentTex();
    const SDL_Texture* GetCurrentTex() const;
    void SetCurrentTex(SDL_Texture* newCurrentTex);

    // textbox (Get/Set - Gestito come puntatore)
    TextBox* GetTextbox();
    const TextBox* GetTextbox() const;
    void SetTextbox(TextBox* newTextbox);
};