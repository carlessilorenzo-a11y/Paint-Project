#define SDL_MAIN_HANDLED
#include "slider.h"
#include "texture.h"
#include "app.h"
#include "textBox.h"

Slider::Slider(SDL_FRect rect, ColorRgb rectColor, ColorRgb bgColor, float valore, float valMax, float valMin, bool cursorTriangle, Window* win) :
	rect(rect), 
    rectColor(rectColor), 
    bgColor(bgColor),
    valore(valore), valMax(valMax), 
    valMin(valMin), 
    cursorTriangle(cursorTriangle), 
    win(win), 
    textureTriangle(nullptr), 
    cursor(rect.x + 1.0f), 
    percentuale(0.0f),
    intervallo(valMax - valMin), 
    moving(false)
{
    if (cursorTriangle)
    {
        textureTriangle = TEXTURE::getTexture(win->getTextures(), "Triangolo").texture;
    }
}

Slider::~Slider()
{
    textureTriangle = nullptr;
}

void Slider::Draw()
{
    SDL_FRect temp = {
        rect.x, 
        rect.y,
        cursor - rect.x,
        rect.h
    };
    SDL_SetRenderDrawColor(win->getRenderer(), bgColor.r, bgColor.g, bgColor.b, bgColor.a);
    SDL_RenderFillRect(win->getRenderer(), &temp);
    SDL_SetRenderDrawColor(win->getRenderer(), rectColor.r, rectColor.g, rectColor.b, rectColor.a);
    SDL_RenderRect(win->getRenderer(), &rect);

    if (cursorTriangle)
    {
        if (textureTriangle)
        {
            float texSize = rect.w / 22.0f;
            temp = {
                cursor - texSize / 2.0f,
                rect.y + rect.h - texSize,
                texSize,
                texSize
            };
            SDL_RenderTexture(win->getRenderer(), textureTriangle, nullptr, &temp);

            temp.y = rect.y;
            SDL_RenderTextureRotated(win->getRenderer(), textureTriangle, nullptr, &temp,
                180.0, nullptr, SDL_FLIP_NONE);
        }
    }
    else
    {
        temp = {
            cursor - 1,
            rect.y,
            3,
            rect.h
        };
        SDL_SetRenderDrawColor(win->getRenderer(), 0, 0, 0, 255);
        SDL_RenderFillRect(win->getRenderer(), &temp);
    }
}

void Slider::Update(Coord click, float& newVal, bool cursorInMove, bool cursorRealesed)
{
    percentuale = valore / intervallo * 100.0f;
    float cursorPos = rect.x + rect.w / 100.0f * percentuale;
    cursor = (cursorPos < rect.x) ? rect.x : (cursorPos > rect.x + rect.w) ? rect.x + rect.w : cursorPos;

    if (APP::isPixelInRect(click, &rect) && !cursorInMove && !cursorRealesed && !moving)
    {
        moving = true;

        float relativeX = click.x - rect.x;
        if (relativeX < 0) relativeX = 0;
        if (relativeX > rect.w) relativeX = rect.w;

        float ratio = relativeX / rect.w;
        percentuale = ratio * 100.0f;
        valore = ratio * intervallo;
        cursor = rect.x + relativeX;

        newVal = valore;
    }
    else if (cursorRealesed)
    {
        moving = false;
    }
    else if (cursorInMove && moving)
    {
        float relativeX = click.x - rect.x;
        if (relativeX < 0) relativeX = 0;
        if (relativeX > rect.w) relativeX = rect.w;

        float ratio = relativeX / rect.w;
        percentuale = ratio * 100.0f;

        valore = ratio * intervallo;
        cursor = rect.x + relativeX;

        newVal = valore;
    }
}


SDL_FRect Slider::getRect() const { return this->rect; }
void Slider::setRect(SDL_FRect newRect)
{
    this->rect = newRect;
    this->cursor = rect.x + (rect.w * (percentuale / 100.0f));
}

float Slider::getCursorPos() const { return this->cursor; }

ColorRgb Slider::getRectColor() const { return this->rectColor; }
void Slider::setRectColor(ColorRgb color) { this->rectColor = color; }

float& Slider::GetValore() { return valore; }
const float& Slider::GetValore() const { return valore; }
void Slider::SetValore(const float& val) 
{ 
    if (val >= valMin && val <= valMax)
    {
        valore = val;
        cursor = rect.x + rect.w * (val / intervallo);
    }
}


SliderTextbox::SliderTextbox(SDL_FRect rect, ColorRgb rectColor, ColorRgb bgColor, float* valore, float valMax, float valMin, int maxDecimali, bool cursorTriangle, Window* win, VariabiliGlobali& global, float charSize) :
    rect(rect),
    rectColor(rectColor),
    bgColor(bgColor),
    valore(valore),
    win(win),
    global(global),
    textbox(new TextBox({ 0.0f, 0.0f, 0.0f, 0.0f }, TypeTxtBox::NUMBERS, 4, valMin, valMax, maxDecimali, global, win, bgColor, charSize)),
    slider(new Slider({0.0f, 0.0f, 0.0f, 0.0f}, rectColor, bgColor, *valore, valMax, valMin, cursorTriangle, win))
{
    textbox->setText(std::to_string(*valore));

    float ratio = 0.8f;
    float gapPercent = 0.05f;

    float sliderW = rect.w * ratio;
    float sliderH = rect.h * 0.8f;

    SDL_FRect sliderRect = {
        rect.x,
        rect.y + (rect.h - sliderH) / 2.0f,
        sliderW,
        sliderH
    };
    slider->setRect(sliderRect);

    float gap = rect.w * gapPercent;
    float textBoxX = rect.x + sliderW + gap;

    SDL_FRect textBoxRect = {
        textBoxX,
        rect.y,
        (rect.x + rect.w) - textBoxX,
        rect.h
    };
    textbox->setRect(textBoxRect);
}

void SliderTextbox::Draw()
{
    if (slider)
    {
        slider->Draw();
    }
    if (textbox)
    {
        textbox->Draw();
    }
}

void SliderTextbox::Update(Coord click, bool cursorInMove, bool cursorRealesed)
{
    if (slider)
    {
        float newVal = -1.0f;

        slider->Update(click, newVal, cursorInMove, cursorRealesed);

        if (newVal != -1.0f)
        {
            *valore = newVal;
            textbox->setText(std::to_string(newVal));
        }
    }
    if (textbox && cursorRealesed)
    {
        bool update = false;
        textbox->Update(&update);

        if (update)
        {
            float newVal = std::stof(textbox->getText());
            *valore = newVal;
            slider->SetValore(newVal);
        }
    }
}

SDL_FRect& SliderTextbox::GetRect() { return rect; }
const SDL_FRect& SliderTextbox::GetRect() const { return rect; }
void SliderTextbox::SetRect(SDL_FRect newRect) { rect = newRect; }