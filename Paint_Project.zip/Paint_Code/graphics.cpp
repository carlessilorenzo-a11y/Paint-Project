#define SDL_MAIN_HANDLED
#include "graphics.h"
#include "texture.h"
#include "app.h"

namespace GRAPHICS
{
    void Print(const std::string& text, float x, float y, float size, SDL_Renderer* renderer, std::vector<Textures>& textures, float letterSpacing)
    {
        struct fSize
        {
            float w;
            float h;
        };

        fSize textureSize, actualSize;

        for (size_t c = 0; c < text.length(); ++c)
        {
            char ch = text[c];
            std::string temp;
            bool down = (ch == 'p' || ch == 'q' || ch == 'g' || ch == 'y');

            if (ch == ' ')
            {
                x += size;
                continue;
            }
            else if (ch == ':')
            {
                temp = "DUE PUNTI";
            }
            else if (ch == '%')
            {
                temp = "Xcento";
            }
            else
            {
                temp = std::string(1, ch);
            }

            Textures tex = TEXTURE::getTexture(textures, temp);

            if (!SDL_GetTextureSize(tex.texture, &textureSize.w, &textureSize.h))
            {
                SDL_Log("Errore: %s", SDL_GetError());
            }

            float scale = size / textureSize.h;
            actualSize.h = textureSize.h * scale;
            actualSize.w = textureSize.w * scale;

            float yOffset = y;
            if (down) yOffset += actualSize.h / 3.0f;

            SDL_FRect dst = { x, yOffset, actualSize.w, actualSize.h };
            SDL_RenderTexture(renderer, tex.texture, NULL, &dst);

            x += actualSize.w + size * letterSpacing;
        }
    }

    void PrintCentered(const std::string& text, const SDL_FRect* rect, float size, SDL_Renderer* renderer, std::vector<Textures>& textures, float letterSpacing)
    {
        struct fSize
        {
            float w;
            float h;
        };

        fSize textureSize, actualSize;
        float totSize = 0;
        float spaceSpace = 0.8f;

        for (size_t c = 0; c < text.length(); ++c)
        {
            char ch = text[c];
            std::string temp;
            if (ch == ' ')
            {
                totSize += size * spaceSpace;
                continue;
            }
            if (ch == ':') temp = "DUE PUNTI";
            else if (ch == '%') temp = "Xcento";
            else temp = std::string(1, ch);

            Textures tex = TEXTURE::getTexture(textures, temp);

            if (SDL_GetTextureSize(tex.texture, &textureSize.w, &textureSize.h))
            {
                float scale = size / textureSize.h;
                totSize += textureSize.w * scale + size * letterSpacing;
            }
            else SDL_Log("Errore: %s", SDL_GetError());
        }

        totSize -= size * letterSpacing;

        float xOffset = rect->x + rect->w / 2 - totSize / 2;

        for (size_t c = 0; c < text.length(); ++c)
        {
            char ch = text[c];
            std::string temp;
            bool down = (ch == 'p' || ch == 'q' || ch == 'g' || ch == 'y');

            if (ch == ' ')
            {
                xOffset += size * spaceSpace;
                continue;
            }
            if (ch == ':') temp = "DUE PUNTI";
            else if (ch == '%') temp = "Xcento";
            else temp = std::string(1, ch);

            Textures tex = TEXTURE::getTexture(textures, temp);

            if (!SDL_GetTextureSize(tex.texture, &textureSize.w, &textureSize.h))
            {
                SDL_Log("Errore: %s", SDL_GetError());
            }

            float scale = size / textureSize.h;
            actualSize.h = textureSize.h * scale;
            actualSize.w = textureSize.w * scale;

            SDL_FRect textureRect;
            textureRect.x = xOffset;
            textureRect.y = rect->y + rect->h / 2 - actualSize.h / 2;
            if (down) textureRect.y += actualSize.h / 3;
            textureRect.w = actualSize.w;
            textureRect.h = actualSize.h;

            SDL_RenderTexture(renderer, tex.texture, NULL, &textureRect);

            xOffset += actualSize.w + size * letterSpacing;
        }
    }

    ColorRgb getRgbColor(ColorType color, int shade)
    {
        switch (color)
        {
        case ColorType::BLACK:
        {
            switch (shade)
            {
            case 0: return { 0, 0, 0, 255 };
            case 1: return { 20, 20, 20, 255 };
            case 2: return { 40, 40, 40, 255 };
            case 3: return { 60, 60, 60, 255 };
            case 4: return { 80, 80, 80, 255 };
            case 5: return { 100, 100, 100, 255 };
            case 6: return { 120, 120, 120, 255 };
            case 7: return { 140, 140, 140, 255 };
            default: return { 0, 0, 0, 255 };
            }
        }
        break;

        case ColorType::WHITE:
        {
            switch (shade)
            {
            case 0: return { 255, 255, 255, 255 };
            case 1: return { 240, 240, 240, 255 };
            case 2: return { 225, 225, 225, 255 };
            case 3: return { 210, 210, 210, 255 };
            case 4: return { 195, 195, 195, 255 };
            case 5: return { 180, 180, 180, 255 };
            case 6: return { 165, 165, 165, 255 };
            case 7: return { 150, 150, 150, 255 };
            default: return { 255, 255, 255, 255 };
            }
        }
        break;

        case ColorType::RED:
        {
            switch (shade)
            {
            case 0: return { 255, 0, 0, 255 };
            case 1: return { 235, 0, 0, 255 };
            case 2: return { 210, 0, 0, 255 };
            case 3: return { 180, 0, 0, 255 };
            case 4: return { 150, 0, 0, 255 };
            case 5: return { 120, 0, 0, 255 };
            case 6: return { 90, 0, 0, 255 };
            case 7: return { 60, 0, 0, 255 };
            default: return { 255, 0, 0, 255 };
            }
        }
        break;

        case ColorType::GREEN:
        {
            switch (shade)
            {
            case 0: return { 0, 255, 0, 255 };
            case 1: return { 0, 235, 0, 255 };
            case 2: return { 0, 210, 0, 255 };
            case 3: return { 0, 180, 0, 255 };
            case 4: return { 0, 150, 0, 255 };
            case 5: return { 0, 120, 0, 255 };
            case 6: return { 0, 90, 0, 255 };
            case 7: return { 0, 60, 0, 255 };
            default: return { 0, 255, 0, 255 };
            }
        }
        break;

        case ColorType::BLUE:
        {
            switch (shade)
            {
            case 0: return { 0, 0, 255, 255 };
            case 1: return { 0, 0, 235, 255 };
            case 2: return { 0, 0, 210, 255 };
            case 3: return { 0, 0, 180, 255 };
            case 4: return { 0, 0, 150, 255 };
            case 5: return { 0, 0, 120, 255 };
            case 6: return { 0, 0, 90, 255 };
            case 7: return { 0, 0, 60, 255 };
            default: return { 0, 0, 255, 255 };
            }
        }
        break;

        case ColorType::YELLOW:
        {
            switch (shade)
            {
            case 0: return { 255, 255, 0, 255 };
            case 1: return { 235, 235, 0, 255 };
            case 2: return { 210, 210, 0, 255 };
            case 3: return { 180, 180, 0, 255 };
            case 4: return { 150, 150, 0, 255 };
            case 5: return { 120, 120, 0, 255 };
            case 6: return { 90, 90, 0, 255 };
            case 7: return { 60, 60, 0, 255 };
            default: return { 255, 255, 0, 255 };
            }
        }
        break;

        case ColorType::CYAN:
        {
            switch (shade)
            {
            case 0: return { 0, 255, 255, 255 };
            case 1: return { 0, 235, 235, 255 };
            case 2: return { 0, 210, 210, 255 };
            case 3: return { 0, 180, 180, 255 };
            case 4: return { 0, 150, 150, 255 };
            case 5: return { 0, 120, 120, 255 };
            case 6: return { 0, 90, 90, 255 };
            case 7: return { 0, 60, 60, 255 };
            default: return { 0, 255, 255, 255 };
            }
        }
        break;

        case ColorType::MAGENTA:
        {
            switch (shade)
            {
            case 0: return { 255, 0, 255, 255 };
            case 1: return { 235, 0, 235, 255 };
            case 2: return { 210, 0, 210, 255 };
            case 3: return { 180, 0, 180, 255 };
            case 4: return { 150, 0, 150, 255 };
            case 5: return { 120, 0, 120, 255 };
            case 6: return { 90, 0, 90, 255 };
            case 7: return { 60, 0, 60, 255 };
            default: return { 255, 0, 255, 255 };
            }
        }
        break;
        }
        return { 0, 0, 0, 255 };
    }

    std::vector<rectColoredRgb> createCircle(float centerX, float centerY, float radius, ColorRgb fillColor, ColorRgb borderColor)
    {
        std::vector<rectColoredRgb> pixels;

        int minX = static_cast<int>(centerX - radius);
        int maxX = static_cast<int>(centerX + radius);
        int minY = static_cast<int>(centerY - radius);
        int maxY = static_cast<int>(centerY + radius);

        float radiusSquared = radius * radius;
        float borderThickness = 1.5f;
        float innerRadiusSquared = (radius - borderThickness) * (radius - borderThickness);

        for (int y = minY; y <= maxY; ++y)
        {
            for (int x = minX; x <= maxX; ++x)
            {
                float dx = x - centerX;
                float dy = y - centerY;
                float distanceSquared = dx * dx + dy * dy;

                if (distanceSquared <= radiusSquared)
                {
                    rectColoredRgb r;
                    r.rect = { static_cast<float>(x), static_cast<float>(y), 1.0f, 1.0f };

                    if (distanceSquared >= innerRadiusSquared)
                        r.color = borderColor;
                    else
                        r.color = fillColor;

                    pixels.push_back(r);
                }
            }
        }

        return pixels;
    }

    std::vector<rectColoredRgb> createCircleFromMap(float centerX, float centerY, float radius, std::vector<std::vector<ColorRgb>> bgMap)
    {
        std::vector<rectColoredRgb> pixels;

        int height = static_cast<int>(bgMap.size());
        if (height == 0) return pixels;
        int width = static_cast<int>(bgMap[0].size());

        int minX = std::max(0, static_cast<int>(centerX - radius));
        int maxX = std::min(width - 1, static_cast<int>(centerX + radius));
        int minY = std::max(0, static_cast<int>(centerY - radius));
        int maxY = std::min(height - 1, static_cast<int>(centerY + radius));

        float radiusSquared = radius * radius;
        float borderThickness = 1.5f;
        float innerRadiusSquared = (radius - borderThickness) * (radius - borderThickness);

        for (int y = minY; y <= maxY; ++y)
        {
            for (int x = minX; x <= maxX; ++x)
            {
                float dx = x - centerX;
                float dy = y - centerY;
                float distanceSquared = dx * dx + dy * dy;

                if (distanceSquared <= radiusSquared)
                {
                    rectColoredRgb r;
                    r.rect = { static_cast<float>(x), static_cast<float>(y), 1.0f, 1.0f };

                    // controlla i limiti
                    if (y >= 0 && y < height && x >= 0 && x < width)
                    {
                        // Copia dal bgMap (cioè startMap) il colore di sfondo
                        r.color = bgMap[y][x];
                        r.color.a = 255; // <-- aggiungi questa riga
                    }
                    else
                    {
                        r.color = { 0, 0, 0, 0 };
                    }

                    // Mantieni lo stesso concetto di bordo
                    if (distanceSquared >= innerRadiusSquared)
                    {
                        // bordo leggermente più scuro (effetto "contorno" di cancellazione)
                        r.color.a = static_cast<unsigned char>(r.color.a * 0.9f);
                    }

                    pixels.push_back(r);
                }
            }
        }

        return pixels;
    }

    void RenderCircle(SDL_Renderer* renderer, float cx, float cy, float radius, const ColorRgb& color)
    {
        if (!renderer || radius <= 0) return;

        SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

        float x = radius;
        float y = 0;
        int decision = 1 - static_cast<int>(x);

        auto plotCirclePoints = [&](float cx, float cy, float x, float y)
            {
                SDL_RenderPoint(renderer, cx + x, cy + y);
                SDL_RenderPoint(renderer, cx - x, cy + y);
                SDL_RenderPoint(renderer, cx + x, cy - y);
                SDL_RenderPoint(renderer, cx - x, cy - y);
                SDL_RenderPoint(renderer, cx + y, cy + x);
                SDL_RenderPoint(renderer, cx - y, cy + x);
                SDL_RenderPoint(renderer, cx + y, cy - x);
                SDL_RenderPoint(renderer, cx - y, cy - x);
            };

        while (y <= x)
        {
            plotCirclePoints(cx, cy, x, y);
            y++;
            if (decision <= 0)
            {
                decision += 2 * static_cast<int>(y) + 1;
            }
            else
            {
                x--;
                decision += 2 * static_cast<int>(y - x) + 1;
            }
        }
    }

    void RenderRectTratteggiato(SDL_Renderer* renderer, SDL_FRect* rect, ColorRgb color1, ColorRgb color2, float lengthTratto)
    {
        float x = rect->x;
        float y = rect->y;
        float w = rect->w - 1.0f;
        float h = rect->h - 1.0f;

        float distanzaCompiuta = 0.0f;

        Coord currentPoint = { -1.0f, -1.0f };
        Coord lastPoint = { -1.0f, -1.0f };

        ColorRgb currenColor = color2;

        for (int i = 0; i < 4; ++i)
        {
            distanzaCompiuta = 0.0f;
            bool finish = false;

            switch (i)
            {
            case 0: //Alto sinistra - Alto destra
            {
                currentPoint = { x, y };
                lastPoint = currentPoint;
                break;
            }
            case 1: //Alto destra - Basso destra
            {
                currentPoint = { x + w, y };
                lastPoint = currentPoint;
                break;
            }
            case 2: //Basso destra - Basso sinistra
            {
                currentPoint = { x + w, y + h };
                lastPoint = currentPoint;
                break;
            }
            case 3: //Basso sinistra - Alto sinistra
            {
                currentPoint = { x, y + h };
                lastPoint = currentPoint;
                break;
            }
            }

            while (true)
            {
                float size = 0.0f;

                switch (i)
                {
                case 0:
                {
                    if (distanzaCompiuta + lengthTratto > w)
                    {
                        size = w - distanzaCompiuta;
                        finish = true;
                    }
                    else size = lengthTratto;

                    currentPoint = {
                        currentPoint.x += size,
                        currentPoint.y
                    };
                    break;
                }
                case 1:
                {
                    if (distanzaCompiuta + lengthTratto > h)
                    {
                        size = h - distanzaCompiuta;
                        finish = true;
                    }
                    else size = lengthTratto;

                    currentPoint = {
                        currentPoint.x,
                        currentPoint.y += size
                    };
                    break;
                }
                case 2:
                {
                    if (distanzaCompiuta + lengthTratto > w)
                    {
                        size = w - distanzaCompiuta;
                        finish = true;
                    }
                    else size = lengthTratto;

                    currentPoint = {
                        currentPoint.x -= size,
                        currentPoint.y
                    };
                    break;
                }
                case 3:
                {
                    if (distanzaCompiuta + lengthTratto > h)
                    {
                        size = h - distanzaCompiuta;
                        finish = true;
                    }
                    else size = lengthTratto;

                    currentPoint = {
                        currentPoint.x,
                        currentPoint.y -= size
                    };
                    break;
                }
                }

                distanzaCompiuta += lengthTratto;

                currenColor = (currenColor == color1) ? color2 : color1;
                SDL_SetRenderDrawColor(renderer, currenColor.r, currenColor.g, currenColor.b, currenColor.a);
                SDL_RenderLine(renderer, lastPoint.x, lastPoint.y, currentPoint.x, currentPoint.y);

                lastPoint = currentPoint;

                if (finish) break;
            }
        }
    }

    void RenderEllisseInscritta(SDL_Renderer* renderer, SDL_FRect* rect, ColorRgb color)
    {
        float semiasse_a = rect->w / 2.0f;
        float semiasse_b = rect->h / 2.0f;

        Coord centro = {
            rect->x + semiasse_a,
            rect->y + semiasse_b
        };

        Coord last = {
            centro.x + semiasse_a,
            centro.y
        };

        SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
        for (int a = 1; a <= 360; ++a)
        {
            float x = centro.x + semiasse_a * std::cos(APP::fromDegToRad(static_cast<float>(a)));
            float y = centro.y + semiasse_b * std::sin(APP::fromDegToRad(static_cast<float>(a)));

            SDL_RenderLine(renderer, last.x, last.y, x, y);

            last.x = x;
            last.y = y;
        }
    }

    void RenderEllisseInscrittaTratteggiata(SDL_Renderer* renderer, SDL_FRect* rect, ColorRgb color1, ColorRgb color2, float lengthTratto)
    {
        float semiasse_a = rect->w / 2.0f;
        float semiasse_b = rect->h / 2.0f;

        Coord centro = {
            rect->x + semiasse_a,
            rect->y + semiasse_b
        };

        Coord last = {
            centro.x + semiasse_a,
            centro.y
        };

        float distanzaAccumulata = 0.0f;
        ColorRgb color = color1;
        for (int a = 1; a <= 360; ++a)
        {
            float x = centro.x + semiasse_a * std::cos(APP::fromDegToRad(static_cast<float>(a)));
            float y = centro.y + semiasse_b * std::sin(APP::fromDegToRad(static_cast<float>(a)));

            float dx = x - last.x;
            float dy = y - last.y;
            float distanza = std::sqrt(dx * dx + dy * dy);

            distanzaAccumulata += distanza;
            if (distanzaAccumulata >= lengthTratto)
            {
                distanzaAccumulata = 0.0f;
                color = (color == color1) ? color2 : color1;
            }

            SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
            SDL_RenderLine(renderer, last.x, last.y, x, y);

            last.x = x;
            last.y = y;
        }
    }

    std::vector<rectColoredRgb> createEllisseInscritta(SDL_FRect* rect, ColorRgb color)
    {
        std::vector<rectColoredRgb> ellisse;

        float a = rect->w / 2.0f;
        float b = rect->h / 2.0f;

        float x0 = rect->x + a;
        float y0 = rect->y + b;

        float a2 = a * a;
        float b2 = b * b;

        for (int y = static_cast<int>(rect->y); y < static_cast<int>(rect->y + rect->h); ++y)
        {
            for (int x = static_cast<int>(rect->x); x < static_cast<int>(rect->x + rect->w); ++x)
            {
                float dx = static_cast<float>(x) - x0;
                float dy = static_cast<float>(y) - y0;

                if ((dx * dx) / a2 + (dy * dy) / b2 <= 1.0f)
                {
                    ellisse.push_back({ static_cast<float>(x), static_cast<float>(y), 1, 1, color });
                }
            }
        }

        return ellisse;
    }

    void RenderPointsTratteggiati(SDL_Renderer* renderer, std::vector<SDL_FPoint> points, ColorRgb color1, ColorRgb color2, float lengthTratto)
    {
        float distanzaAccumulata = 0.0f;
        ColorRgb color = color1;

        for (size_t i = 0; i < points.size(); ++i)
        {
            size_t j = (i == 0) ? points.size() - 1 : i - 1;
            SDL_FPoint A = points[j];
            SDL_FPoint B = points[i];

            float dx = B.x - A.x;
            float dy = B.y - A.y;
            float distanzaSegmento = std::sqrt(dx * dx + dy * dy);

            if (distanzaSegmento == 0) continue;

            float ux = dx / distanzaSegmento;
            float uy = dy / distanzaSegmento;

            float percorsoSulSegmento = 0.0f;

            while (percorsoSulSegmento < distanzaSegmento)
            {
                float spazioLiberoNelTratto = lengthTratto - distanzaAccumulata;
                float spazioRimanenteSulSegmento = distanzaSegmento - percorsoSulSegmento;

                float daDisegnare = std::min(spazioLiberoNelTratto, spazioRimanenteSulSegmento);

                SDL_FPoint start = { A.x + percorsoSulSegmento * ux, A.y + percorsoSulSegmento * uy };
                percorsoSulSegmento += daDisegnare;
                SDL_FPoint end = { A.x + percorsoSulSegmento * ux, A.y + percorsoSulSegmento * uy };

                SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
                SDL_RenderLine(renderer, start.x, start.y, end.x, end.y);

                distanzaAccumulata += daDisegnare;

                if (distanzaAccumulata >= lengthTratto)
                {
                    color = (color == color1) ? color2 : color1;
                    distanzaAccumulata = 0.0f;
                }
            }
        }
    }

    void RenderFillCircle(SDL_Renderer* renderer, float cx, float cy, float radius, const ColorRgb& color)
    {
        SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
        for (int y = 0; y < radius * 2.0f; ++y)
        {
            for (int x = 0; x < radius * 2.0f; ++x)
            {
                Coord point = {
                    cx - radius / 2.0f + x,
                    cy - radius / 2.0f + y
                };

                float dx = point.x - cx;
                float dy = point.y - cy;

                float distanza = std::sqrt(dx * dx + dy * dy);

                if (distanza <= radius)
                {
                    SDL_RenderPoint(renderer, point.x, point.y);
                }
            }
        }
    }

    void RenderAreaTratteggiata(SDL_Renderer* renderer, const std::unordered_set<Coord>& area,
        ColorRgb color1, ColorRgb color2,
        const Coord mapOffset, const float zoom,
        int mapWidth, int mapHeight) // Aggiunti i limiti della mappa
    {
        Coord offset[4] = {
            { 1.0f, 0.0f },  // 0: Destra
            { 0.0f, 1.0f },  // 1: Basso
            { -1.0f, 0.0f }, // 2: Sinistra
            { 0.0f, -1.0f }  // 3: Alto
        };

        float lengthTratto = 5.0f;

        for (const auto& pixel : area)
        {
            for (int o = 0; o < 4; ++o)
            {
                int nx = (int)pixel.x + (int)offset[o].x;
                int ny = (int)pixel.y + (int)offset[o].y;

                // CONDIZIONE AGGIORNATA:
                // Disegna il bordo se:
                // 1. Il vicino è fuori dai limiti della mappa (nx < 0, ny < 0, ecc.)
                // 2. OPPURE il vicino non è nell'area selezionata
                bool fuoriMappa = (nx < 0 || nx >= mapWidth || ny < 0 || ny >= mapHeight);

                if (fuoriMappa || !area.count({ (float)nx, (float)ny }))
                {
                    float sx = (float)pixel.x * zoom + mapOffset.x;
                    float sy = (float)pixel.y * zoom + mapOffset.y;

                    float ax, ay, bx, by, distanzaIniziale;

                    switch (o)
                    {
                    case 3: // ALTO
                        ax = sx; ay = sy; bx = sx + zoom; by = sy;
                        distanzaIniziale = (float)pixel.x * zoom;
                        break;
                    case 0: // DESTRA
                        ax = sx + zoom; ay = sy; bx = sx + zoom; by = sy + zoom;
                        distanzaIniziale = (float)pixel.y * zoom;
                        break;
                    case 1: // BASSO
                        ax = sx + zoom; ay = sy + zoom; bx = sx; by = sy + zoom;
                        distanzaIniziale = (float)pixel.x * zoom;
                        break;
                    case 2: // SINISTRA
                        ax = sx; ay = sy + zoom; bx = sx; by = sy;
                        distanzaIniziale = (float)pixel.y * zoom;
                        break;
                    }

                    float percorso = 0.0f;
                    while (percorso < zoom)
                    {
                        float distCorrente = distanzaIniziale + percorso;
                        float restoNelTratto = lengthTratto - fmod(distCorrente, lengthTratto);
                        float daDisegnare = std::min(restoNelTratto, zoom - percorso);

                        if (fmod(distCorrente, lengthTratto * 2.0f) < lengthTratto)
                            SDL_SetRenderDrawColor(renderer, color1.r, color1.g, color1.b, color1.a);
                        else
                            SDL_SetRenderDrawColor(renderer, color2.r, color2.g, color2.b, color2.a);

                        float tStart = percorso / zoom;
                        float tEnd = (percorso + daDisegnare) / zoom;

                        SDL_RenderLine(renderer,
                            ax + (bx - ax) * tStart, ay + (by - ay) * tStart,
                            ax + (bx - ax) * tEnd, ay + (by - ay) * tEnd
                        );

                        percorso += daDisegnare;
                    }
                }
            }
        }
    }

    void fillMapWithSelectedArea(VariabiliGlobali& global, ColorRgb c)
    {
        Win& win = global.win;
        Level& currentLvl = win.Main.level()[global.currentLevel];

        if (win.Main.level().IsOpen())
        {
            std::vector<std::vector<ColorRgb>>& map = currentLvl.map;

            if (win.Main.GetSelections()->IsSelected())
            {
                switch (win.Main.GetSelections()->GetLastType())
                {
                case Tools::SELEZIONE_RETTANGOLARE:
                {
                    SDL_FRect& selection = win.Main.GetSelections()->GetRect();
                    SDL_FRect r = {
                       (selection.x - currentLvl.moveCoord.x) / win.Main.level().GetZoom(),
                       (selection.y - currentLvl.moveCoord.y) / win.Main.level().GetZoom(),
                       selection.w / win.Main.level().GetZoom(),
                       selection.h / win.Main.level().GetZoom()
                    };

                    for (int y = 0; y < static_cast<int>(r.h); ++y)
                    {
                        for (int x = 0; x < static_cast<int>(r.w); ++x)
                        {
                            map[static_cast<size_t>(y + r.y)][static_cast<size_t>(x + r.x)] = { c.r, c.g, c.b, c.a };
                        }
                    }
                    break;
                }
                case Tools::SELEZIONE_CIRCOLARE:
                {
                    SDL_FRect& selection = win.Main.GetSelections()->GetRect();
                    SDL_FRect r = {
                       (selection.x - currentLvl.moveCoord.x) / win.Main.level().GetZoom(),
                       (selection.y - currentLvl.moveCoord.y) / win.Main.level().GetZoom(),
                       selection.w / win.Main.level().GetZoom(),
                       selection.h / win.Main.level().GetZoom()
                    };

                    for (int y = 0; y < static_cast<int>(r.h); ++y)
                    {
                        for (int x = 0; x < static_cast<int>(r.w); ++x)
                        {
                            if (APP::isPixelInEllisse({ static_cast<float>(x + r.x), static_cast<float>(y + r.y) }, &r))
                            {
                                map[static_cast<size_t>(y + r.y)][static_cast<size_t>(x + r.x)] = { c.r, c.g, c.b, c.a };
                            }
                        }
                    }
                    break;
                }
                case Tools::SELEZIONE_LAZO:
                {
                    std::unordered_set<Coord> area = win.Main.GetSelections()->GetArea();
                    for (const auto& pixel : area)
                    {
                        map[static_cast<size_t>(pixel.y)][static_cast<size_t>(pixel.x)] = { c.r, c.g, c.b, c.a };
                    }
                    break;
                }
                case Tools::SELEZIONE_COLORE:
                    std::unordered_set<Coord> area = win.Main.GetSelections()->GetArea();
                    for (const auto& pixel : area)
                    {
                        map[static_cast<size_t>(pixel.y)][static_cast<size_t>(pixel.x)] = { c.r, c.g, c.b, c.a };
                    }
                    break;
                }
            }
            else
            {
                for (auto& y : map)
                {
                    for (auto& pixel : y)
                    {
                        pixel = { c.r, c.g, c.b, c.a };
                    }
                }
            }
            currentLvl.needsUpdate = true;
        }
    }
}