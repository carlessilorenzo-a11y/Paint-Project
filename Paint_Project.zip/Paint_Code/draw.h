#pragma once
#include <vector>
#include <queue>

#include "basicStruct.h"

struct VariabiliGlobali;

class Project
{
protected:
    VariabiliGlobali& global;
    float zoom;
    bool alphaLevel;
    bool isOpen;
    bool baseLevelDeleted;
    std::string currentfile;
    std::string currentfileProject;
    Coord alphaGridCoord;
    Size basicSize;
    Size limitSize;
    Level finalLevel;
    std::vector<Level> level;
    SDL_Texture* alphaGrid;

public:
    Level& operator[](size_t pos);
    const Level& operator[](size_t pos) const;

    Project(VariabiliGlobali& global);

    ~Project();

    void Draw();
    void Update();
    void UpdateCanvas();
    void UpdateAlphaGrid();
    void moveDraw(bool tool);


    // zoom
    float GetZoom() const;
    float& GetZoom();
    void SetZoom(float newZoom);

    // alphaLevel
    bool IsAlphaLevel() const;
    bool& GetAlphaLevel();
    void SetAlphaLevel(bool newAlphaLevel);

    // isOpen
    bool IsOpen() const;
    bool& GetOpen();
    void SetOpen(bool newOpen);

    // baseLevelDeleted
    bool IsBaseLevelDeleted() const;
    bool& GetBaseLevelDeleted();
    void SetBaseLevelDeleted(bool newBaseLevelDeleted);

    // currentfile
    const std::string& GetCurrentfile() const;
    std::string& GetCurrentfile();
    void SetCurrentfile(const std::string& newCurrentfile);

    // currentfileProject
    const std::string& GetCurrentfileProject() const;
    std::string& GetCurrentfileProject();
    void SetCurrentfileProject(const std::string& newCurrentfile);

    const Coord& GetAlphaGridCoord() const;
    Coord& GetAlphaGridCoord();
    void SetAlphaGridCoord(const Coord& newAlphaGridCoord);

    // basicSize
    const Size& GetBasicSize() const;
    Size& GetBasicSize();
    void SetBasicSize(const Size& newSize);

    // limitSize
    const Size& GetLimitSize() const;
    Size& GetLimitSize();
    void SetLimitSize(const Size& newLimitSize);

    // finalLevel 
    Level& GetFinalLevel();
    const Level& GetFinalLevel() const;
    void SetFinalLevel(const Level& newRect);

    // level
    const std::vector<Level>& GetLevel() const;
    std::vector<Level>& GetLevel();
    void SetLevel(const std::vector<Level>& newLevel);

    // alphaGrid
    SDL_Texture* GetAlphaGrid() const;
    SDL_Texture*& GetAlphaGrid();
    void SetAlphaGrid(SDL_Texture* newAlphaGrid);
};