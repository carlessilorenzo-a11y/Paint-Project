#define SDL_MAIN_HANDLED
#include "saveWin.h"
#include "textBox.h"
#include "salvataggio.h"
#include "texture.h"
#include "graphics.h"

Save::Save(VariabiliGlobali& global) :
    global(global),
    error(false),
    project(false),
    back(),
    next(),
    textbox(nullptr),
    fileType({}) {
}

void Save::Update()
{
    if ((global.click.x >= back.rect.x && global.click.x <= back.rect.x + back.rect.w) &&
        (global.click.y >= back.rect.y && global.click.y <= back.rect.y + back.rect.h) && window)
    {
        Destroy();
        global.click = { -1, -1 };
        return;
    }
    else if ((global.click.x >= next.rect.x && global.click.x <= next.rect.x + next.rect.w) &&
        (global.click.y >= next.rect.y && global.click.y <= next.rect.y + next.rect.h) && window)
    {
        if (textbox->getText().empty())
        {
            if (textbox->getText().empty())
            {
                textbox->setERROR(true);
            }
            else
            {
                textbox->setERROR(false);
            }
        }

        FileRect selected;

        if (!project)
        {
            for (auto& obj : fileType)
            {
                if (obj.open)
                {
                    error = false;
                    selected = obj;
                    break;
                }
                else if (!obj.open)
                {
                    error = true;
                }
            }
        }

        if (!textbox->getERROR() && !error)
        {
            if (!project)
            {
                std::vector<std::vector<ColorRgb>> map = TEXTURE::getLevelsMap(global);
                if (SALVATAGGIO::SaveMapToImage(map, global.directoryDraw + textbox->getText() + '.' + selected.text, ((selected.type == FileType::PNG) ? true : false)))
                {
                    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "OPERAZIONE COMPLEATA", "Disegno salvato con successo", NULL);
                    global.win.Main.level().GetCurrentfile() = textbox->getText();
                }
                else
                {
                    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ERROR", "Errore nel savataggio del disegno", NULL);
                }
            }
            else
            {
                std::string filename = global.directoryProjects + textbox->getText() + ".pnt";
                SALVATAGGIO::saveProjectData(filename, global);
            }

            Destroy();
            global.click = { -1, -1 };
            return;
        }
    }

    if (!project)
    {
        for (auto& obj : fileType)
        {
            if ((global.click.x >= obj.rect.x && global.click.x <= obj.rect.x + obj.rect.w) &&
                (global.click.y >= obj.rect.y && global.click.y <= obj.rect.y + obj.rect.h))
            {
                if (!obj.open)
                {
                    for (auto& temp : fileType)
                    {
                        if (temp.open)
                        {
                            temp.open = false;
                        }
                    }
                    obj.open = true;
                    break;
                }
                else
                {
                    obj.open = false;
                    break;
                }
            }
        }
    }

    if (textbox)
    {
        textbox->Update();
    }
}

void Save::Draw()
{
    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderClear(renderer);

    GRAPHICS::Print("Inserisci il nome del file:", static_cast<float>(size.h / 13), static_cast<float>(size.h / 13), 10.0f, renderer, textures);
    GRAPHICS::Print("Scegli il tipo di file:", textbox->getRect().x, textbox->getRect().y + textbox->getRect().h * 2.0f, 10.0f, renderer, textures);

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderFillRect(renderer, &back.rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &back.rect);
    GRAPHICS::PrintCentered(back.text, &back.rect, 8, renderer, textures);

    SDL_SetRenderDrawColor(renderer, 64, 64, 64, 255);
    SDL_RenderFillRect(renderer, &next.rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderRect(renderer, &next.rect);
    GRAPHICS::PrintCentered(next.text, &next.rect, 8, renderer, textures);

    if (!project)
    {
        for (const auto& obj : fileType)
        {
            SDL_SetRenderDrawColor(renderer, ((error) ? 255 : 0), 0, 0, 255);
            SDL_RenderRect(renderer, &obj.rect);
            if (obj.open)
            {
                SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
                SDL_FRect temp = {
                    obj.rect.x + 1,
                    obj.rect.y + 1,
                    obj.rect.w - 2,
                    obj.rect.h - 2
                };
                SDL_RenderFillRect(renderer, &temp);
            }
            GRAPHICS::Print(obj.text, obj.rect.x + obj.rect.w * 1.5f, obj.rect.y, 10.0f, renderer, textures);
        }
    }

    if (textbox)
    {
        textbox->Draw();
    }
}

// error (Get/Set)
bool Save::HasError() const { return error; }
void Save::SetError(bool hasError) { error = hasError; }

// project (Get/Set)
bool Save::IsProject() const { return project; }
void Save::SetProject(bool newProject) { project = newProject; }

// back (Get/Set)
rectText& Save::GetBack() { return back; }
const rectText& Save::GetBack() const { return back; }
void Save::SetBack(const rectText& newBack) { back = newBack; }

// next (Get/Set)
rectText& Save::GetNext() { return next; }
const rectText& Save::GetNext() const { return next; }
void Save::SetNext(const rectText& newNext) { next = newNext; }

// textbox (Get/Set)
TextBox* Save::GetTextbox() { return textbox; }
const TextBox* Save::GetTextbox() const { return textbox; }
void Save::SetTextbox(TextBox* newTextbox) { textbox = newTextbox; }

// fileType (std::vector<FileRect>)
std::vector<FileRect>& Save::GetFileType() { return fileType; }
const std::vector<FileRect>& Save::GetFileType() const { return fileType; }
void Save::SetFileType(const std::vector<FileRect>& newFileType) { fileType = newFileType; }