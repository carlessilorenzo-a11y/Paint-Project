#define SDL_MAIN_HANDLED
#include "app.h"
#include "set.h"

#include <iostream>

namespace APP
{
    bool isMainWindowFocus(VariabiliGlobali& global)
    {
        if (!global.win.setNew.isOpen() &&
            !global.win.save.isOpen() &&
            !global.win.color.isOpen() &&
            !global.win.load.isOpen())
        {
            return true;
        }
        return false;
    }

    size_t countFileLines(const fs::path& filePath)
    {
        std::ifstream file(filePath);
        if (!file.is_open()) return 0;

        size_t lines = 0;
        std::string line;
        while (std::getline(file, line))
            ++lines;

        return lines;
    }

    size_t countProjectLines()
    {
        fs::path projectPath = fs::current_path();
        size_t total = 0;

        for (auto& entry : fs::recursive_directory_iterator(projectPath))
        {
            if (!entry.is_regular_file()) continue;

            std::string ext = entry.path().extension().string();
            if (ext == ".cpp" || ext == ".h" || ext == ".hpp" ||
                ext == ".c" || ext == ".cc" || ext == ".cxx")
            {
                total += countFileLines(entry.path());
            }
        }

        return total;
    }

    float GetTextWidth(const std::string& text, float size, std::vector<Textures>& textures, float letterSpacing)
    {
        struct fSize
        {
            float w;
            float h;
        };

        fSize textureSize;
        float totWidth = 0.0f;
        float spaceSpace = 0.8f;

        for (size_t c = 0; c < text.length(); ++c)
        {
            char ch = text[c];
            std::string temp;

            if (ch == ' ')
            {
                totWidth += size * spaceSpace;
                continue;
            }
            else temp = std::string(1, ch);

            for (auto& name : textures)
            {
                if (name.name == temp && name.texture)
                {
                    if (SDL_GetTextureSize(name.texture, &textureSize.w, &textureSize.h))
                    {
                        float scale = size / textureSize.h;
                        totWidth += textureSize.w * scale + size * letterSpacing;
                    }
                    else
                    {
                        SDL_Log("Errore: %s", SDL_GetError());
                    }
                    break;
                }
            }
        }

        if (!text.empty()) totWidth -= size * letterSpacing;

        return totWidth;
    }

    std::vector<std::string> listaFileCartella(const std::string& cartella)
    {
        std::vector<std::string> risultati;
        const std::string path = "C:/Users/carle/OneDrive/Desktop/Programmazione/Paint/Paint" + cartella;

        fs::path percorsoCompleto = path;

        try
        {
            for (const auto& entry : fs::directory_iterator(percorsoCompleto))
            {
                if (fs::is_regular_file(entry.status()))
                {
                    risultati.push_back(entry.path().filename().string());
                }
            }
        }
        catch (const fs::filesystem_error& e)
        {
            std::cerr << "Errore: " << e.what() << "\n";
        }

        return risultati;
    }

    std::string toLower(std::string s)
    {
        for (int i = 0; i < s.size(); ++i)
        {
            if (s[i] >= 'A' && s[i] <= 'Z')
            {
                s[i] = s[i] + ('a' - 'A');
            }
        }
        return s;
    }

    bool isPixelInRect(Coord coord, SDL_FRect* rect)
    {
        return (coord.x >= rect->x && coord.x <= rect->x + rect->w) &&
            (coord.y >= rect->y && coord.y <= rect->y + rect->h);
    }

    void Log(std::string text)
    {
        static int count = 0;

        if (count == 0)
        {
            SDL_Log(text.c_str());
            count++;
        }
    }

    int messageBoxYesNo(std::string title, std::string msg)
    {
        // Definizione dei pulsanti
        const SDL_MessageBoxButtonData buttons[] = {
            { SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT, 1, "Si" }, // ID 1
            { SDL_MESSAGEBOX_BUTTON_ESCAPEKEY_DEFAULT, 0, "No" }  // ID 0
        };

        const SDL_MessageBoxData data = {
            SDL_MESSAGEBOX_INFORMATION,    // Icona (punto di domanda)
            NULL,                          // Finestra genitore (NULL = centro schermo)
            title.c_str(),                 // Titolo
            msg.c_str(),                   // Messaggio
            SDL_arraysize(buttons),        // Numero di pulsanti (2)
            buttons,                       // L'array creato sopra
            NULL                           // Schema colori (default)
        };

        int buttonid;
        if (!SDL_ShowMessageBox(&data, &buttonid))
        {
            return -1;
        }

        return buttonid;
    }

    void applyZoom(VariabiliGlobali& global, SDL_Event& event, float zoomFactor)
    {
        SDL_FRect pos = {
            static_cast<float>(global.win.Main.getSize().w - global.win.Main.level().GetBasicSize().w) / 2.0f,
            static_cast<float>(global.win.Main.getSize().h - global.win.Main.level().GetBasicSize().h) / 2.0f,
            static_cast<float>(global.win.Main.level().GetBasicSize().w),
            static_cast<float>(global.win.Main.level().GetBasicSize().h)
        };

        if ((global.cursorPosition.x >= pos.x && global.cursorPosition.x <= pos.x + pos.w) &&
            (global.cursorPosition.y >= pos.y && global.cursorPosition.y <= pos.y + pos.h))
        {
            float relativeMouseX = global.cursorPosition.x - pos.x;
            float relativeMouseY = global.cursorPosition.y - pos.y;
            float oldZoom = global.win.Main.level().GetZoom();

            // nuovo fattore di zoom
            if (event.wheel.y > 0) global.win.Main.level().GetZoom() *= zoomFactor;
            else if (event.wheel.y < 0) global.win.Main.level().GetZoom() /= zoomFactor;

            float newZoom = global.win.Main.level().GetZoom();

            auto updatePos = [&](float& coord, float mousePos)
                {
                    float pivot = (mousePos - coord) / oldZoom;
                    coord = mousePos - pivot * newZoom;
                };

            auto updateSize = [&](float& dim, float originalDim) 
                {
                    dim = originalDim * newZoom;
                };

            updatePos(global.win.Main.level().GetAlphaGridCoord().x, relativeMouseX);
            updatePos(global.win.Main.level().GetAlphaGridCoord().y, relativeMouseY);

            for (size_t i = 0; i < global.win.Main.level().GetLevel().size(); ++i)
            {
                auto& lvl = global.win.Main.level()[i];

                updateSize(lvl.zoomSize.w, lvl.size.w);
                updateSize(lvl.zoomSize.h, lvl.size.h);

                updatePos(lvl.zoomSize.x, relativeMouseX);
                updatePos(lvl.zoomSize.y, relativeMouseY);
                updatePos(lvl.moveCoord.x, relativeMouseX);
                updatePos(lvl.moveCoord.y, relativeMouseY);
            }

            if (global.win.Main.level().IsBaseLevelDeleted())
            {
                Level& finalLvl = global.win.Main.level().GetFinalLevel();
                updateSize(finalLvl.zoomSize.w, finalLvl.size.w);
                updateSize(finalLvl.zoomSize.h, finalLvl.size.h);

                updatePos(finalLvl.zoomSize.x, relativeMouseX);
                updatePos(finalLvl.zoomSize.y, relativeMouseY);
                updatePos(finalLvl.moveCoord.x, relativeMouseX);
                updatePos(finalLvl.moveCoord.y, relativeMouseY);
            }

            Selections* selection = global.win.Main.GetSelections();
            if (selection)
            {
                Tools type = selection->GetLastType();

                if (selection->IsSelected())
                {
                    updatePos(selection->GetRect().x, relativeMouseX);
                    updatePos(selection->GetRect().y, relativeMouseY);
                    selection->GetRect().w = (selection->GetRect().w / oldZoom) * newZoom;
                    selection->GetRect().h = (selection->GetRect().h / oldZoom) * newZoom;
                }

                if(type == Tools::SELEZIONE_RETTANGOLARE || 
                    type == Tools::SELEZIONE_CIRCOLARE || 
                    type == Tools::SELEZIONE_LAZO)
                {
                    updatePos(selection->GetStartCoord().x, relativeMouseX);
                    updatePos(selection->GetStartCoord().y, relativeMouseY);
                }

                if (type == Tools::SELEZIONE_RETTANGOLARE ||
                    type == Tools::SELEZIONE_CIRCOLARE)
                {
                    updatePos(selection->GetFinalCoord().x, relativeMouseX);
                    updatePos(selection->GetFinalCoord().y, relativeMouseY);

                    for (auto& sRect : selection->GetSettingRect())
                    {
                        updatePos(sRect.x, relativeMouseX);
                        updatePos(sRect.y, relativeMouseY);
                        sRect.w = (sRect.w / oldZoom) * newZoom;
                        sRect.h = (sRect.h / oldZoom) * newZoom;
                    }
                }

                if (type == Tools::SELEZIONE_LAZO)
                {
                    std::vector<SDL_FPoint>& preparationFrame = selection->GetPreparationLazoCoord();
                    for (auto& pixel : preparationFrame)
                    {
                        updatePos(pixel.x, relativeMouseX);
                        updatePos(pixel.y, relativeMouseY);
                    }

                    if (!selection->IsSelected())
                    {
                        std::vector<Coord>& cerchi = selection->GetLazoMovingPoints();
                        for (auto& pixel : cerchi)
                        {
                            updatePos(pixel.x, relativeMouseX);
                            updatePos(pixel.y, relativeMouseY);
                        }
                    }
                    else
                    {
                        std::vector<SDL_FPoint>&  frame = selection->GetLazoCoord();
                        for (auto& pixel : frame)
                        {
                            updatePos(pixel.x, relativeMouseX);
                            updatePos(pixel.y, relativeMouseY);
                        }
                    }
                }

                if (type == Tools::SELEZIONE_COLORE)
                {
                    SDL_DestroyTexture(selection->getTexture());
                    selection->getTexture() = selection->createEdgeAreaTexture();
                }
            }
        }
    }

    float fromDegToRad(float degrees)
    {
        return degrees * (static_cast<float>(M_PI) / 180.0f);
    }

    float fromRadToDeg(float radians)
    {
        return radians * (180.0f / static_cast<float>(M_PI));
    }

    bool isPixelInEllisse(Coord pixel, SDL_FRect* ellisse)
    {
        float a = ellisse->w / 2.0f;
        float b = ellisse->h / 2.0f;

        float x0 = ellisse->x + a;
        float y0 = ellisse->y + b;

        float a2 = a * a;
        float b2 = b * b;

        float dx = static_cast<float>(pixel.x) - x0;
        float dy = static_cast<float>(pixel.y) - y0;

        if ((dx * dx) / (a * a) + (dy * dy) / (b * b) <= 1.0f)
            return true;

        return false;
    }

    bool isPixelInCircle(Coord coord, Coord center, float radius)
    {
        float dx = center.x - coord.x;
        float dy = center.y - coord.y;

        float distanza = std::sqrt(dx * dx + dy * dy);

        return distanza < radius;
    }

    void createNewLevelFromSelection(VariabiliGlobali& global)
    {
        Level newLevel;

        size_t newPos = global.win.Main.level().GetLevel().size();
        size_t lastPos = global.currentLevel;

        std::vector<std::vector<ColorRgb>>& map = global.win.Main.level()[lastPos].map;
        Selections* selections = global.win.Main.GetSelections();
        MainWin& win = global.win.Main;
        float zoom = win.level().GetZoom();

        newLevel.name = "Livello " + std::to_string(newPos);

        std::unordered_set<Coord> area = selections->GetArea();
        SDL_FRect& rect = selections->GetRect();
        SDL_FRect r = {
            (rect.x - win.level()[lastPos].moveCoord.x) / zoom,
            (rect.y - win.level()[lastPos].moveCoord.y) / zoom,
            rect.w / zoom,
            rect.h / zoom
        };

        newLevel.moveCoord = {
            rect.x,
            rect.y
        };
        newLevel.zoomSize = rect;
        newLevel.size = r;

        if (newLevel.size.w < 1.0f || newLevel.size.h < 1.0f) 
        {
            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "Errore", "Selezione troppo piccola!", nullptr);
            return;
        }

        auto isInSelection = [&](Coord pixel) -> bool
            {
                switch (selections->GetLastType())
                {
                case Tools::SELEZIONE_RETTANGOLARE:
                {
                    Coord screenCoord = {
                        pixel.x * zoom + newLevel.moveCoord.x,
                        pixel.y * zoom + newLevel.moveCoord.y
                    };
                    return isPixelInRect(screenCoord, &rect);
                }
                case Tools::SELEZIONE_CIRCOLARE:
                {
                    Coord screenCoord = {
                        pixel.x * zoom + newLevel.moveCoord.x,
                        pixel.y * zoom + newLevel.moveCoord.y
                    };
                    return isPixelInEllisse(screenCoord, &rect);
                }
                case Tools::SELEZIONE_LAZO:
                case Tools::SELEZIONE_COLORE:
                {
                    Coord globalMapCoord = {
                        std::floor(pixel.x + r.x),
                        std::floor(pixel.y + r.y)
                    };

                    return area.count(globalMapCoord);
                }
                }
                return false;
            };

        for (int y = 0; y < static_cast<int>(r.h); ++y)
        {
            newLevel.map.push_back({});
            for (int x = 0; x < static_cast<int>(r.w); ++x)
            {
                ColorRgb pixel = {};

                if (isInSelection({static_cast<float>(x), static_cast<float>(y)}))
                {
                    pixel = map[static_cast<size_t>(y + r.y)][static_cast<size_t>(x + r.x)];
                }
                else
                {
                    pixel = { 0, 0, 0, 0 };
                }

                newLevel.map[y].push_back(pixel);
            }
        }
        newLevel.startMap = newLevel.map;

        GRAPHICS::fillMapWithSelectedArea(global, { 0, 0, 0, 0 });

        win.level()[lastPos].needsUpdate = true;

        win.level().UpdateCanvas();
        win.level().Draw();

        newLevel.opacity = win.level()[lastPos].opacity;
        newLevel.bgColor = win.level()[lastPos].bgColor;

        APP::updateCronology(global);

        newLevel.needsUpdate = true;

        global.currentLevel = newPos;

        win.level().GetLevel().push_back(std::move(newLevel));

        selections->GetLastType() = Tools::NOTHING;
        selections->IsSelected() = false;

        SET::menuTools(global);
        SET::levelMenu(global);

        win.level()[newPos].needsUpdate = true;
    }

    bool isPixelInDrawAndBasic(Coord pixel, VariabiliGlobali& global)
    {
        Size basicSize = global.win.Main.level().GetBasicSize();
        Size screenSize = global.win.Main.getSize();

        SDL_FRect screenLimit = {
            (screenSize.w - basicSize.w) / 2.0f,
            (screenSize.h - basicSize.h) / 2.0f,
            static_cast<float>(basicSize.w),
            static_cast<float>(basicSize.h)
        };

        SDL_FRect drawRect = {
            global.win.Main.level()[global.currentLevel].moveCoord.x,
            global.win.Main.level()[global.currentLevel].moveCoord.y,
            global.win.Main.level()[global.currentLevel].zoomSize.w,
            global.win.Main.level()[global.currentLevel].zoomSize.h 
        };

        return isPixelInRect(pixel, &screenLimit) && isPixelInRect(pixel, &drawRect);
    }

    void copy(VariabiliGlobali& global)
    {
        if (!global.win.Main.level().IsOpen()) return;

        Level& level = global.win.Main.level()[global.currentLevel];
        float zoom = global.win.Main.level().GetZoom();
        std::vector<std::vector<ColorRgb>> map;

        Selections* selection = global.win.Main.GetSelections();

        SDL_FRect rect;
        if (selection->IsSelected())
        {
            rect = selection->GetRect();
        }
        else
        {
            rect = {
                level.moveCoord.x,
                level.moveCoord.y,
                level.zoomSize.w,
                level.zoomSize.h
            };
        }

        rect = {
            (rect.x - level.moveCoord.x) / zoom,
            (rect.y - level.moveCoord.y) / zoom,
            rect.w / zoom,
            rect.h / zoom
        };

        for (int y = 0; y < static_cast<int>(rect.h); ++y)
        {
            map.push_back({});
            for (int x = 0; x < static_cast<int>(rect.w); ++x)
            {
                Coord mapCoord = { static_cast<float>(rect.x + x), static_cast<float>(rect.y + y) };
                bool inSelection = false;

                if (selection->IsSelected())
                {
                    switch (selection->GetLastType())
                    {
                    case Tools::SELEZIONE_RETTANGOLARE:
                    {
                        inSelection = true;
                        break;
                    }
                    case Tools::SELEZIONE_CIRCOLARE:
                    {
                        inSelection = APP::isPixelInEllisse(mapCoord, &rect);
                        break;
                    }
                    case Tools::SELEZIONE_LAZO:
                    case Tools::SELEZIONE_COLORE:
                    {
                        inSelection = selection->IsPixelInArea(mapCoord);
                        break;
                    }
                    }
                }
                else
                {
                    inSelection = true;
                }

                ColorRgb color;
                if (inSelection)
                {
                    color = level.map[static_cast<size_t>(mapCoord.y)][static_cast<size_t>(mapCoord.x)];
                }
                else
                {
                    color = { 0, 0, 0, 0 };
                }

                map[y].push_back(color);
            }
        }

        global.copy.name = "Copy " + level.name;
        global.copy.map = map;
        global.copy.rect = rect;
        global.copy.opacity = level.opacity;
    }

    void paste(VariabiliGlobali& global, bool isPlace)
    {
        if (!global.win.Main.level().IsOpen()) return;

        Level newLevel;

        size_t newPos = global.win.Main.level().GetLevel().size();
        size_t lastPos = global.currentLevel;

        std::vector<std::vector<ColorRgb>>& map = global.copy.map;
        MainWin& win = global.win.Main;
        float zoom = win.level().GetZoom();

        newLevel.name = global.copy.name;

        SDL_FRect rect = {
            global.copy.rect.x * zoom + global.win.Main.level()[lastPos].moveCoord.x,
            global.copy.rect.y * zoom + global.win.Main.level()[lastPos].moveCoord.y,
            global.copy.rect.w * zoom,
            global.copy.rect.h * zoom
        };
        if (!isPlace)
        {
            SDL_FRect levelRect = {
                global.win.Main.level()[lastPos].zoomSize.x,
                global.win.Main.level()[lastPos].zoomSize.y,
                global.win.Main.level()[lastPos].zoomSize.w,
                global.win.Main.level()[lastPos].zoomSize.h
            };

            rect = {
                levelRect.x + (levelRect.w - rect.w) / 2.0f,
                levelRect.y + (levelRect.h - rect.h) / 2.0f,
                rect.w,
                rect.h
            };
        }

        SDL_FRect r = {
            (rect.x - win.level()[lastPos].moveCoord.x) / zoom,
            (rect.y - win.level()[lastPos].moveCoord.y) / zoom,
            rect.w / zoom,
            rect.h / zoom
        };

        newLevel.moveCoord = {
            rect.x,
            rect.y
        };
        newLevel.zoomSize = rect;
        newLevel.size = r;

        if (newLevel.size.w < 1.0f || newLevel.size.h < 1.0f)
        {
            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, "Errore", "Copia troppo piccola!", nullptr);
            return;
        }

        for (int y = 0; y < static_cast<int>(r.h); ++y)
        {
            newLevel.map.push_back({});
            for (int x = 0; x < static_cast<int>(r.w); ++x)
            {
                ColorRgb pixel = {};

                pixel = map[y][x];

                newLevel.map[y].push_back(pixel);
            }
        }
        newLevel.startMap = newLevel.map;

        win.level()[lastPos].needsUpdate = true;

        win.level().UpdateCanvas();

        newLevel.opacity = global.copy.opacity;
        newLevel.bgColor = win.level()[lastPos].bgColor;

        if (win.GetSelections()->IsSelected())
        {
            win.GetSelections()->GetLastType() = Tools::NOTHING;
            win.GetSelections()->IsSelected() = false;
        }

        APP::updateCronology(global);

        newLevel.needsUpdate = true;

        global.currentLevel = newPos;

        win.level().GetLevel().push_back(std::move(newLevel));

        SET::menuTools(global);
        SET::levelMenu(global);

        win.level()[newPos].needsUpdate = true;
    }

    void updateCronology(VariabiliGlobali& global)
    {
        Level& currentLvl = global.win.Main.level()[global.currentLevel];

        if (currentLvl.chronology.elements.empty() ||
            currentLvl.map != currentLvl.chronology.elements.back().map ||
            currentLvl.moveCoord != currentLvl.chronology.elements.back().moveCoord)
        {
            if (currentLvl.chronology.pos + 1 < currentLvl.chronology.elements.size())
            {
                currentLvl.chronology.elements.resize(currentLvl.chronology.pos + 1);
            }

            ChronologyElements chrono;
            chrono.map = currentLvl.map;
            chrono.moveCoord = currentLvl.moveCoord;
            chrono.zoomSize = currentLvl.zoomSize;

            currentLvl.chronology.pos = currentLvl.chronology.elements.size();
            currentLvl.chronology.elements.push_back(std::move(chrono));
        }
        global.cronologyUpdate = false;
    }

    void Undo(VariabiliGlobali& global)
    {
        Level& currentLvl = global.win.Main.level()[global.currentLevel];
        if (currentLvl.chronology.pos > 0)
        {
            currentLvl.chronology.pos--;

            currentLvl.map = currentLvl.chronology.elements[currentLvl.chronology.pos].map;
            currentLvl.moveCoord = currentLvl.chronology.elements[currentLvl.chronology.pos].moveCoord;
            currentLvl.zoomSize = currentLvl.chronology.elements[currentLvl.chronology.pos].zoomSize;

            currentLvl.needsUpdate = true;
        }
    }

    void Redo(VariabiliGlobali& global)
    {
        Level& currentLvl = global.win.Main.level()[global.currentLevel];
        if (currentLvl.chronology.pos + 1 < currentLvl.chronology.elements.size())
        {
            currentLvl.chronology.pos++;

            currentLvl.map = currentLvl.chronology.elements[currentLvl.chronology.pos].map;
            currentLvl.moveCoord = currentLvl.chronology.elements[currentLvl.chronology.pos].moveCoord;
            currentLvl.zoomSize = currentLvl.chronology.elements[currentLvl.chronology.pos].zoomSize;

            currentLvl.needsUpdate = true;
        }
    }

    std::string getToolString(Tools tool)
    {
        switch (tool)
        {
        case Tools::MOVE: return "Move";
        case Tools::BRUSH: return "Brush";
        case Tools::ERASER: return "Eraser";
        case Tools::BUCKET: return "Bucket";
        case Tools::PIPETTE: return "Pipette";
        case Tools::SELEZIONE_RETTANGOLARE: return "Rectangular Selection";
        case Tools::SELEZIONE_CIRCOLARE: return "Elliptical Selection";
        case Tools::SELEZIONE_LAZO: return "Lasso Selection";
        case Tools::SELEZIONE_COLORE: return "Color Selection";
        }
        return "\0";
    }

    std::string getToolsSettingString(Tools tool, int nSetting)
    {
        switch (tool)
        {
        case Tools::NOTHING:
            break;

        case Tools::MOVE:
        {
            break;
        }

        case Tools::BRUSH:
        {
            switch (nSetting)
            {
            case 0: return "Size";
            }
            break;
        }

        case Tools::ERASER:
        {
            switch (nSetting)
            {
            case 0: return "Size";
            }
            break;
        }

        case Tools::BUCKET:
        {
            switch (nSetting)
            {
            case 0: return "Error";
            }
            break;
        }

        case Tools::PIPETTE:
        {
            break;
        }

        case Tools::SELEZIONE_RETTANGOLARE:
        {
            break;
        }

        case Tools::SELEZIONE_CIRCOLARE:
        {
            break;
        }

        case Tools::SELEZIONE_LAZO:
        {
            break;
        }

        case Tools::SELEZIONE_COLORE:
        {
            switch (nSetting)
            {
            case 0: return "Error";
            }
            break;
        }
        }
        return "\0";
    }

    void ancoraLivello(VariabiliGlobali& global, size_t lvlPos)
    {
        std::vector<Level>& levels = global.win.Main.level().GetLevel();
        float zoom = global.win.Main.level().GetZoom();

        if (levels.size() <= 1) return;
        if (lvlPos == levels.size() - 1) return;

        Level& currentLvl = levels[lvlPos];
        Level& targetLvl = levels[lvlPos + 1]; // il targetLvl è il livello su cui verrà incollato il currentLvl

        Level newLevel;
        newLevel.name = targetLvl.name;

        Coord min = {
            std::min(currentLvl.moveCoord.x, targetLvl.moveCoord.x),
            std::min(currentLvl.moveCoord.y, targetLvl.moveCoord.y)
        };
        Coord cornerMax = {
            std::max(currentLvl.moveCoord.x + currentLvl.zoomSize.w, targetLvl.moveCoord.x + targetLvl.zoomSize.w),
            std::max(currentLvl.moveCoord.y + currentLvl.zoomSize.h, targetLvl.moveCoord.y + targetLvl.zoomSize.h)
        };

        newLevel.moveCoord = {
            min.x,
            min.y
        };

        newLevel.zoomSize = {
            newLevel.moveCoord.x,
            newLevel.moveCoord.y,
            cornerMax.x - newLevel.moveCoord.x,
            cornerMax.y - newLevel.moveCoord.y
        };

        newLevel.size.w = newLevel.zoomSize.w / zoom;
        newLevel.size.h = newLevel.zoomSize.h / zoom;

        size_t newW = static_cast<size_t>(std::ceil(newLevel.size.w));
        size_t newH = static_cast<size_t>(std::ceil(newLevel.size.h));
        if (newW == 0 || newH == 0) return;

        newLevel.map.resize(newH, std::vector<ColorRgb>(newW));

        auto pasteLvl = [zoom](Level& lvl, Level& target)
            {
                int endY = static_cast<int>(std::ceil(target.size.h));
                int endX = static_cast<int>(std::ceil(target.size.w));

                for (int y = 0; y < endY; ++y)
                {
                    for (int x = 0; x < endX; ++x)
                    {
                        FSize offset = {
                            target.moveCoord.x - lvl.moveCoord.x,
                            target.moveCoord.y - lvl.moveCoord.y,
                        };

                        int lvlX = x + static_cast<int>(std::floor(offset.w / zoom));
                        int lvlY = y + static_cast<int>(std::floor(offset.h / zoom));

                        if (lvlY >= 0 && lvlY < static_cast<int>(lvl.map.size()) &&
                            lvlX >= 0 && lvlX < static_cast<int>(lvl.map[lvlY].size()) &&
                            y >= 0 && y < static_cast<int>(target.map.size()) &&
                            x >= 0 && x < static_cast<int>(target.map[y].size()))
                        {
                            lvl.map[lvlY][lvlX] = target.map[y][x];
                        }
                    }
                }
            };

        pasteLvl(newLevel, targetLvl);
        pasteLvl(newLevel, currentLvl);

        newLevel.startMap = newLevel.map;

        if (global.baseLevelPos == lvlPos) global.win.Main.level().SetBaseLevelDeleted(true); 
        else if (global.baseLevelPos == static_cast<size_t>(lvlPos + 1)) global.baseLevelPos = lvlPos;
        else if (global.baseLevelPos > static_cast<size_t>(lvlPos + 1)) global.baseLevelPos--;


        newLevel.opacity = 255;
        newLevel.bgColor = targetLvl.bgColor;

        APP::updateCronology(global);

        newLevel.needsUpdate = true;

        levels.erase(levels.begin() + lvlPos + 1);
        levels.erase(levels.begin() + lvlPos);
        levels.insert(levels.begin() + lvlPos, newLevel);

        global.win.Main.level().UpdateCanvas();
        global.win.Main.level().UpdateAlphaGrid();

        SET::menuTools(global);
        SET::levelMenu(global);
    }
}